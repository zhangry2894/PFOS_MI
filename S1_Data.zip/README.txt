S1 Data  Essential inputs and final results

01_inputs contains standardized target evidence and source/annotation snapshots.
02_results contains complete final result tables for all scientific branches
reported in the manuscript. 03_figure_data contains the source values of the
current main and supplementary figures. Tables.xlsx is unchanged and contains
the current main tables and supplementary tabulations.

The primary definition is 37 biological overlap genes, 36 measured candidates.
Historical38 and strict18 are separate sensitivity analyses. Source filenames,
variant/method/cohort/rule columns identify each branch. GO_KEGG_all_terms.csv
contains every tested row (including nonsignificant rows), not selected hits.
Transcriptome_wide_limma.csv.gz preserves the full multiple-testing families.
All_subset_comparisons.csv retains 492 primary, 957 strict18 and 120 historical
comparison rows. Workflow tables retain the final held-out predictions and
selection results, not disposable training caches. Negative results are kept.

In consolidated CSVs, source_member identifies the original table and source_row
is its one-based data-row order. All original header names and cell strings are
unchanged. Empty added cells mean that a field was absent in that source schema;
consult SOURCE_MAP.csv/source_columns_json to distinguish that from a recorded
empty value. source_table_member specifies the retained source table when an
identical historical alias is reconstructed. Do not combine different definitions, cohorts or selection rules
as if they were independent observations. Original paths in the source map are
provenance identifiers, not current navigation paths.

The PFOS evidence is a standardized retained database export, not proof of
binding. Third-party export redistribution conditions and source accessions are
documented in S2 and the repository RIGHTS_AND_SOURCES.md. S3/S4 are processed
gene-expression matrices, not raw CEL files. Necessary code, fold definitions,
parameters, final models and additional external matrices are supplied in S2;
structural records and docking reproduction materials are in S5.

Duplicate summaries, repeated per-fold exports, all nonselected per-subset model
caches and nonselected per-subset sample predictions are omitted. These can be
regenerated using the original refit code; they were not regenerated during this
packaging. Every retained final table was checked against the previous edition
at cell-string or unchanged-file-byte level. Scientific results were not changed.
The unchanged complete prior edition remains with the authors as a backup.

For common reading, start with 02_results/Tables.xlsx and 03_figure_data.
For software, use the source map and S2 restoration instructions. The checksum
manifest covers every current file except the manifest itself.
