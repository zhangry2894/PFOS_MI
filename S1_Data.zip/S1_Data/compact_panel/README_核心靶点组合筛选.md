# PFOS–MI核心靶点组合筛选（≤7个基因）

## 1. PFOS靶点定义

本分析采用“至少被2个预测数据库共同支持”的多来源共识交集：SuperPred、PharmMapper、SwissTargetPrediction、STITCH和TargetNet中至少2个数据库命中。该集合包含74个PFOS靶点。严格要求5个数据库全部命中的字面五重交集为0，因此不能用于后续机器学习。

74个PFOS共识靶点与原始2,841个MI相关基因求交得到38个基因；其中37个同时存在于GSE66360和GSE48060表达矩阵。

## 2. 文献参照与本次路线

已发表AMI研究常将LASSO、SVM-RFE、随机森林/Boruta和XGBoost等算法的交集用于压缩生物标志物。例如：

- Frontiers in Cardiovascular Medicine（2022）采用LASSO、Random Forest和SVM-RFE交集获得7个AMI标志物。
- Aging（2024）采用SVM-RFE、XGBoost-RFE、Boruta和LASSO交集获得4个AMI候选基因。
- 近期AMI研究采用Logistic、LASSO、SVM-RFE和Random Forest交集获得7个候选标志物，并进一步进行外部表达与实验验证。

ExhauFS方法论文提出先缩小候选特征集合，再对可计算规模的所有特征组合进行穷举比较。本次分析结合这两类思路：

1. 在GSE66360发现集内运行LASSO、SVM-RFE、Boruta和XGBoost。
2. 保留至少被2/4算法支持的基因，恰好得到7个候选。
3. 穷举所有2–7基因组合，共120种。
4. 每种组合使用相同的岭逻辑回归模型；lambda.1se仅在发现集固定分层5折交叉验证中确定。
5. 仅使用GSE66360预定义验证集选择组合。
6. 组合锁定后，才读取GSE48060外部验证结果。

## 3. 七基因算法投票池

| 基因 | 支持算法数 | 算法 |
|---|---:|---|
| AKR1C3 | 4 | LASSO、SVM-RFE、Boruta、XGBoost |
| MMP2 | 4 | LASSO、SVM-RFE、Boruta、XGBoost |
| MMP9 | 4 | LASSO、SVM-RFE、Boruta、XGBoost |
| NR3C2 | 3 | SVM-RFE、Boruta、XGBoost |
| PLAT | 3 | LASSO、SVM-RFE、Boruta |
| PLAU | 3 | SVM-RFE、Boruta、XGBoost |
| ALPL | 2 | SVM-RFE、Boruta |

## 4. 每个基因数下内部验证最优的组合

| 基因数 | 内部验证最优组合 | GSE66360验证AUC（95%CI） | GSE48060外部AUC（95%CI） |
|---:|---|---:|---:|
| 2 | ALPL + PLAU | 0.884（0.798–0.970） | 0.733（0.588–0.878） |
| 3 | ALPL + NR3C2 + PLAU | 0.807（0.695–0.920） | 0.731（0.584–0.879） |
| 4 | ALPL + MMP9 + NR3C2 + PLAU | 0.815（0.703–0.927） | 0.743（0.599–0.887） |
| 5 | ALPL + MMP2 + MMP9 + NR3C2 + PLAU | 0.791（0.669–0.912） | 0.739（0.595–0.883） |
| 6 | ALPL + MMP2 + MMP9 + NR3C2 + PLAT + PLAU | 0.760（0.633–0.888） | 0.724（0.579–0.869） |
| 7 | AKR1C3 + ALPL + MMP2 + MMP9 + NR3C2 + PLAT + PLAU | 0.699（0.558–0.840） | 0.594（0.432–0.757） |

外部AUC没有参与上述组合的挑选。

## 5. 推荐结果

### 统计学最简组合：ALPL + PLAU

- 内部验证AUC：0.884（95%CI 0.798–0.970）
- 外部验证AUC：0.733（95%CI 0.588–0.878）
- 方向锁定等权评分外部AUC：0.728（95%CI 0.583–0.874）
- 1,000次验证集分层bootstrap中，该组合成为最优组合的频率：79.0%
- 基因进入bootstrap最优组合的频率：ALPL 98.1%，PLAU 97.3%
- 岭模型系数：ALPL 0.2941，PLAU 0.1925，方向均为MI升高

这是当前最符合“组合简洁、内部筛选稳定、外部方向锁定后仍有区分能力”的方案。

### 机制覆盖更宽的备选组合：ALPL + MMP9 + NR3C2 + PLAU

该4基因组合是所有4基因模型中内部验证最优者，内部AUC为0.815，外部AUC为0.743。它增加了MMP9和NR3C2，机制解释空间更大，但并未在内部验证中超过2基因组合；因此建议作为备选机制面板，不应仅因外部AUC稍高而替代预先锁定的2基因主组合。

### 传统严格四算法交集：AKR1C3 + MMP2 + MMP9

内部AUC为0.616，外部AUC为0.545。它具有最严格的算法一致性，但预测迁移能力较弱。若文章强调“算法一致的机制靶点”，可以保留；若强调“组合诊断表现”，不建议作为主模型。

## 6. 解释边界

- 本结果来自公共外周血/循环细胞表达队列，不能直接证明PFOS与ALPL或PLAU发生物理结合。
- ALPL和PLAU在GSE48060中的单基因差异表达FDR未小于0.05；外部证据主要来自两基因联合排序能力。因此应称为“探索性组合”或“候选核心靶点”，不应直接称为临床诊断标志物。
- 如果文章把核心靶点从原组合改为ALPL和PLAU，后续富集、免疫相关、网络图、docking和讨论均需同步更新或明确哪些分析属于旧靶点集合。
- 不能继续查看GSE48060后再更换组合，否则GSE48060将失去独立外部验证属性。

## 7. 主要文献

1. Zhang et al. Machine learning-based integration develops biomarkers initial the crosstalk between inflammation and immune in acute myocardial infarction patients. Front Cardiovasc Med. 2022;9:1059543. https://doi.org/10.3389/fcvm.2022.1059543
2. Huang et al. Comprehensive bioinformatics analytics and in vivo validation reveal SLC31A1 as an emerging diagnostic biomarker for acute myocardial infarction. Aging. 2024. https://pmc.ncbi.nlm.nih.gov/articles/PMC11132003/
3. Li et al. Machine learning-derived identification of an obesity and lipid metabolism-related genes signature for the diagnosis and molecular typing of acute myocardial infarction. Front Cardiovasc Med. 2026;13:1694872. https://doi.org/10.3389/fcvm.2026.1694872
4. Nersisyan et al. ExhauFS: exhaustive search-based feature selection for classification and survival regression. PeerJ. 2022;10:e13200. https://doi.org/10.7717/peerj.13200
5. Li et al. Robust biomarker screening from gene expression data by stable machine learning-recursive feature elimination methods. Comput Biol Chem. 2022;100:107747. https://doi.org/10.1016/j.compbiolchem.2022.107747
