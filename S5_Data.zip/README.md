# S5 Data: essential docking inputs and final evidence

This reader-oriented edition replaces the many dated run folders with three directories.
No docking score, molecular coordinate, RMSD or scientific conclusion was changed.
The full preceding archive remains in the author's edition 19 backup.

## Read the final results first

- `02_results/native_dry_per_seed.csv` and `native_fixed_water_per_seed.csv`: all
  15 original native-ligand validation searches (five preparations, three seeds).
- `02_results/PFOS_all9_top1_scores.csv`: all nine PFOS dry-pocket, fixed-water,
  and remote-surface scores. Computational search seeds are not biological replicates.
- The two `all_pose_RMSD.csv` files retain every ranked native-pose result,
  including the duplicate water reproducibility check. ALPL and fixed-water PLAU
  failures are retained; lower-ranked recovery does not replace the top-ranked test.
- `02_results/Fig4_all14_contacts.csv`: all 14 nearest-residue geometric contacts
  at <=4 Angstrom for first predefined seed 20260920, rank 1. Not assigned H bonds.
- `02_results/display_ligands.sdf`: the six displayed native/reference/PFOS poses.
  Exact record-to-filename mapping is in `SOURCE_MAP.csv`. Receptors are in inputs.

## Inputs, not processing clutter

`01_inputs/9SH5.cif`, `6NMB.pdb`, `A1JNY.sdf`, `AMH.sdf` and `PFOS.sdf` are the
original supplied structure/ligand files. They are distinguished from the eight
prepared PDBQT files actually used by Vina. Raw PDB/CIF files alone do not specify
protonation, charge, atom typing or retained water/metal choices, so both layers
are necessary. `AMH.sdf` is retained as supplied for chemical-template provenance;
it is not substituted for the experimental bound coordinates in 6NMB. The
tranexamic-acid chemical states and bound-coordinate references actually used are in
`prepared_ligands_and_bound_references.sdf` and the preparation records.

`run_parameters.csv` lists all grid centers/sizes, seeds, exhaustiveness, CPU,
energy range and mode count, including two duplicate verification searches.
`all_run_configurations.txt` preserves their exact original configurations.
`preparation_and_completed_run_records.txt` preserves chemistry, environment,
software hashes, run status and input/output provenance as readable named records.

## Why several combined files remain

`all_completed_docking_outputs.pdbqt` holds complete final Vina poses for the 24
scientific searches. `REMARK SOURCE_RECORD` separates each run. Two byte-identical
replay outputs use aliases rather than extra copies. These are final outputs, not
optimization trajectories. All final execution and receptor-preparation logs are
in one named-record text file. Multiple required SDF records share one SDF file.
No nested archive, encoded database or discarded intermediate is hidden here.

Removed from delivery: duplicate pose-conversion SDFs, repeated display copies,
old failed preparation-attempt work directories, superseded plotting data and
nonessential packaging/audit caches. The scientific control failures remain.

## Verification and optional reproduction

From an extracted S5 directory, run:

```
python 03_code/restore_and_check.py --verify
python 03_code/restore_and_check.py --verify --rdkit-path /path/to/site-packages
python 03_code/restore_and_check.py --restore /NEW/writable/docking_workspace
```

The first command checks byte provenance, archived input/output hashes, all 310
identity-RMSD records (including the duplicate water check), nine PFOS scores,
15 seed-level native summaries and 14 contacts. If RDKit is installed, the same
command also checks chemically constrained fixed-frame symmetry RMSDs; otherwise
the report explicitly records that the symmetry check was not run. No fitting is
used. `SOURCE_MAP.csv` supplies exact byte boundaries, original names and SHA256.
Restoration creates only a new directory and recreates required script paths.

For an actual Vina rerun, use the restored portable entry points:

```
python /NEW/writable/docking_workspace/corrected_baseline/scripts/replay_bundle.py --vina /path/to/vina --output /NEW/dry_replay
python /NEW/writable/docking_workspace/replay_water_bundle.py --vina /path/to/vina --output /NEW/water_replay
```

These require the recorded Vina 1.2.7 executable SHA256. Reproduction on a different
build may not be byte-identical. For images, set `PFOS_PYMOL_ROOT` to the restored
`figure_upgrade_20261021/pymol` directory and run its `render_structures.py` inside
PyMOL 3.1.0, then run the restored `remaining/assemble_structural.R` in R with the
listed libraries. The scientific preparation/analysis source is retained verbatim;
its original machine-specific executable paths must be adapted for a full raw-
structure rebuild. The portable replay instead uses the frozen prepared inputs.

This packaging step did not rerun Vina, prepare structures or rerender figures.
Coordinate, numerical and provenance verification is not a new docking validation.
The results remain preparation-dependent computational hypotheses and do not
establish PFOS binding, inhibition or competitive occupancy.

`MANIFEST_SHA256.csv` inventories this edition. Third-party structures remain
attributable to RCSB PDB entries 9SH5/6NMB and their chemical components, and the
PFOS ligand source is PubChem CID 74483. No new licence or accession is asserted.
