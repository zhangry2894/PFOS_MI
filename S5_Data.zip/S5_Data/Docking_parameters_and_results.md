# ALPL/PLAU docking-rescue parameters and results

## Scope and interpretation

This analysis is a structural sensitivity analysis of PFOS placement in two co-crystal-defined pockets. It is not an experimental binding assay. AutoDock Vina scores are scoring-function outputs and must not be interpreted as free energies, dissociation constants, target specificity, competitive inhibition, or functional modulation.

## Ligand and structures

- PFOS: PubChem CID 74483, modeled as the deprotonated sulfonate with formal charge -1; prepared PDBQT partial-charge sum = -0.999 e.
- ALPL: PDB 9SH5, chain A; native ligand A1JNY; retained Zn602, Mg601, Ca603, and Zn604.
- PLAU: PDB 6NMB, chain A; native ligand AMH, residue A302.
- Ligand-specific control: HSA PDB 4E99, chain A, two crystallographic PFOS sites.

## Primary Vina configuration

Common parameters:

```text
exhaustiveness = 16
num_modes = 20
energy_range = 5
cpu = 4
seed = 20260920, 20260921, or 20260922
```

Target-specific boxes:

| Target/condition | center_x | center_y | center_z | size_x | size_y | size_z |
|---|---:|---:|---:|---:|---:|---:|
| ALPL orthosteric, dry/local-water | 114.468 | 134.639 | 145.323 | 22.000 | 28.220 | 22.000 |
| ALPL remote surface control | 116.034 | 143.232 | 91.084 | 22.000 | 22.000 | 22.000 |
| PLAU orthosteric, dry/local-water | 56.467 | -5.942 | 108.695 | 22.000 | 22.381 | 22.000 |
| PLAU remote surface control | 79.393 | -20.244 | 133.719 | 22.000 | 22.000 | 22.000 |

The dry preparation removed crystallographic waters. The local-water sensitivity preparation retained waters within 4.0 A of the co-crystallized ligand: zero waters for ALPL/9SH5 and three waters for PLAU/6NMB.

Example command:

```text
vina --config <run-specific-config.txt>
```

Every run-specific configuration, input path, seed, output path, and log is retained in `S5_Data.zip`.

## Focused native-ligand redocking sensitivity

The focused sensitivity run retained the same centers and seeds, shortened each primary box dimension by 6 A with a minimum dimension of 18 A, and used:

```text
exhaustiveness = 64
num_modes = 40
energy_range = 10
cpu = 4
```

Focused box sizes were 18.000 x 22.220 x 18.000 A for ALPL and 18.000 x 18.000 x 18.000 A for PLAU.

## Validation rule

Native-ligand and HSA-PFOS redocking used raw symmetry-corrected heavy-atom RMSD in the fixed receptor coordinate frame. The ligand was not superposed before RMSD calculation. The prespecified strict pass rule was top-ranked RMSD <=2.0 A for all three seeds.

## Redocking results

| System | Mean top-ranked RMSD (A) | Mean best-available RMSD (A) | Seeds passing top-ranked rule | Status |
|---|---:|---:|---:|---|
| ALPL/A1JNY, primary | 8.833 | 2.654 | 0/3 | FAIL |
| PLAU/AMH, primary | 4.747 | 0.861 | 0/3 | FAIL |
| ALPL/A1JNY, focused | 5.137 | 2.286 | 0/3 | FAIL |
| PLAU/AMH, focused | 4.730 | 0.956 | 0/3 | FAIL |
| HSA/PFOS site 1 | 2.167 | 1.523 | 0/3 | FAIL |
| HSA/PFOS site 2 | 7.328 | 1.693 | 0/3 | FAIL |

Lower-ranked near-native poses show that the search sampled crystallographic-like alternatives for PLAU and both HSA sites, but the scoring/ranking step did not reliably place them first. Therefore, the docking protocol did not meet strict validation.

## PFOS docking results

| Target | Dry pocket score (kcal/mol) | Local-water score (kcal/mol) | Remote-surface score (kcal/mol) | Surface minus dry (kcal/mol) | Dry-pose repeatability, maximum pairwise RMSD (A) |
|---|---:|---:|---:|---:|---:|
| ALPL | -6.786 +/- 0.037 | -6.786 +/- 0.037 | -3.472 +/- 0.082 | 3.314 | 1.680 |
| PLAU | -7.540 +/- 0.130 | -7.214 +/- 0.112 | -4.233 +/- 0.041 | 3.307 | 1.006 |

The modeled orthosteric-pocket scores were more favorable than their matched surface controls, and dry top poses were repeatable across seeds. However, because top-ranked redocking failed, these findings are reported only as exploratory pocket-placement results.

## Recurrent residues within 4.0 A

- ALPL: Zn602, Ser110, Arg184, and His341 were among the recurrent nearest contacts.
- PLAU: Ser190, Ser195, Gly216, Gln192, Cys191, and Trp215 were among the recurrent nearest contacts.

Full contact frequencies and mean minimum distances are in `PFOS_residue_contacts_consensus.csv` and `PFOS_residue_contacts_all.csv`.

## Files to use for figure production

- `Fig3_source_redocking_RMSD.csv`
- `Fig3_source_repeatability.csv`
- `Fig3_source_PFOS_scores.csv`
- `PFOS_residue_contacts_consensus.csv`
- `PFOS_top_pose_seed_repeatability.csv`
- `PFOS_seed_results.csv`
- `docking_configuration_summary.csv`

## Representative pose selection and Figure 4

For each protein, the three seed-specific top-ranked dry-pocket PFOS poses were compared by pairwise heavy-atom RMSD. The medoid pose with the smallest mean RMSD to the other two top-ranked poses was selected for display. This selected ALPL seed 20260922 model 1 (Vina score -6.829 kcal/mol; mean medoid RMSD 1.254 A) and PLAU seed 20260921 model 1 (Vina score -7.466 kcal/mol; mean medoid RMSD 0.531 A).

`figures/Fig4.*` shows paired 3D pocket views and 2D interaction maps derived from those retained coordinates. The labels below each target report recurrent contacts present in all three top-ranked dry-pocket seed poses and the descriptive mean minimum distance. The complete contact table remains in `results/PFOS_residue_contacts_all.csv`. These images are exploratory pose visualizations, not evidence of experimental binding, affinity, inhibition, target engagement, or functional modulation.
