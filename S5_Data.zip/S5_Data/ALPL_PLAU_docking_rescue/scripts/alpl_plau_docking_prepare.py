from __future__ import annotations

import csv
import hashlib
import json
import math
import subprocess
import sys
from pathlib import Path

import gemmi
from rdkit import Chem
from meeko import MoleculePreparation, PDBQTWriterLegacy


SOURCE_ROOT = Path(sys.argv[1]).resolve()
OUT = Path(sys.argv[2]).resolve()
ADT_PYTHON = Path(sys.argv[3]).resolve()
PREP_RECEPTOR = Path(sys.argv[4]).resolve()

RAW = SOURCE_ROOT / "01_raw_inputs"
STRUCT_ALPL = RAW / "structures/ALPL_9SH5/9SH5.cif"
STRUCT_PLAU = RAW / "structures/PLAU_6NMB/6NMB.pdb"
LIG_ALPL = RAW / "native_ligands/ALPL_9SH5_A1JNY/A1JNY.sdf"
LIG_PLAU = RAW / "native_ligands/PLAU_6NMB_AMH/AMH.sdf"
PFOS = SOURCE_ROOT / "02_prepared_inputs/ligands/PFOS_CID74483_anion_minus1.pdbqt"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def meeko_text(mol: Chem.Mol) -> str:
    setups = MoleculePreparation().prepare(mol)
    if len(setups) != 1:
        raise RuntimeError(f"Expected one Meeko setup, got {len(setups)}")
    text, ok, error = PDBQTWriterLegacy.write_string(setups[0])
    if not ok:
        raise RuntimeError(str(error))
    return text


def pdbqt_charge(text: str) -> float:
    return sum(
        float(line[70:76])
        for line in text.splitlines()
        if line.startswith(("ATOM  ", "HETATM"))
    )


def alpl_bound_ligand() -> Chem.Mol:
    structure = gemmi.read_structure(str(STRUCT_ALPL))
    residue = next(res for res in structure[0]["A"] if res.name == "A1JNY")
    coord = {atom.name.strip(): atom for atom in residue}
    block = gemmi.cif.read_file(str(STRUCT_ALPL)).sole_block()
    atom_rows = block.find([
        "_chem_comp_atom.comp_id", "_chem_comp_atom.atom_id",
        "_chem_comp_atom.type_symbol",
    ])
    definitions = [list(row) for row in atom_rows if row[0] == "A1JNY"]
    rw = Chem.RWMol()
    name_to_index: dict[str, int] = {}
    for _, atom_id, symbol in definitions:
        if atom_id not in coord:
            continue
        atom = Chem.Atom(symbol)
        atom.SetFormalCharge(0)
        name_to_index[atom_id] = rw.AddAtom(atom)
    bond_rows = block.find([
        "_chem_comp_bond.comp_id", "_chem_comp_bond.atom_id_1",
        "_chem_comp_bond.atom_id_2", "_chem_comp_bond.value_order",
    ])
    bond_types = {
        "sing": Chem.BondType.SINGLE, "doub": Chem.BondType.DOUBLE,
        "trip": Chem.BondType.TRIPLE, "arom": Chem.BondType.AROMATIC,
    }
    for comp, a1, a2, order in bond_rows:
        if comp == "A1JNY" and a1 in name_to_index and a2 in name_to_index:
            rw.AddBond(name_to_index[a1], name_to_index[a2], bond_types[order])
    mol = rw.GetMol()
    conformer = Chem.Conformer(mol.GetNumAtoms())
    for atom_id, idx in name_to_index.items():
        pos = coord[atom_id].pos
        conformer.SetAtomPosition(idx, (pos.x, pos.y, pos.z))
        mol.GetAtomWithIdx(idx).SetProp("_TriposAtomName", atom_id)
    mol.AddConformer(conformer, assignId=True)
    Chem.SanitizeMol(mol)
    mol = Chem.RemoveHs(mol)
    mol.SetProp("_Name", "A1JNY_bound_ALPL_9SH5_chain_A")
    return mol


def parse_pdb_atom(line: str) -> dict:
    return {
        "record": line[:6].strip(), "serial": int(line[6:11]),
        "name": line[12:16].strip(), "altloc": line[16:17],
        "resname": line[17:20].strip(), "chain": line[21:22],
        "resseq": line[22:26].strip(), "icode": line[26:27],
        "x": float(line[30:38]), "y": float(line[38:46]), "z": float(line[46:54]),
        "occupancy": float(line[54:60] or 1.0), "bfactor": float(line[60:66] or 0.0),
        "element": ((line[76:78].strip() if len(line) >= 78 else "") or line[12:16].strip()[0]).upper(),
        "line": line,
    }


def plau_source_atoms() -> tuple[list[dict], list[str]]:
    lines = STRUCT_PLAU.read_text(encoding="ascii", errors="replace").splitlines()
    atoms = []
    conect = []
    for line in lines:
        if line.startswith(("ATOM  ", "HETATM")) and len(line) >= 54:
            atom = parse_pdb_atom(line)
            if atom["altloc"] in {" ", "A", "1"}:
                atoms.append(atom)
        elif line.startswith("CONECT"):
            conect.append(line)
    return atoms, conect


def plau_bound_ligand() -> Chem.Mol:
    atoms, conect = plau_source_atoms()
    ligand = [a for a in atoms if a["resname"] == "AMH" and a["chain"] == "A" and a["resseq"] == "302"]
    serials = {a["serial"] for a in ligand}
    relevant_conect = []
    for line in conect:
        values = [int(line[i:i + 5]) for i in range(6, len(line), 5) if line[i:i + 5].strip()]
        if values and values[0] in serials:
            kept = [v for v in values if v in serials]
            if len(kept) >= 2:
                relevant_conect.append("CONECT" + "".join(f"{v:5d}" for v in kept))
    pdb_block = "\n".join([a["line"] for a in ligand] + relevant_conect + ["END", ""])
    pdb_mol = Chem.MolFromPDBBlock(pdb_block, sanitize=False, removeHs=False, proximityBonding=False)
    if pdb_mol is None:
        raise RuntimeError("RDKit could not parse bound AMH from 6NMB")
    template = next((m for m in Chem.SDMolSupplier(str(LIG_PLAU), removeHs=False) if m is not None), None)
    if template is None:
        raise RuntimeError("RDKit could not parse the author-supplied AMH SDF")
    template = Chem.RemoveHs(template)
    pdb_mol = Chem.RemoveHs(pdb_mol, sanitize=False)
    try:
        mol = Chem.AssignBondOrdersFromTemplate(template, pdb_mol)
        Chem.SanitizeMol(mol)
    except Exception:
        # The PDB CONECT graph is retained if bond-order transfer is not possible.
        mol = pdb_mol
        Chem.SanitizeMol(mol)
    mol.SetProp("_Name", "AMH_bound_PLAU_6NMB_chain_A_residue_302")
    return mol


def atom_line(serial: int, name: str, resname: str, chain: str, resseq: int,
              x: float, y: float, z: float, occupancy: float, bfactor: float,
              element: str, record: str) -> str:
    atom_name = f" {name:<3}" if len(name) < 4 and len(element) == 1 else f"{name:<4}"
    return (
        f"{record:<6}{serial:5d} {atom_name} {resname:>3} {chain:1}{resseq:4d}    "
        f"{x:8.3f}{y:8.3f}{z:8.3f}{occupancy:6.2f}{bfactor:6.2f}          {element:>2}"
    )


def alpl_receptor_atoms() -> tuple[list[dict], list[dict], list[dict]]:
    structure = gemmi.read_structure(str(STRUCT_ALPL))
    chain = structure[0]["A"]
    protein: list[dict] = []
    metals: list[dict] = []
    waters: list[dict] = []
    for residue in chain:
        category = "protein" if residue.het_flag == "A" else (
            "metal" if residue.name in {"ZN", "MG", "CA"} else (
                "water" if residue.name in {"HOH", "WAT"} else "other"
            )
        )
        if category == "other":
            continue
        for atom in residue:
            if atom.altloc not in {"\x00", " ", "A", "1"}:
                continue
            row = {
                "record": "ATOM" if category == "protein" else "HETATM",
                "name": atom.name.strip(), "resname": residue.name,
                "chain": "A", "resseq": residue.seqid.num,
                "x": atom.pos.x, "y": atom.pos.y, "z": atom.pos.z,
                "occupancy": atom.occ, "bfactor": atom.b_iso,
                "element": atom.element.name.upper(),
            }
            {"protein": protein, "metal": metals, "water": waters}[category].append(row)
    return protein, metals, waters


def plau_receptor_atoms() -> tuple[list[dict], list[dict], list[dict]]:
    atoms, _ = plau_source_atoms()
    protein = [a for a in atoms if a["record"] == "ATOM" and a["chain"] == "A"]
    metals = [a for a in atoms if a["record"] == "HETATM" and a["chain"] == "A" and a["resname"] in {"ZN", "MG", "CA"}]
    waters = [a for a in atoms if a["record"] == "HETATM" and a["resname"] in {"HOH", "WAT"}]
    return protein, metals, waters


def ligand_coords(mol: Chem.Mol) -> list[tuple[float, float, float]]:
    conf = mol.GetConformer()
    return [tuple(conf.GetAtomPosition(i)) for i, atom in enumerate(mol.GetAtoms()) if atom.GetAtomicNum() > 1]


def near_waters(waters: list[dict], ligand_xyz: list[tuple[float, float, float]], cutoff: float = 4.0) -> list[dict]:
    selected = []
    for atom in waters:
        if min(math.dist((atom["x"], atom["y"], atom["z"]), xyz) for xyz in ligand_xyz) <= cutoff:
            selected.append(atom)
    return selected


def write_receptor(path: Path, protein: list[dict], metals: list[dict], waters: list[dict]) -> None:
    lines = []
    for serial, atom in enumerate(protein + metals + waters, 1):
        lines.append(atom_line(
            serial, atom["name"], atom["resname"], atom.get("chain", "A") or "A",
            int(atom["resseq"]), atom["x"], atom["y"], atom["z"],
            atom.get("occupancy", 1.0), atom.get("bfactor", 0.0),
            atom["element"], atom["record"],
        ))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines + ["END", ""]), encoding="ascii")


def prepare_receptor(pdb: Path, pdbqt: Path, condition: str, log: Path) -> None:
    cleanup = "nphs_lps_waters" if condition == "dry" else "nphs_lps"
    command = [
        str(ADT_PYTHON), str(PREP_RECEPTOR), "-r", str(pdb), "-o", str(pdbqt),
        "-A", "checkhydrogens", "-U", cleanup,
    ]
    run = subprocess.run(command, capture_output=True, text=True)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(
        "COMMAND\n" + subprocess.list2cmdline(command) + "\n\nSTDOUT\n" + run.stdout + "\nSTDERR\n" + run.stderr,
        encoding="utf-8",
    )
    if run.returncode != 0 or not pdbqt.exists() or pdbqt.stat().st_size == 0:
        raise RuntimeError(f"Receptor preparation failed: {pdb}; see {log}")
    patched = []
    for line in pdbqt.read_text(encoding="ascii", errors="replace").splitlines():
        if line.startswith("HETATM") and line[17:20].strip() in {"ZN", "MG", "CA"}:
            line = line[:70] + f"{2.0:6.3f}" + line[76:]
        patched.append(line)
    pdbqt.write_text("\n".join(patched) + "\n", encoding="ascii")


def grid(ligand_xyz: list[tuple[float, float, float]], protein: list[dict]) -> dict:
    center = {axis: round(sum(p[i] for p in ligand_xyz) / len(ligand_xyz), 3) for i, axis in enumerate("xyz")}
    size = {}
    for i, axis in enumerate("xyz"):
        extent = max(p[i] for p in ligand_xyz) - min(p[i] for p in ligand_xyz)
        size[axis] = round(min(30.0, max(22.0, extent + 16.0)), 3)
    ca = [a for a in protein if a["name"] == "CA"]
    protein_center = [sum(a[axis] for a in protein) / len(protein) for axis in ("x", "y", "z")]
    eligible = []
    for atom in ca:
        point = [atom[axis] for axis in ("x", "y", "z")]
        distance = math.dist(point, [center[a] for a in "xyz"])
        if distance < 25.0:
            continue
        density = sum(math.dist(point, [other[a] for a in "xyz"]) <= 10.0 for other in ca)
        eligible.append((density, -distance, atom))
    if not eligible:
        raise RuntimeError("No surface-control C-alpha atom was at least 25 A from the orthosteric center")
    _, _, anchor = min(eligible, key=lambda item: (item[0], item[1]))
    vector = [anchor[axis] - protein_center[i] for i, axis in enumerate(("x", "y", "z"))]
    norm = math.sqrt(sum(v * v for v in vector))
    control = {
        axis: round(anchor[axis] + 6.0 * vector[i] / norm, 3)
        for i, axis in enumerate(("x", "y", "z"))
    }
    return {
        "center": center, "size": size,
        "surface_control": {"center": control, "size": {"x": 22.0, "y": 22.0, "z": 22.0},
                            "anchor_residue": f"{anchor['resname']}:{anchor.get('chain', 'A')}:{anchor['resseq']}"},
    }


def main() -> None:
    for required in (STRUCT_ALPL, STRUCT_PLAU, LIG_ALPL, LIG_PLAU, PFOS, ADT_PYTHON, PREP_RECEPTOR):
        if not required.exists():
            raise FileNotFoundError(required)
    for directory in ("prepared/receptors/dry", "prepared/receptors/wet", "prepared/native_ligands", "configs", "logs"):
        (OUT / directory).mkdir(parents=True, exist_ok=True)

    cases = {
        "ALPL_9SH5": {
            "pdb": "9SH5", "chain": "A", "native": "A1JNY",
            "mol": alpl_bound_ligand(), "source_atoms": alpl_receptor_atoms(),
        },
        "PLAU_6NMB": {
            "pdb": "6NMB", "chain": "A", "native": "AMH A302",
            "mol": plau_bound_ligand(), "source_atoms": plau_receptor_atoms(),
        },
    }
    ligand_rows = []
    receptor_rows = []
    grids = {}
    for case, info in cases.items():
        mol = info["mol"]
        reference = OUT / f"prepared/native_ligands/{case}_native_bound_reference.sdf"
        writer = Chem.SDWriter(str(reference))
        writer.write(mol)
        writer.close()
        prepared = Chem.AddHs(mol, addCoords=True)
        prepared.SetProp("_Name", f"{case}_native_prepared")
        prepared_sdf = OUT / f"prepared/native_ligands/{case}_native_prepared.sdf"
        writer = Chem.SDWriter(str(prepared_sdf))
        writer.write(prepared)
        writer.close()
        pdbqt_text = meeko_text(prepared)
        prepared_pdbqt = OUT / f"prepared/native_ligands/{case}_native_prepared.pdbqt"
        prepared_pdbqt.write_text(pdbqt_text, encoding="ascii")

        protein, metals, waters = info["source_atoms"]
        xyz = ligand_coords(mol)
        local_waters = near_waters(waters, xyz)
        for condition, retained_waters in (("dry", []), ("wet", local_waters)):
            pdb = OUT / f"prepared/receptors/{condition}/{case}_{condition}.pdb"
            pdbqt = pdb.with_suffix(".pdbqt")
            write_receptor(pdb, protein, metals, retained_waters)
            prepare_receptor(pdb, pdbqt, condition, OUT / f"logs/receptor_{case}_{condition}.log")
            receptor_rows.append({
                "case": case, "PDB_ID": info["pdb"], "chain": info["chain"],
                "condition": condition, "protein_atom_count": len(protein),
                "retained_metals": ";".join(f"{a['resname']}:{a['resseq']}" for a in metals) or "none",
                "retained_water_oxygen_count": len(retained_waters),
                "prepared_pdb": pdb.relative_to(OUT).as_posix(),
                "prepared_pdbqt": pdbqt.relative_to(OUT).as_posix(),
            })
        grids[case] = grid(xyz, protein)
        grids[case].update({"PDB_ID": info["pdb"], "chain": info["chain"], "native_ligand": info["native"]})
        ligand_rows.append({
            "case": case, "native_ligand": info["native"],
            "heavy_atoms": mol.GetNumHeavyAtoms(), "formal_charge": Chem.GetFormalCharge(prepared),
            "pdbqt_partial_charge_sum": round(pdbqt_charge(pdbqt_text), 4),
            "bound_reference_sdf": reference.relative_to(OUT).as_posix(),
            "prepared_sdf": prepared_sdf.relative_to(OUT).as_posix(),
            "prepared_pdbqt": prepared_pdbqt.relative_to(OUT).as_posix(),
            "method": "Bound co-crystal coordinates plus CCD/PubChem topology; RDKit hydrogens; Meeko 0.8.0 PDBQT",
        })

    (OUT / "configs/all_grids.json").write_text(json.dumps(grids, indent=2) + "\n", encoding="utf-8")
    write_csv(OUT / "logs/native_ligand_preparation.csv", ligand_rows)
    write_csv(OUT / "logs/receptor_preparation.csv", receptor_rows)
    checksum_rows = []
    for path in (STRUCT_ALPL, STRUCT_PLAU, LIG_ALPL, LIG_PLAU, PFOS):
        checksum_rows.append({"file": str(path), "sha256": sha256(path), "bytes": path.stat().st_size})
    write_csv(OUT / "logs/input_checksums.csv", checksum_rows)
    print(json.dumps({"status": "prepared", "output": str(OUT), "grids": grids}, indent=2))


if __name__ == "__main__":
    main()
