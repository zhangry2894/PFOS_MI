from __future__ import annotations

import csv
import itertools
import json
import math
import statistics
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
from scipy.optimize import linear_sum_assignment
from rdkit import Chem


OUT = Path(sys.argv[1]).resolve()
OBABEL = Path(sys.argv[2]).resolve()
MANIFEST = OUT / "logs/docking_job_manifest.csv"


def read_csv(path: Path) -> list[dict]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def parse_pdbqt_models(path: Path) -> list[dict]:
    models = []
    current = None
    score = None
    for line in path.read_text(encoding="ascii", errors="replace").splitlines():
        if line.startswith("MODEL"):
            current, score = [], None
        elif line.startswith("REMARK VINA RESULT:"):
            score = float(line.split()[3])
        elif line.startswith(("ATOM  ", "HETATM")):
            if current is None:
                current = []
            atom_type = line[77:].strip().upper()
            if atom_type == "A":
                element = "C"
            elif atom_type.startswith("CL"):
                element = "CL"
            elif atom_type.startswith("BR"):
                element = "BR"
            elif atom_type.startswith("H"):
                element = "H"
            else:
                element = atom_type[:1]
            current.append({
                "x": float(line[30:38]), "y": float(line[38:46]), "z": float(line[46:54]),
                "element": element, "resname": line[17:20].strip(),
                "chain": line[21:22], "resseq": line[22:26].strip(),
            })
        elif line.startswith("ENDMDL") and current is not None:
            models.append({"score": score, "atoms": current})
            current = None
    if current:
        models.append({"score": score, "atoms": current})
    return models


def convert_pdbqt_to_sdf(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    command = [str(OBABEL), "-ipdbqt", str(source), "-osdf", "-O", str(target), "-d"]
    run = subprocess.run(command, capture_output=True, text=True)
    if run.returncode != 0:
        raise RuntimeError(f"Open Babel conversion failed for {source}: {run.stderr}")


def mols_from_sdf(path: Path) -> list[Chem.Mol]:
    return [m for m in Chem.SDMolSupplier(str(path), removeHs=True) if m is not None]


def raw_graph_symmetry_rmsd(reference: Chem.Mol, pose: Chem.Mol) -> tuple[float, str]:
    """RMSD in the fixed receptor frame; ligand superposition is not performed."""
    ref = Chem.RemoveHs(reference)
    mobile = Chem.RemoveHs(pose)
    ref_coords = np.asarray(ref.GetConformer().GetPositions(), dtype=float)
    mobile_coords = np.asarray(mobile.GetConformer().GetPositions(), dtype=float)
    matches = mobile.GetSubstructMatches(ref, uniquify=False, maxMatches=100000)
    best = math.inf
    for match in matches:
        if len(match) != ref.GetNumAtoms():
            continue
        value = float(np.sqrt(np.mean(np.sum((ref_coords - mobile_coords[np.asarray(match)]) ** 2, axis=1))))
        best = min(best, value)
    if math.isfinite(best):
        return best, "graph_symmetry_raw_RMSD_no_ligand_superposition"
    # Fallback preserves the receptor coordinate frame and permits only element-wise assignment.
    ref_elements = [a.GetSymbol().upper() for a in ref.GetAtoms()]
    mob_elements = [a.GetSymbol().upper() for a in mobile.GetAtoms()]
    if sorted(ref_elements) != sorted(mob_elements):
        raise RuntimeError("Reference/pose element counts differ")
    squared = 0.0
    count = 0
    for element in sorted(set(ref_elements)):
        ri = [i for i, e in enumerate(ref_elements) if e == element]
        mi = [i for i, e in enumerate(mob_elements) if e == element]
        cost = np.sum((ref_coords[ri, None, :] - mobile_coords[None, mi, :]) ** 2, axis=2)
        row, col = linear_sum_assignment(cost)
        squared += float(cost[row, col].sum())
        count += len(row)
    return math.sqrt(squared / count), "element_assignment_raw_RMSD_no_ligand_superposition"


def raw_element_rmsd(atoms_a: list[dict], atoms_b: list[dict]) -> float:
    a = [x for x in atoms_a if x["element"] != "H"]
    b = [x for x in atoms_b if x["element"] != "H"]
    ea, eb = [x["element"] for x in a], [x["element"] for x in b]
    if sorted(ea) != sorted(eb):
        return math.nan
    ca = np.asarray([[x["x"], x["y"], x["z"]] for x in a])
    cb = np.asarray([[x["x"], x["y"], x["z"]] for x in b])
    squared = 0.0
    count = 0
    for element in sorted(set(ea)):
        ai = [i for i, e in enumerate(ea) if e == element]
        bi = [i for i, e in enumerate(eb) if e == element]
        cost = np.sum((ca[ai, None, :] - cb[None, bi, :]) ** 2, axis=2)
        row, col = linear_sum_assignment(cost)
        squared += float(cost[row, col].sum())
        count += len(row)
    return math.sqrt(squared / count)


def validation(rows: list[dict], analysis_name: str = "native_ligand_redocking",
               output_stem: str = "native_redocking") -> tuple[list[dict], list[dict]]:
    detail = []
    for job in rows:
        if job["analysis"] != analysis_name:
            continue
        case = job["case"]
        reference_path = OUT / f"prepared/native_ligands/{case}_native_bound_reference.sdf"
        reference = mols_from_sdf(reference_path)[0]
        pose_path = OUT / f"analysis/{output_stem}_sdf/{case}_seed{job['seed']}.sdf"
        convert_pdbqt_to_sdf(Path(job["output"]), pose_path)
        poses = mols_from_sdf(pose_path)
        models = parse_pdbqt_models(Path(job["output"]))
        for rank, (pose, model) in enumerate(zip(poses, models), 1):
            rmsd, method = raw_graph_symmetry_rmsd(reference, pose)
            detail.append({
                "case": case, "seed": int(job["seed"]), "rank": rank,
                "affinity_kcal_mol": model["score"], "raw_symmetry_corrected_heavy_atom_RMSD_A": round(rmsd, 4),
                "method": method,
            })
    write_csv(OUT / f"analysis/{output_stem}_pose_RMSD.csv", detail)
    summary = []
    for case in sorted({row["case"] for row in detail}):
        case_rows = [row for row in detail if row["case"] == case]
        seeds = sorted({row["seed"] for row in case_rows})
        top = [next(row for row in case_rows if row["seed"] == seed and row["rank"] == 1)["raw_symmetry_corrected_heavy_atom_RMSD_A"] for seed in seeds]
        best = [min(row["raw_symmetry_corrected_heavy_atom_RMSD_A"] for row in case_rows if row["seed"] == seed) for seed in seeds]
        passed = sum(value <= 2.0 for value in top)
        summary.append({
            "case": case, "n_seeds": len(seeds),
            "criterion": "top-ranked raw symmetry-corrected heavy-atom RMSD <=2.0 A in fixed receptor frame",
            "top_pose_RMSD_mean_A": round(statistics.mean(top), 3),
            "top_pose_RMSD_sd_A": round(statistics.stdev(top), 3),
            "top_pose_RMSD_range_A": f"{min(top):.3f}-{max(top):.3f}",
            "best_available_pose_RMSD_mean_A": round(statistics.mean(best), 3),
            "top_pose_pass_seeds": f"{passed}/{len(seeds)}",
            "validation_status": "PASS" if passed == len(seeds) else "FAIL",
        })
    write_csv(OUT / f"results/{output_stem}_summary.csv", summary)
    return detail, summary


def score_summaries(rows: list[dict], validation_summary: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    relevant = [row for row in rows if row["analysis"] in {"PFOS_docking", "negative_surface_control"}]
    detail = []
    for row in relevant:
        detail.append({
            "case": row["case"], "condition": row["condition"], "seed": int(row["seed"]),
            "best_affinity_kcal_mol": float(row["best_affinity_kcal_mol"]),
            "output": row["output"], "config": row["config"],
        })
    write_csv(OUT / "results/PFOS_seed_results.csv", detail)
    status = {row["case"]: row["validation_status"] for row in validation_summary}
    summaries = []
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in detail:
        grouped[(row["case"], row["condition"])].append(row)
    for (case, condition), group in sorted(grouped.items()):
        values = [row["best_affinity_kcal_mol"] for row in group]
        summaries.append({
            "case": case, "condition": condition, "n_seeds": len(values),
            "mean_best_affinity_kcal_mol": round(statistics.mean(values), 3),
            "sd_best_affinity_kcal_mol": round(statistics.stdev(values), 3),
            "range_kcal_mol": f"{min(values):.3f} to {max(values):.3f}",
            "native_redocking_status": status.get(case, "not applicable"),
        })
    write_csv(OUT / "results/PFOS_docking_summary_by_condition.csv", summaries)
    comparisons = []
    for case in sorted({row["case"] for row in detail}):
        means = {row["condition"]: row["mean_best_affinity_kcal_mol"] for row in summaries if row["case"] == case}
        comparisons.append({
            "case": case, "dry_mean_kcal_mol": means["dry"], "wet_mean_kcal_mol": means["wet"],
            "surface_mean_kcal_mol": means["surface"],
            "wet_minus_dry_kcal_mol": round(means["wet"] - means["dry"], 3),
            "surface_minus_dry_kcal_mol": round(means["surface"] - means["dry"], 3),
            "native_redocking_status": status.get(case, ""),
            "interpretation": "Vina scoring-function comparison; not experimental affinity or specificity",
        })
    write_csv(OUT / "results/PFOS_docking_controls_comparison.csv", comparisons)
    return detail, summaries, comparisons


def repeatability(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        if row["analysis"] not in {"PFOS_docking", "negative_surface_control"}:
            continue
        grouped[(row["case"], row["condition"])].append(row)
    output = []
    for (case, condition), group in sorted(grouped.items()):
        tops = [(int(row["seed"]), parse_pdbqt_models(Path(row["output"]))[0]["atoms"]) for row in group]
        pairs = [(a, b, raw_element_rmsd(coords_a, coords_b)) for (a, coords_a), (b, coords_b) in itertools.combinations(sorted(tops), 2)]
        values = [item[2] for item in pairs]
        output.append({
            "case": case, "condition": condition, "n_seed_pairs": len(values),
            "top_pose_pairwise_RMSD_mean_A": round(statistics.mean(values), 3),
            "top_pose_pairwise_RMSD_max_A": round(max(values), 3),
            "all_pairs_le_2A": "YES" if max(values) <= 2.0 else "NO",
            "pairwise_values": ";".join(f"{a}-{b}:{value:.3f}" for a, b, value in pairs),
        })
    write_csv(OUT / "results/PFOS_top_pose_seed_repeatability.csv", output)
    return output


def receptor_atoms(path: Path) -> list[dict]:
    atoms = []
    for line in path.read_text(encoding="ascii", errors="replace").splitlines():
        if not line.startswith(("ATOM  ", "HETATM")):
            continue
        atom_type = line[77:].strip().upper()
        if atom_type.startswith("H"):
            continue
        atoms.append({
            "x": float(line[30:38]), "y": float(line[38:46]), "z": float(line[46:54]),
            "resname": line[17:20].strip(), "chain": line[21:22], "resseq": line[22:26].strip(),
        })
    return atoms


def contacts(rows: list[dict]) -> list[dict]:
    hit_count: dict[tuple, int] = defaultdict(int)
    min_distances: dict[tuple, list[float]] = defaultdict(list)
    run_count: dict[tuple[str, str], int] = defaultdict(int)
    for row in rows:
        if row["analysis"] != "PFOS_docking":
            continue
        case, condition = row["case"], row["condition"]
        run_count[(case, condition)] += 1
        ligand = [a for a in parse_pdbqt_models(Path(row["output"]))[0]["atoms"] if a["element"] != "H"]
        ligand_xyz = np.asarray([[a["x"], a["y"], a["z"]] for a in ligand])
        residues: dict[tuple[str, str, str], list[dict]] = defaultdict(list)
        for atom in receptor_atoms(Path(row["receptor"])):
            residues[(atom["resname"], atom["chain"], atom["resseq"])].append(atom)
        for residue, atoms in residues.items():
            coords = np.asarray([[a["x"], a["y"], a["z"]] for a in atoms])
            distance = float(np.min(np.linalg.norm(coords[:, None, :] - ligand_xyz[None, :, :], axis=2)))
            if distance <= 4.0:
                key = (case, condition) + residue
                hit_count[key] += 1
                min_distances[key].append(distance)
    output = []
    for key, count in sorted(hit_count.items()):
        case, condition, resname, chain, resseq = key
        n = run_count[(case, condition)]
        output.append({
            "case": case, "condition": condition, "residue": f"{resname}:{chain}:{resseq}",
            "contact_cutoff_A": 4.0, "seed_contact_count": count, "n_seeds": n,
            "contact_frequency": round(count / n, 3),
            "mean_min_distance_A": round(statistics.mean(min_distances[key]), 3),
        })
    write_csv(OUT / "results/PFOS_residue_contacts_all.csv", output)
    write_csv(OUT / "results/PFOS_residue_contacts_consensus.csv", [row for row in output if row["contact_frequency"] >= 0.667])
    return output


def configuration_summary(rows: list[dict]) -> list[dict]:
    keys = ["case", "analysis", "condition", "center_x", "center_y", "center_z", "size_x", "size_y", "size_z",
            "exhaustiveness", "num_modes", "energy_range_kcal_mol", "cpu"]
    seen = set()
    output = []
    for row in rows:
        signature = tuple(row[key] for key in keys)
        if signature in seen:
            continue
        seen.add(signature)
        output.append({key: row[key] for key in keys})
    write_csv(OUT / "results/docking_configuration_summary.csv", output)
    return output


def main() -> None:
    rows = read_csv(MANIFEST)
    configs = configuration_summary(rows)
    detail, val_summary = validation(rows)
    focused_manifest = OUT / "logs/focused_native_redocking_manifest.csv"
    focused_summary = []
    if focused_manifest.exists():
        _, focused_summary = validation(
            read_csv(focused_manifest),
            analysis_name="focused_native_redocking_sensitivity",
            output_stem="focused_native_redocking",
        )
    seed_results, score_summary, comparisons = score_summaries(rows, val_summary)
    repeat = repeatability(rows)
    contact_rows = contacts(rows)
    payload = {
        "native_redocking": val_summary,
        "focused_native_redocking_sensitivity": focused_summary,
        "PFOS_controls": comparisons,
        "pose_repeatability": repeat,
        "consensus_contact_count": sum(row["contact_frequency"] >= 0.667 for row in contact_rows),
        "parameters": {"vina": "1.2.7", "seeds": [20260920, 20260921, 20260922],
                       "exhaustiveness": 16, "num_modes": 20, "energy_range_kcal_mol": 5, "cpu": 4},
        "interpretation_boundary": "Docking scores and poses support modeled pocket compatibility only; they do not establish affinity, specificity, target engagement, inhibition, or functional effects.",
    }
    (OUT / "results/docking_results_summary.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
