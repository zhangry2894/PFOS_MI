from __future__ import annotations

import csv
import json
import re
import subprocess
import sys
import time
from pathlib import Path


OUT = Path(sys.argv[1]).resolve()
VINA = Path(sys.argv[2]).resolve()
PFOS = Path(sys.argv[3]).resolve()

SEEDS = [20260920, 20260921, 20260922]
EXHAUSTIVENESS = 16
NUM_MODES = 20
ENERGY_RANGE = 5
CPU = 4


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def best_score(text: str) -> float | None:
    for line in text.splitlines():
        match = re.match(r"^\s*1\s+(-?\d+(?:\.\d+)?)\s+", line)
        if match:
            return float(match.group(1))
    return None


def complete(path: Path) -> bool:
    if not path.exists() or path.stat().st_size < 500:
        return False
    text = path.read_text(encoding="ascii", errors="replace")
    return "REMARK VINA RESULT:" in text and "MODEL 1" in text


def make_config(job: dict) -> str:
    center, size = job["center"], job["size"]
    return "\n".join([
        f"receptor = {job['receptor']}", f"ligand = {job['ligand']}",
        f"center_x = {center['x']}", f"center_y = {center['y']}", f"center_z = {center['z']}",
        f"size_x = {size['x']}", f"size_y = {size['y']}", f"size_z = {size['z']}",
        f"exhaustiveness = {EXHAUSTIVENESS}", f"num_modes = {NUM_MODES}",
        f"energy_range = {ENERGY_RANGE}", f"seed = {job['seed']}", f"cpu = {CPU}",
        f"out = {job['output']}", "verbosity = 1", "",
    ])


def main() -> None:
    grids = json.loads((OUT / "configs/all_grids.json").read_text(encoding="utf-8"))
    jobs = []
    for case in sorted(grids):
        grid = grids[case]
        native = OUT / f"prepared/native_ligands/{case}_native_prepared.pdbqt"
        for seed in SEEDS:
            jobs.append({
                "analysis": "native_ligand_redocking", "case": case, "condition": "dry", "seed": seed,
                "receptor": OUT / f"prepared/receptors/dry/{case}_dry.pdbqt", "ligand": native,
                "center": grid["center"], "size": grid["size"],
                "output": OUT / f"validation/native_redocking/{case}/seed_{seed}.pdbqt",
            })
        for condition in ("dry", "wet"):
            for seed in SEEDS:
                jobs.append({
                    "analysis": "PFOS_docking", "case": case, "condition": condition, "seed": seed,
                    "receptor": OUT / f"prepared/receptors/{condition}/{case}_{condition}.pdbqt", "ligand": PFOS,
                    "center": grid["center"], "size": grid["size"],
                    "output": OUT / f"pfos_docking/{case}/{condition}/seed_{seed}.pdbqt",
                })
        for seed in SEEDS:
            jobs.append({
                "analysis": "negative_surface_control", "case": case, "condition": "surface", "seed": seed,
                "receptor": OUT / f"prepared/receptors/dry/{case}_dry.pdbqt", "ligand": PFOS,
                "center": grid["surface_control"]["center"], "size": grid["surface_control"]["size"],
                "output": OUT / f"controls/surface/{case}/seed_{seed}.pdbqt",
            })
    manifest = []
    print(f"Planned docking jobs: {len(jobs)}", flush=True)
    for index, job in enumerate(jobs, 1):
        job["output"].parent.mkdir(parents=True, exist_ok=True)
        config = OUT / f"configs/runs/{job['analysis']}/{job['case']}_{job['condition']}_seed{job['seed']}.txt"
        log = OUT / f"logs/docking/{job['analysis']}/{job['case']}_{job['condition']}_seed{job['seed']}.log"
        config.parent.mkdir(parents=True, exist_ok=True)
        log.parent.mkdir(parents=True, exist_ok=True)
        config.write_text(make_config(job), encoding="utf-8")
        started = time.time()
        if complete(job["output"]):
            status, code = "SKIPPED_COMPLETE", 0
            text = log.read_text(encoding="utf-8", errors="replace") if log.exists() else ""
        else:
            print(f"[{index}/{len(jobs)}] {job['analysis']} {job['case']} {job['condition']} seed={job['seed']}", flush=True)
            run = subprocess.run([str(VINA), "--config", str(config)], capture_output=True, text=True)
            code = run.returncode
            text = run.stdout
            log.write_text("STDOUT\n" + run.stdout + "\nSTDERR\n" + run.stderr, encoding="utf-8")
            status = "COMPLETED" if code == 0 and complete(job["output"]) else "FAILED"
            if status == "FAILED":
                raise RuntimeError(f"Docking failed at job {index}; see {log}")
        center, size = job["center"], job["size"]
        manifest.append({
            "job_index": index, "analysis": job["analysis"], "case": job["case"],
            "condition": job["condition"], "seed": job["seed"], "status": status,
            "center_x": center["x"], "center_y": center["y"], "center_z": center["z"],
            "size_x": size["x"], "size_y": size["y"], "size_z": size["z"],
            "exhaustiveness": EXHAUSTIVENESS, "num_modes": NUM_MODES,
            "energy_range_kcal_mol": ENERGY_RANGE, "cpu": CPU,
            "best_affinity_kcal_mol": best_score(text),
            "runtime_seconds": round(time.time() - started, 3),
            "receptor": str(job["receptor"]), "ligand": str(job["ligand"]),
            "output": str(job["output"]), "config": str(config), "log": str(log),
        })
        write_csv(OUT / "logs/docking_job_manifest.csv", manifest)
    print(json.dumps({"status": "complete", "jobs": len(manifest), "manifest": str(OUT / 'logs/docking_job_manifest.csv')}, indent=2))


if __name__ == "__main__":
    main()
