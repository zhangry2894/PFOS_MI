#!/usr/bin/env Rscript

suppressPackageStartupMessages(library(magick))
suppressPackageStartupMessages(library(grid))

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) {
  stop("Usage: Rscript build_docking_figure4.R <input_dir> <output_dir>")
}

input_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
output_dir <- normalizePath(args[[2]], winslash = "/", mustWork = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

required <- c("ALPL_3D.png", "ALPL_2D.png", "PLAU_3D.png", "PLAU_2D.png")
paths <- file.path(input_dir, required)
if (!all(file.exists(paths))) {
  stop("Missing source image(s): ", paste(required[!file.exists(paths)], collapse = ", "))
}

# PLOS ONE full-width raster contract at 300 dpi: <=2250 px wide and <=2625 px high.
canvas_w <- 2250L
margin_x <- 40L
gap_x <- 30L
left_w <- 1480L
right_w <- canvas_w - (2L * margin_x) - gap_x - left_w
header_h <- 74L
note_h <- 48L
row_gap <- 34L

prepare_3d <- function(path, width) {
  image_read(path) |>
    image_background("white", flatten = TRUE) |>
    image_resize(paste0(width, "x")) |>
    image_convert(colorspace = "sRGB", depth = 8)
}

prepare_2d <- function(path, target, width) {
  img <- image_read(path) |> image_background("white", flatten = TRUE)
  info <- image_info(img)
  if (target == "ALPL") {
    # Remove only the empty upper margin; retain the complete diagram and legend.
    img <- image_crop(img, geometry_area(info$width, info$height - 360L, 0L, 360L), repage = TRUE)
  } else {
    img <- image_crop(img, geometry_area(info$width, info$height - 170L, 0L, 170L), repage = TRUE)
  }
  img |>
    image_resize(paste0(width, "x")) |>
    image_convert(colorspace = "sRGB", depth = 8)
}

alpl_3d <- prepare_3d(paths[[1]], left_w)
alpl_2d <- prepare_2d(paths[[2]], "ALPL", right_w)
plau_3d <- prepare_3d(paths[[3]], left_w)
plau_2d <- prepare_2d(paths[[4]], "PLAU", right_w)

row_height <- function(a, b) max(image_info(a)$height, image_info(b)$height)
row1_h <- row_height(alpl_3d, alpl_2d)
row2_h <- row_height(plau_3d, plau_2d)
canvas_h <- header_h + row1_h + note_h + row_gap + header_h + row2_h + note_h + 25L
if (canvas_h > 2625L) stop("Figure exceeds the PLOS ONE height limit: ", canvas_h, " px")

place_center_y <- function(img, x, y_top, row_h) {
  ih <- image_info(img)$height
  y <- y_top + as.integer((row_h - ih) / 2)
  list(img = img, x = x, y = y, w = image_info(img)$width, h = ih)
}

# Row 1
y1 <- header_h
p_a <- place_center_y(alpl_3d, margin_x, y1, row1_h)
p_b <- place_center_y(alpl_2d, margin_x + left_w + gap_x, y1, row1_h)

# Row 2
header2_y <- header_h + row1_h + note_h + row_gap
y2 <- header2_y + header_h
p_c <- place_center_y(plau_3d, margin_x, y2, row2_h)
p_d <- place_center_y(plau_2d, margin_x + left_w + gap_x, y2, row2_h)

right_x <- margin_x + left_w + gap_x

draw_panel <- function(p) {
  grid.raster(
    as.raster(p$img),
    x = unit((p$x + p$w / 2) / canvas_w, "npc"),
    y = unit(1 - (p$y + p$h / 2) / canvas_h, "npc"),
    width = unit(p$w / canvas_w, "npc"),
    height = unit(p$h / canvas_h, "npc"),
    interpolate = TRUE
  )
}

draw_text <- function(label, x_px, y_px, fontsize = 9, bold = FALSE) {
  grid.text(
    label,
    x = unit(x_px / canvas_w, "npc"),
    y = unit(1 - y_px / canvas_h, "npc"),
    just = c("left", "top"),
    gp = gpar(fontfamily = "Arial", fontsize = fontsize, fontface = if (bold) "bold" else "plain", col = "black")
  )
}

draw_figure <- function() {
  grid.newpage()
  grid.rect(gp = gpar(fill = "white", col = NA))
  draw_panel(p_a); draw_panel(p_b); draw_panel(p_c); draw_panel(p_d)
  draw_text("A", 12, 12, fontsize = 10, bold = TRUE)
  draw_text("ALPL / 9SH5  |  3D pocket view", margin_x + 35L, 16, fontsize = 9, bold = TRUE)
  draw_text("B", right_x - 4L, 12, fontsize = 10, bold = TRUE)
  draw_text("ALPL / 9SH5  |  2D interaction map", right_x + 38L, 16, fontsize = 9, bold = TRUE)
  draw_text(
    "3/3-seed contacts, mean minimum distance (Angstrom): Zn602 2.35; Ser110 2.83; Arg184 2.88; His341 3.03.",
    margin_x, header_h + row1_h + 8L, fontsize = 8, bold = FALSE
  )
  draw_text("C", 12, header2_y + 12L, fontsize = 10, bold = TRUE)
  draw_text("PLAU / 6NMB  |  3D pocket view", margin_x + 35L, header2_y + 16L, fontsize = 9, bold = TRUE)
  draw_text("D", right_x - 4L, header2_y + 12L, fontsize = 10, bold = TRUE)
  draw_text("PLAU / 6NMB  |  2D interaction map", right_x + 38L, header2_y + 16L, fontsize = 9, bold = TRUE)
  draw_text(
    "3/3-seed contacts, mean minimum distance (Angstrom): Ser190 2.80; Ser195 3.01; Gly216 3.09; Cys191 3.11; Trp215 3.11.",
    margin_x, header2_y + header_h + row2_h + 8L, fontsize = 8, bold = FALSE
  )
}

width_in <- canvas_w / 300
height_in <- canvas_h / 300

ragg::agg_png(file.path(output_dir, "Fig4.png"), width = width_in, height = height_in,
              units = "in", res = 300, background = "white", scaling = 1)
draw_figure()
dev.off()

ragg::agg_tiff(file.path(output_dir, "Fig4.tif"), width = width_in, height = height_in,
               units = "in", res = 300, background = "white", scaling = 1,
               compression = "lzw", bitsize = 8)
draw_figure()
dev.off()

grDevices::cairo_pdf(file.path(output_dir, "Fig4.pdf"), width = width_in, height = height_in,
                     family = "Arial", bg = "white", fallback_resolution = 300)
draw_figure()
dev.off()

svglite::svglite(file.path(output_dir, "Fig4.svg"), width = width_in, height = height_in,
                 bg = "white", pointsize = 12)
draw_figure()
dev.off()

qa <- data.frame(
  item = c("core_conclusion", "archetype", "source_images", "crop_policy", "pixel_dimensions", "density", "alpha_channel", "contact_distance_note", "interpretation_boundary"),
  value = c(
    "Representative selected PFOS poses can be inspected for ALPL and PLAU without replacing quantitative docking controls.",
    "image plate",
    paste(required, collapse = "; "),
    "Only empty upper margins of the 2D exports were cropped; molecular diagrams, labels, and legends were retained.",
    paste0(canvas_w, " x ", canvas_h),
    "300 dpi",
    "none after white-background flattening",
    "Displayed distances are descriptive means of the minimum distance across three seed-specific top-ranked poses; contact frequency is 3/3 and no inferential interval is implied.",
    "Exploratory pose visualization only; not evidence of binding, affinity, inhibition, or functional modulation."
  ),
  stringsAsFactors = FALSE
)
write.csv(qa, file.path(output_dir, "Fig4_QA.csv"), row.names = FALSE, fileEncoding = "UTF-8")

cat(sprintf("Created Fig4 at %d x %d pixels (300 dpi).\n", canvas_w, canvas_h))
