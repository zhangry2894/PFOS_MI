from __future__ import annotations

import csv
import json
import re
import subprocess
import sys
from pathlib import Path


OUT = Path(sys.argv[1]).resolve()
VINA = Path(sys.argv[2]).resolve()
SEEDS = [20260920, 20260921, 20260922]


def score(text: str) -> float | None:
    for line in text.splitlines():
        match = re.match(r"^\s*1\s+(-?\d+(?:\.\d+)?)\s+", line)
        if match:
            return float(match.group(1))
    return None


def main() -> None:
    grids = json.loads((OUT / "configs/all_grids.json").read_text(encoding="utf-8"))
    rows = []
    for case, grid in sorted(grids.items()):
        size = {axis: round(max(18.0, float(grid["size"][axis]) - 6.0), 3) for axis in "xyz"}
        for seed in SEEDS:
            receptor = OUT / f"prepared/receptors/dry/{case}_dry.pdbqt"
            ligand = OUT / f"prepared/native_ligands/{case}_native_prepared.pdbqt"
            output = OUT / f"validation/focused_native_redocking/{case}/seed_{seed}.pdbqt"
            config = OUT / f"configs/focused_native_redocking/{case}_seed{seed}.txt"
            log = OUT / f"logs/focused_native_redocking/{case}_seed{seed}.log"
            for path in (output.parent, config.parent, log.parent):
                path.mkdir(parents=True, exist_ok=True)
            center = grid["center"]
            config.write_text("\n".join([
                f"receptor = {receptor}", f"ligand = {ligand}",
                f"center_x = {center['x']}", f"center_y = {center['y']}", f"center_z = {center['z']}",
                f"size_x = {size['x']}", f"size_y = {size['y']}", f"size_z = {size['z']}",
                "exhaustiveness = 64", "num_modes = 40", "energy_range = 10",
                f"seed = {seed}", "cpu = 4", f"out = {output}", "verbosity = 1", "",
            ]), encoding="utf-8")
            print(f"focused redocking {case} seed={seed}", flush=True)
            run = subprocess.run([str(VINA), "--config", str(config)], capture_output=True, text=True)
            log.write_text("STDOUT\n" + run.stdout + "\nSTDERR\n" + run.stderr, encoding="utf-8")
            if run.returncode != 0:
                raise RuntimeError(f"Focused redocking failed; see {log}")
            rows.append({
                "analysis": "focused_native_redocking_sensitivity", "case": case, "condition": "dry",
                "seed": seed, "center_x": center["x"], "center_y": center["y"], "center_z": center["z"],
                "size_x": size["x"], "size_y": size["y"], "size_z": size["z"],
                "exhaustiveness": 64, "num_modes": 40, "energy_range_kcal_mol": 10, "cpu": 4,
                "best_affinity_kcal_mol": score(run.stdout), "receptor": str(receptor),
                "ligand": str(ligand), "output": str(output), "config": str(config), "log": str(log),
            })
    path = OUT / "logs/focused_native_redocking_manifest.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"status": "complete", "jobs": len(rows), "manifest": str(path)}, indent=2))


if __name__ == "__main__":
    main()
