#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(pROC)
  library(dplyr)
  library(tidyr)
  library(svglite)
  library(ragg)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("Usage: Rscript make_alpl_plau_figures.R <tmp1> <docking_output> <figure_output>")
ml_root <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
dock_root <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[3]], winslash = "/", mustWork = FALSE)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

# Figure contracts
# Fig. 2: an internally selected two-gene panel retains moderate discrimination
# in the untouched external cohort, while single-gene external FDR support is absent.
# Fig. 3: PFOS poses favor co-crystal-defined pockets over remote surface boxes,
# but failure of top-ranked native redocking restricts interpretation to exploration.

pal <- c(
  dark = "#20252B", grey = "#8A949E", light = "#E7EBEF",
  blue = "#3978A8", teal = "#2A9D8F", orange = "#D98C3F", red = "#C8564F"
)

theme_pub <- function() {
  theme_classic(base_size = 6.8, base_family = "Arial") +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.title = element_text(size = 6.8),
      axis.text = element_text(size = 6.2, colour = "black"),
      legend.title = element_text(size = 6.4),
      legend.text = element_text(size = 6.0),
      strip.text = element_text(size = 6.5, face = "bold"),
      plot.title = element_text(size = 7.2, face = "bold"),
      plot.tag = element_text(size = 8.0, face = "bold"),
      panel.grid = element_blank(),
      plot.margin = margin(3, 4, 3, 4)
    )
}
theme_set(theme_pub())

save_bundle <- function(plot, stem, width_mm = 183, height_mm = 145) {
  width_in <- width_mm / 25.4
  height_in <- height_mm / 25.4
  svglite::svglite(paste0(stem, ".svg"), width = width_in, height = height_in)
  print(plot)
  dev.off()
  grDevices::cairo_pdf(paste0(stem, ".pdf"), width = width_in, height = height_in, family = "Arial")
  print(plot)
  dev.off()
  ragg::agg_tiff(paste0(stem, ".tif"), width = width_in, height = height_in,
                 units = "in", res = 600, compression = "lzw")
  print(plot)
  dev.off()
  ragg::agg_png(paste0(stem, ".png"), width = width_in, height = height_in,
               units = "in", res = 300)
  print(plot)
  dev.off()
}

# ------------------------------ Figure 2 ------------------------------
membership <- read.csv(file.path(ml_root, "04_results", "strict_four_algorithm", "four_algorithm_membership_all_candidates.csv"), check.names = FALSE)
vote_pool <- membership[membership$n_algorithms >= 2, c("gene", "LASSO", "SVM_RFE", "Boruta", "XGBoost", "n_algorithms")]
vote_pool <- vote_pool[order(vote_pool$n_algorithms, vote_pool$gene), ]
vote_pool$gene <- factor(vote_pool$gene, levels = vote_pool$gene)
membership_long <- pivot_longer(vote_pool, cols = c("LASSO", "SVM_RFE", "Boruta", "XGBoost"),
                                names_to = "Algorithm", values_to = "Selected")
membership_long$Algorithm <- factor(membership_long$Algorithm,
                                    levels = c("LASSO", "SVM_RFE", "Boruta", "XGBoost"),
                                    labels = c("LASSO", "SVM-RFE", "Boruta", "XGBoost"))
p2a <- ggplot(membership_long, aes(Algorithm, gene, fill = factor(Selected))) +
  geom_tile(colour = "white", linewidth = 0.6) +
  geom_text(aes(label = ifelse(Selected == 1, "x", "")), size = 2.2, colour = "white") +
  scale_fill_manual(values = c("0" = pal[["light"]], "1" = pal[["teal"]]), guide = "none") +
  labs(title = "Seven-gene vote pool", x = NULL, y = NULL) +
  theme(axis.text.x = element_text(angle = 35, hjust = 1), axis.ticks = element_blank(), axis.line = element_blank())

best_size <- read.csv(file.path(ml_root, "compact7_analysis", "results", "best_internal_subset_by_gene_count.csv"), check.names = FALSE)
auc_size <- bind_rows(
  transmute(best_size, n_genes, Cohort = "GSE66360 combination-selection", AUC = ROC_AUC_internal,
            low = AUC_CI_low_internal, high = AUC_CI_high_internal),
  transmute(best_size, n_genes, Cohort = "GSE48060 external", AUC = ROC_AUC_external,
            low = AUC_CI_low_external, high = AUC_CI_high_external)
)
p2b <- ggplot(auc_size, aes(n_genes, AUC, colour = Cohort, group = Cohort)) +
  geom_hline(yintercept = 0.5, linetype = 2, linewidth = 0.35, colour = pal[["grey"]]) +
  geom_errorbar(aes(ymin = low, ymax = high), width = 0.12, linewidth = 0.45) +
  geom_line(linewidth = 0.65) + geom_point(size = 1.8) +
  geom_point(data = subset(auc_size, n_genes == 2), size = 3.0, shape = 21, stroke = 0.8, fill = "white") +
  scale_colour_manual(values = c("GSE66360 combination-selection" = pal[["blue"]], "GSE48060 external" = pal[["orange"]])) +
  scale_x_continuous(breaks = 2:7) + scale_y_continuous(limits = c(0.35, 1.01), breaks = seq(0.4, 1.0, 0.2)) +
  labs(title = "Best internally selected panel by size", x = "Panel size (genes)", y = "ROC AUC (95% CI)", colour = NULL) +
  theme(legend.position = "bottom")

pred <- read.csv(file.path(ml_root, "compact7_analysis", "results", "all_120_subset_predictions.csv"), check.names = FALSE)
pred <- pred[pred$subset_id == "S021", ]
roc_rows <- lapply(split(pred, pred$cohort), function(d) {
  roc_object <- pROC::roc(d$truth, d$probability_MI, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  label <- if (unique(d$cohort) == "GSE66360_predefined_validation") "GSE66360 combination-selection" else "GSE48060 external"
  data.frame(FPR = 1 - roc_object$specificities, Sensitivity = roc_object$sensitivities, Cohort = label)
})
roc_df <- bind_rows(roc_rows)
p2c <- ggplot(roc_df, aes(FPR, Sensitivity, colour = Cohort)) +
  geom_abline(slope = 1, intercept = 0, linetype = 2, linewidth = 0.35, colour = pal[["grey"]]) +
  geom_path(linewidth = 0.8) + coord_equal(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
  scale_colour_manual(values = c("GSE66360 combination-selection" = pal[["blue"]], "GSE48060 external" = pal[["orange"]])) +
  labs(title = "Locked ALPL + PLAU ridge score", x = "1 - specificity", y = "Sensitivity", colour = NULL) +
  theme(legend.position = "bottom")

limma <- read.csv(file.path(ml_root, "04_results", "limma_all_genes_all_cohorts.csv"), check.names = FALSE)
effect <- limma[limma$gene %in% c("ALPL", "PLAU") & limma$cohort %in% c("GSE66360_discovery", "GSE66360_validation", "GSE48060_external"), ]
effect$SE <- abs(effect$logFC / effect$t)
effect$low <- effect$logFC - 1.96 * effect$SE
effect$high <- effect$logFC + 1.96 * effect$SE
effect$Cohort <- factor(effect$cohort,
                        levels = c("GSE66360_discovery", "GSE66360_validation", "GSE48060_external"),
                        labels = c("GSE66360 discovery", "GSE66360 combination-selection", "GSE48060 external"))
effect$q_label <- paste0("q=", formatC(effect$adj.P.Val, digits = 2, format = "g"))
effect$Cohort_gene <- factor(
  paste(effect$Cohort, effect$gene, sep = " | "),
  levels = rev(c(
    "GSE66360 discovery | ALPL", "GSE66360 discovery | PLAU",
    "GSE66360 combination-selection | ALPL", "GSE66360 combination-selection | PLAU",
    "GSE48060 external | ALPL", "GSE48060 external | PLAU"
  ))
)
p2d <- ggplot(effect, aes(logFC, Cohort_gene, colour = gene)) +
  geom_vline(xintercept = 0, linewidth = 0.35, colour = pal[["grey"]]) +
  geom_errorbar(aes(xmin = low, xmax = high), width = 0.16, linewidth = 0.5, orientation = "y") +
  geom_point(size = 2.0) +
  geom_text(aes(label = q_label), x = 2.05, hjust = 1, size = 2.0, show.legend = FALSE) +
  scale_colour_manual(values = c("ALPL" = pal[["blue"]], "PLAU" = pal[["teal"]])) +
  scale_x_continuous(limits = c(-0.25, 2.1)) +
  labs(title = "Cohort-specific expression effects", x = "MI - control log2 fold change (95% CI)", y = NULL, colour = NULL) +
  theme(legend.position = "bottom")

fig2 <- ((p2a | p2b) / (p2c | p2d)) +
  plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(size = 8, face = "bold"))
save_bundle(fig2, file.path(out_dir, "Fig2"), width_mm = 183, height_mm = 150)

write.csv(membership_long, file.path(out_dir, "Fig2_source_algorithm_membership.csv"), row.names = FALSE)
write.csv(auc_size, file.path(out_dir, "Fig2_source_panel_size_auc.csv"), row.names = FALSE)
write.csv(pred, file.path(out_dir, "Fig2_source_selected_panel_predictions.csv"), row.names = FALSE)
write.csv(effect, file.path(out_dir, "Fig2_source_expression_effects.csv"), row.names = FALSE)

# ------------------------------ Figure 3 ------------------------------
primary_redock <- read.csv(file.path(dock_root, "results", "native_redocking_summary.csv"), check.names = FALSE,
                           fileEncoding = "UTF-8-BOM")
validation_plot <- transmute(
  primary_redock,
  Target = recode(case, "ALPL_9SH5" = "ALPL / 9SH5", "PLAU_6NMB" = "PLAU / 6NMB"),
  `Top-ranked pose` = top_pose_RMSD_mean_A,
  `Best available pose` = best_available_pose_RMSD_mean_A
) |>
  pivot_longer(cols = c("Top-ranked pose", "Best available pose"), names_to = "Pose", values_to = "RMSD")

hsa_path <- file.path(dock_root, "results", "HSA_PFOS_raw_redocking_RMSD.csv")
if (file.exists(hsa_path)) {
  hsa <- read.csv(hsa_path, check.names = FALSE, fileEncoding = "UTF-8-BOM") |>
    group_by(case) |>
    summarise(`Top-ranked pose` = mean(top_pose_raw_RMSD_A),
              `Best available pose` = mean(best_available_raw_RMSD_A), .groups = "drop") |>
    mutate(Target = recode(case, "HSA_4E99_site1" = "HSA / 4E99 site 1", "HSA_4E99_site2" = "HSA / 4E99 site 2")) |>
    select(Target, `Top-ranked pose`, `Best available pose`) |>
    pivot_longer(cols = c("Top-ranked pose", "Best available pose"), names_to = "Pose", values_to = "RMSD")
  validation_plot <- bind_rows(validation_plot, hsa)
}
validation_plot$Target <- factor(validation_plot$Target,
                                 levels = c("ALPL / 9SH5", "PLAU / 6NMB", "HSA / 4E99 site 1", "HSA / 4E99 site 2"))
p3a <- ggplot(validation_plot, aes(Target, RMSD, colour = Pose, shape = Pose)) +
  geom_hline(yintercept = 2, linetype = 2, linewidth = 0.4, colour = pal[["red"]]) +
  geom_point(size = 2.2, position = position_dodge(width = 0.38)) +
  scale_colour_manual(values = c("Top-ranked pose" = pal[["dark"]], "Best available pose" = pal[["blue"]])) +
  scale_shape_manual(values = c("Top-ranked pose" = 16, "Best available pose" = 17)) +
  labs(title = "Raw redocking RMSD", x = NULL, y = "Heavy-atom RMSD (A)", colour = NULL, shape = NULL) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "bottom")

scores <- read.csv(file.path(dock_root, "results", "PFOS_docking_summary_by_condition.csv"), check.names = FALSE,
                   fileEncoding = "UTF-8-BOM")
scores$Target <- recode(scores$case, "ALPL_9SH5" = "ALPL / 9SH5", "PLAU_6NMB" = "PLAU / 6NMB")
scores$Condition <- factor(scores$condition, levels = c("dry", "wet", "surface"),
                           labels = c("Dry pocket", "Local-water sensitivity", "Remote surface"))
p3b <- ggplot(scores, aes(Condition, mean_best_affinity_kcal_mol, fill = Condition)) +
  geom_col(width = 0.68, colour = "black", linewidth = 0.3) +
  geom_errorbar(aes(ymin = mean_best_affinity_kcal_mol - sd_best_affinity_kcal_mol,
                    ymax = mean_best_affinity_kcal_mol + sd_best_affinity_kcal_mol),
                width = 0.15, linewidth = 0.45) +
  facet_wrap(~Target, nrow = 1) +
  scale_fill_manual(values = c("Dry pocket" = pal[["blue"]], "Local-water sensitivity" = pal[["teal"]], "Remote surface" = pal[["light"]])) +
  labs(title = "PFOS Vina scores across controls", x = NULL, y = "Best Vina score (kcal/mol)", fill = NULL) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "none")

repeatability <- read.csv(file.path(dock_root, "results", "PFOS_top_pose_seed_repeatability.csv"), check.names = FALSE,
                          fileEncoding = "UTF-8-BOM")
repeatability$Target <- recode(repeatability$case, "ALPL_9SH5" = "ALPL / 9SH5", "PLAU_6NMB" = "PLAU / 6NMB")
repeatability$Condition <- factor(repeatability$condition, levels = c("dry", "wet", "surface"),
                                  labels = c("Dry pocket", "Local-water sensitivity", "Remote surface"))
p3c <- ggplot(repeatability, aes(Condition, top_pose_pairwise_RMSD_max_A, colour = Target, group = Target)) +
  geom_hline(yintercept = 2, linetype = 2, linewidth = 0.4, colour = pal[["red"]]) +
  geom_line(linewidth = 0.65) + geom_point(size = 2.0) +
  scale_colour_manual(values = c("ALPL / 9SH5" = pal[["blue"]], "PLAU / 6NMB" = pal[["orange"]])) +
  labs(title = "Seed-to-seed PFOS pose repeatability", x = NULL,
       y = "Maximum pairwise top-pose RMSD (A)", colour = NULL) +
  theme(axis.text.x = element_text(angle = 25, hjust = 1), legend.position = "bottom")

fig3 <- (p3a | p3c) / p3b + plot_layout(heights = c(1, 1.12)) +
  plot_annotation(tag_levels = "A") &
  theme(plot.tag = element_text(size = 8, face = "bold"))
save_bundle(fig3, file.path(out_dir, "Fig3"), width_mm = 183, height_mm = 137)

write.csv(validation_plot, file.path(out_dir, "Fig3_source_redocking_RMSD.csv"), row.names = FALSE)
write.csv(scores, file.path(out_dir, "Fig3_source_PFOS_scores.csv"), row.names = FALSE)
write.csv(repeatability, file.path(out_dir, "Fig3_source_repeatability.csv"), row.names = FALSE)

qa <- data.frame(
  Figure = c("Fig2", "Fig3"),
  Core_conclusion = c(
    "ALPL + PLAU was selected from a seven-gene vote pool without consulting GSE48060 and retained moderate external discrimination; external single-gene FDR support remained absent.",
    "PFOS showed reproducible pocket placement and better pocket than surface scores, but top-ranked native redocking failed, limiting docking to exploratory compatibility."
  ),
  Archetype = "quantitative grid",
  Backend = "R / ggplot2 / patchwork",
  Width_mm = 183,
  Height_mm = c(150, 137),
  Replicate_unit = c("subjects; bootstrap selection reported separately", "three fixed computational seeds"),
  Uncertainty = c("DeLong 95% CI; limma approximate 95% CI", "mean +/- seed SD where shown"),
  stringsAsFactors = FALSE
)
write.csv(qa, file.path(out_dir, "figure_QA_contract.csv"), row.names = FALSE)
cat("Created Fig2 and Fig3 bundles in", out_dir, "\n")
