from __future__ import annotations

import csv
import itertools
import math
import subprocess
import sys
from pathlib import Path

import numpy as np
from rdkit import Chem
from scipy.optimize import linear_sum_assignment


ROOT = Path(sys.argv[1]).resolve()
OBABEL = Path(sys.argv[2]).resolve()


def convert(source: Path, target: Path, source_format: str) -> list[Chem.Mol]:
    target.parent.mkdir(parents=True, exist_ok=True)
    run = subprocess.run([str(OBABEL), f"-i{source_format}", str(source), "-osdf", "-O", str(target), "-d"], capture_output=True, text=True)
    if run.returncode:
        raise RuntimeError(run.stderr)
    return [m for m in Chem.SDMolSupplier(str(target), removeHs=True) if m is not None]


def raw_rmsd(ref: Chem.Mol, pose: Chem.Mol) -> float:
    rc = np.asarray(ref.GetConformer().GetPositions())
    pc = np.asarray(pose.GetConformer().GetPositions())
    best = math.inf
    for match in pose.GetSubstructMatches(ref, uniquify=False, maxMatches=100000):
        value = float(np.sqrt(np.mean(np.sum((rc - pc[np.asarray(match)]) ** 2, axis=1))))
        best = min(best, value)
    if math.isfinite(best):
        return best
    re = [a.GetSymbol() for a in ref.GetAtoms()]
    pe = [a.GetSymbol() for a in pose.GetAtoms()]
    total, count = 0.0, 0
    for element in sorted(set(re)):
        ri = [i for i, e in enumerate(re) if e == element]
        pi = [i for i, e in enumerate(pe) if e == element]
        cost = np.sum((rc[ri, None, :] - pc[None, pi, :]) ** 2, axis=2)
        row, col = linear_sum_assignment(cost)
        total += float(cost[row, col].sum())
        count += len(row)
    return math.sqrt(total / count)


def main() -> None:
    rows = []
    for site in ("site1", "site2"):
        case = f"HSA_4E99_{site}"
        ref = convert(
            ROOT / f"02_prepared_inputs/native_ligands/{case}_P8S_crystal.pdb",
            ROOT / f"13_alpl_plau_update/analysis/HSA_raw_RMSD/{case}_reference.sdf", "pdb",
        )[0]
        for seed in (20260920, 20260921, 20260922):
            poses = convert(
                ROOT / f"04_protocol_validation/HSA_PFOS_redocking/{site}/dry/{case}_dry_seed{seed}_out.pdbqt",
                ROOT / f"13_alpl_plau_update/analysis/HSA_raw_RMSD/{case}_seed{seed}.sdf", "pdbqt",
            )
            values = [raw_rmsd(ref, pose) for pose in poses]
            rows.append({"case": case, "seed": seed, "top_pose_raw_RMSD_A": round(values[0], 4),
                         "best_available_raw_RMSD_A": round(min(values), 4),
                         "best_available_rank": values.index(min(values)) + 1})
    output = ROOT / "13_alpl_plau_update/results/HSA_PFOS_raw_redocking_RMSD.csv"
    with output.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    for case, group in itertools.groupby(rows, key=lambda row: row["case"]):
        group = list(group)
        print(case, group)


if __name__ == "__main__":
    main()
