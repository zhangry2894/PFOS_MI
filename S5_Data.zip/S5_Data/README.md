# S5 Data: minimal docking reproducibility bundle

This compact archive retains the minimum non-duplicated files needed to audit the
reported ALPL/PLAU docking-rescue analysis and the HSA/PFOS ligand-specific control.

## Included

- source structures and charge-auditable PFOS/native-ligand inputs;
- prepared dry/local-water receptors and prepared ligands;
- every primary, surface-control, native-redocking and focused-redocking config;
- all corresponding PDBQT outputs and run logs for the three fixed seeds;
- raw fixed-frame redocking RMSDs, seed scores, pose-repeatability and residue-contact
  results;
- analysis scripts, figure-3 source CSV files and SHA-256 checksums.

Derived duplicate SDF pose conversions and already exported TIFF/PDF/SVG/PNG figures
were omitted because they can be regenerated from the retained PDBQT outputs and
scripts. Run-specific config paths were changed from machine-specific absolute paths
to paths relative to the extracted archive; numerical parameters were not changed.

The prespecified top-ranked redocking RMSD <= 2.0 A criterion failed. PFOS poses and
scores are therefore exploratory scoring-function outputs, not experimental evidence
of affinity, specificity or functional modulation.

## Representative pose figure

`figures/Fig4.*` contains the manuscript's four-panel representative pose figure. The displayed ALPL seed 20260922 model 1 and PLAU seed 20260921 model 1 structures were selected as medoids among the three seed-specific top-ranked dry-pocket poses. Source images, selected structures, the R assembly script, and the figure QA record are included. These views are exploratory and do not override the failed strict top-ranked redocking criterion.
