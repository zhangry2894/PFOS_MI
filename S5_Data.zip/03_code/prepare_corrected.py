"""Prepare new, independently audited inputs; never change the source tree."""
from __future__ import annotations
import csv
import hashlib
import json
import math
import platform
import shutil
import subprocess
import sys
from pathlib import Path

SOURCE = Path(r'H:\NT\xinnei\MI\PFOS\tougao\revise\tmp\12_docking_rescue')
ROOT = Path(__file__).resolve().parents[1]
DEPS = SOURCE / '00_protocol/software/python_packages'
sys.path.insert(0, str(DEPS))
import numpy as np
import gemmi
import rdkit
from rdkit import Chem
from rdkit.Chem import AllChem, rdMolDescriptors
import meeko
from meeko import MoleculePreparation, PDBQTWriterLegacy

ADT = Path(r'G:\autodockvina\python.exe')
ADT_SCRIPT = Path(r'G:\autodockvina\Lib\site-packages\AutoDockTools\Utilities24\prepare_receptor4.py')
VINA = SOURCE / '00_protocol/software/vina_1.2.7/vina_1.2.7_win.exe'
RAW = SOURCE / '01_raw_inputs'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def sdf(path, mol):
    path.parent.mkdir(parents=True, exist_ok=True)
    w = Chem.SDWriter(str(path)); w.write(mol); w.close()

def graph(mol):
    return Chem.MolToSmiles(Chem.RemoveHs(mol), isomericSmiles=False)

def read_sdf(path):
    molecules = [m for m in Chem.SDMolSupplier(str(path), removeHs=False) if m is not None]
    if len(molecules) != 1:
        raise RuntimeError(f'Expected exactly one readable molecule: {path}')
    return molecules[0]

def alpl_native(path):
    structure = gemmi.read_structure(str(path))
    ligand = next(r for r in structure[0]['A'] if r.name == 'A1JNY')
    coords = {a.name.strip(): a.pos for a in ligand if a.element.atomic_number > 1}
    block = gemmi.cif.read_file(str(path)).sole_block()
    rw, idx = Chem.RWMol(), {}
    for comp, name, element in block.find(['_chem_comp_atom.comp_id', '_chem_comp_atom.atom_id', '_chem_comp_atom.type_symbol']):
        if comp == 'A1JNY' and name in coords:
            idx[name] = rw.AddAtom(Chem.Atom(element))
    types = {'SING': Chem.BondType.SINGLE, 'DOUB': Chem.BondType.DOUBLE,
             'TRIP': Chem.BondType.TRIPLE, 'AROM': Chem.BondType.AROMATIC}
    for comp, a, b, order in block.find(['_chem_comp_bond.comp_id', '_chem_comp_bond.atom_id_1', '_chem_comp_bond.atom_id_2', '_chem_comp_bond.value_order']):
        if comp == 'A1JNY' and a in idx and b in idx:
            rw.AddBond(idx[a], idx[b], types[order.upper()])
    mol = rw.GetMol(); Chem.SanitizeMol(mol)
    conf = Chem.Conformer(mol.GetNumAtoms())
    for name, i in idx.items():
        p = coords[name]; conf.SetAtomPosition(i, (p.x, p.y, p.z))
        mol.GetAtomWithIdx(i).SetProp('_TriposAtomName', name)
    mol.AddConformer(conf)
    template = read_sdf(RAW / 'native_ligands/ALPL_9SH5_A1JNY/A1JNY.sdf')
    assert graph(mol) == graph(template), 'ALPL graph differs from source template'
    assert rdMolDescriptors.CalcMolFormula(mol) == 'C17H16N2O4S'
    return mol, structure

def plau_native(path):
    lines = path.read_text(encoding='ascii').splitlines()
    atoms = [l for l in lines if l.startswith('HETATM') and l[17:20].strip() == 'AMH'
             and l[21] == 'A' and l[22:26].strip() == '302' and l[16] in (' ', 'A')]
    serials = {int(l[6:11]) for l in atoms}
    conect = []
    for line in lines:
        if not line.startswith('CONECT'): continue
        ids = [int(line[i:i+5]) for i in range(6, len(line), 5) if line[i:i+5].strip()]
        if ids and ids[0] in serials:
            ids = [i for i in ids if i in serials]
            if len(ids) > 1: conect.append('CONECT' + ''.join(f'{i:5d}' for i in ids))
    pdb = '\n'.join(atoms + conect + ['END', ''])
    raw = Chem.MolFromPDBBlock(pdb, sanitize=False, removeHs=False, proximityBonding=False)
    if raw is None: raise RuntimeError('Cannot read crystal AMH')
    raw = Chem.RemoveHs(raw, sanitize=False)
    before = np.array(raw.GetConformer().GetPositions())
    template = Chem.RemoveHs(read_sdf(RAW / 'native_ligands/PLAU_6NMB_AMH/AMH.sdf'))
    # Correct namespace. No silent fallback is permitted.
    mol = AllChem.AssignBondOrdersFromTemplate(template, raw)
    Chem.SanitizeMol(mol)
    Chem.AssignAtomChiralTagsFromStructure(mol, confId=0, replaceExistingTags=True)
    assert np.max(np.abs(mol.GetConformer().GetPositions() - before)) == 0
    assert graph(mol) == graph(template), 'Corrected AMH graph mismatch'
    assert rdMolDescriptors.CalcMolFormula(mol) == 'C8H15NO2'
    assert len(mol.GetSubstructMatches(Chem.MolFromSmarts('C(=O)[OH]'))) == 1
    return mol, gemmi.read_structure(str(path))

def zwitterion(neutral):
    mol = Chem.Mol(neutral)
    ns = [a for a in mol.GetAtoms() if a.GetAtomicNum() == 7]
    assert len(ns) == 1
    ns[0].SetFormalCharge(1); ns[0].SetNumExplicitHs(3); ns[0].SetNoImplicit(True)
    acid = mol.GetSubstructMatch(Chem.MolFromSmarts('C(=O)[OH]'))
    assert len(acid) == 3
    oxygen = mol.GetAtomWithIdx(acid[2])
    oxygen.SetFormalCharge(-1); oxygen.SetNumExplicitHs(0); oxygen.SetNoImplicit(True)
    Chem.SanitizeMol(mol)
    assert rdMolDescriptors.CalcMolFormula(mol) == 'C8H15NO2'
    assert Chem.GetFormalCharge(mol) == 0
    return mol

def element_from_type(atom_type):
    typ = atom_type.strip().upper()
    if typ.startswith('H'): return 'H'
    return {'A': 'C', 'NA': 'N', 'OA': 'O', 'SA': 'S', 'ZN': 'ZN', 'MG': 'MG', 'CA': 'CA', 'CL': 'CL', 'BR': 'BR'}.get(typ, typ)

def ligand_input(folder, mol):
    folder.mkdir(parents=True, exist_ok=True)
    reference = Chem.RemoveHs(mol)
    reference.SetProp('_Name', folder.name + '_experimental_frame_reference')
    sdf(folder / 'reference.sdf', reference)
    prepared = Chem.AddHs(reference, addCoords=True)
    assert np.max(np.abs(prepared.GetConformer().GetPositions()[:reference.GetNumAtoms()] - reference.GetConformer().GetPositions())) == 0
    sdf(folder / 'prepared.sdf', prepared)
    setups = MoleculePreparation().prepare(prepared)
    assert len(setups) == 1
    text, ok, error = PDBQTWriterLegacy.write_string(setups[0])
    if not ok: raise RuntimeError(str(error))
    (folder / 'prepared.pdbqt').write_text(text, encoding='ascii')
    xyz = np.array(reference.GetConformer().GetPositions())
    mapping, used = {}, set()
    for line in text.splitlines():
        if not line.startswith(('ATOM  ', 'HETATM')): continue
        element = element_from_type(line[77:])
        if element == 'H': continue
        p = np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])
        candidates = [i for i, a in enumerate(reference.GetAtoms()) if a.GetSymbol().upper() == element and np.linalg.norm(xyz[i] - p) < 0.002]
        assert len(candidates) == 1 and candidates[0] not in used, 'Ambiguous PDBQT identity map'
        i = candidates[0]; used.add(i); mapping[str(int(line[6:11]))] = i
    assert len(used) == reference.GetNumAtoms()
    dump(folder / 'atom_mapping.json', {'pdbqt_serial_to_reference_index': mapping,
                                     'reference_atom_names': [a.GetPDBResidueInfo().GetName().strip() if a.GetPDBResidueInfo() else a.GetProp('_TriposAtomName') if a.HasProp('_TriposAtomName') else str(a.GetIdx()) for a in reference.GetAtoms()]})
    return {'formula': rdMolDescriptors.CalcMolFormula(prepared), 'heavy_atoms': reference.GetNumAtoms(),
            'all_atoms': prepared.GetNumAtoms(), 'smiles': Chem.MolToSmiles(reference),
            'formal_charge': Chem.GetFormalCharge(prepared),
            'atom_formal_charges': {str(a.GetIdx()): a.GetFormalCharge() for a in reference.GetAtoms()},
            'exact_reference_frame_preserved': True, 'identity_map_complete': True}

def receptor_input(folder, structure, chains):
    folder.mkdir(parents=True, exist_ok=True)
    lines, source_atoms, serial, metals = [], [], 0, []
    for chain in structure[0]:
        if chain.name not in chains: continue
        for res in chain:
            protein = res.het_flag == 'A'
            metal = res.name in ('ZN', 'MG', 'CA')
            if not (protein or metal): continue
            for atom in res:
                if atom.element.atomic_number <= 1 or atom.altloc not in ('\x00', ' ', 'A', '1'): continue
                serial += 1; element = atom.element.name.upper(); name = atom.name.strip()
                name_field = f' {name:<3}' if len(name) < 4 and len(element) == 1 else f'{name:<4}'
                p = atom.pos; record = 'ATOM' if protein else 'HETATM'
                line = f'{record:<6}{serial:5d} {name_field} {res.name:>3} {chain.name:1}{res.seqid.num:4d}{res.seqid.icode if res.seqid.icode.strip() else " ":1}   {p.x:8.3f}{p.y:8.3f}{p.z:8.3f}{atom.occ:6.2f}{atom.b_iso:6.2f}          {element:>2}'
                lines.append(line)
                source_atoms.append((chain.name, res.seqid.num, res.seqid.icode.strip(), name, element, [p.x, p.y, p.z]))
                if metal: metals.append(f'{chain.name}:{res.name}:{res.seqid.num}')
        lines.append('TER')
    pdb, pdbqt = folder / 'receptor.pdb', folder / 'receptor.pdbqt'
    pdb.write_text('\n'.join(lines + ['END', '']), encoding='ascii')
    command = [str(ADT), str(ADT_SCRIPT), '-r', str(pdb), '-o', str(pdbqt), '-A', 'checkhydrogens', '-U', 'nphs_lps_waters']
    run = subprocess.run(command, capture_output=True, text=True, timeout=1800)
    (folder / 'preparation.log').write_text('COMMAND\n' + subprocess.list2cmdline(command) + '\nSTDOUT\n' + run.stdout + '\nSTDERR\n' + run.stderr, encoding='utf-8')
    if run.returncode != 0 or not pdbqt.exists(): raise RuntimeError(f'Receptor preparation failed: {folder}')
    source_by_key = {(c, n, ins, a): (e, np.array(p)) for c, n, ins, a, e, p in source_atoms}
    assert len(source_by_key) == len(source_atoms), 'Duplicate source atom keys'
    found, max_error = set(), 0.0
    for line in pdbqt.read_text().splitlines():
        if not line.startswith(('ATOM  ', 'HETATM')): continue
        e = element_from_type(line[77:])
        if e == 'H': continue
        key = (line[21], int(line[22:26]), line[26].strip(), line[12:16].strip())
        assert key in source_by_key, f'Unexpected prepared heavy atom {key}'
        assert key not in found, f'Duplicate prepared heavy atom {key}'
        old_element, old_xyz = source_by_key[key]
        assert old_element == e, (old_element, e, key)
        p = np.array([float(line[30:38]), float(line[38:46]), float(line[46:54])])
        max_error = max(max_error, float(np.linalg.norm(p - old_xyz)))
        found.add(key)
    assert found == set(source_by_key), f'Heavy atoms omitted: {set(source_by_key)-found}'
    assert max_error <= 0.001, f'Prepared receptor heavy atoms moved: {max_error}'
    if chains == ['A', 'B']: assert ('B', 388, '', 'OH') in found
    return {'chains': chains, 'heavy_atoms': len(found), 'retained_metals': metals,
            'max_heavy_atom_coordinate_change_A': max_error,
            'B_TYR388_OH_retained': ('B', 388, '', 'OH') in found,
            'dry': True, 'ADT_warnings': [l for l in run.stdout.splitlines() if any(t in l.lower() for t in ('unable', 'sorry', 'warning'))]}

def main():
    if (ROOT / 'inputs_manifest.json').exists(): raise RuntimeError('Preparation already exists; do not overwrite')
    (ROOT / 'logs').mkdir(parents=True, exist_ok=True)
    source_files = {
        '9SH5.cif': RAW / 'structures/ALPL_9SH5/9SH5.cif',
        '6NMB.pdb': RAW / 'structures/PLAU_6NMB/6NMB.pdb',
        'A1JNY.sdf': RAW / 'native_ligands/ALPL_9SH5_A1JNY/A1JNY.sdf',
        'AMH.sdf': RAW / 'native_ligands/PLAU_6NMB_AMH/AMH.sdf'}
    rawdir = ROOT / 'raw_snapshot'; rawdir.mkdir(exist_ok=True)
    checksums = []
    for name, path in source_files.items():
        shutil.copy2(path, rawdir / name)
        checksums.append({'source': str(path), 'snapshot': str(rawdir/name), 'sha256': sha(path), 'bytes': path.stat().st_size})
    alpl, astr = alpl_native(source_files['9SH5.cif'])
    plau, pstr = plau_native(source_files['6NMB.pdb'])
    ligands = {'ALPL_A1JNY_neutral': alpl, 'PLAU_AMH_zwitterion': zwitterion(plau), 'PLAU_AMH_neutral': plau}
    ligand_qa = {}
    for name, mol in ligands.items():
        print('Preparing ligand', name, flush=True)
        ligand_qa[name] = ligand_input(ROOT / 'prepared/ligands' / name, mol)
    receptor_qa = {}
    for name, structure, chains in [('ALPL_AB', astr, ['A','B']), ('ALPL_A', astr, ['A']), ('PLAU_A', pstr, ['A'])]:
        print('Preparing receptor', name, flush=True)
        receptor_qa[name] = receptor_input(ROOT / 'prepared/receptors' / name, structure, chains)
    variants = [
        {'name':'ALPL_AB_primary', 'target':'ALPL', 'role':'primary', 'receptor':'ALPL_AB', 'ligand':'ALPL_A1JNY_neutral'},
        {'name':'ALPL_A_sensitivity', 'target':'ALPL', 'role':'sensitivity', 'receptor':'ALPL_A', 'ligand':'ALPL_A1JNY_neutral'},
        {'name':'PLAU_zwitterion_primary', 'target':'PLAU', 'role':'primary', 'receptor':'PLAU_A', 'ligand':'PLAU_AMH_zwitterion'},
        {'name':'PLAU_neutral_sensitivity', 'target':'PLAU', 'role':'sensitivity', 'receptor':'PLAU_A', 'ligand':'PLAU_AMH_neutral'}]
    boxes = {'ALPL': {'center':[114.468,134.639,145.323], 'size':[22,28.220,22]},
             'PLAU': {'center':[56.467,-5.942,108.695], 'size':[22,22.381,22]}}
    payload = {'preparation_gate':'PASS', 'variants': variants, 'boxes': boxes,
               'ligand_checks':ligand_qa, 'receptor_checks':receptor_qa,
               'raw_checksums':checksums, 'vina':str(VINA),
               'seeds':[20260920,20260921,20260922], 'exhaustiveness':32, 'num_modes':20, 'energy_range':5, 'cpu':4,
               'environment':{'python':sys.version, 'python_executable':sys.executable, 'platform':platform.platform(),
                              'rdkit':rdkit.__version__, 'gemmi':gemmi.__version__, 'meeko':meeko.__version__, 'numpy':np.__version__},
               'software_checksums': {str(p):sha(p) for p in (VINA,ADT_SCRIPT,Path(__file__),ROOT/'PROTOCOL.md')}}
    dump(ROOT/'inputs_manifest.json', payload)
    print(json.dumps(payload, indent=2), flush=True)

if __name__ == '__main__': main()
