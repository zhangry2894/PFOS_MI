
===== SOURCE RECORD: corrected_baseline/PROTOCOL.md =====
# Native-ligand correction and redocking protocol, 2026-10-16

## Scope and status

This is a new corrective analysis, not a retrospectively preregistered original analysis.
The author authorized execution after discovery of a PLAU ligand bond-order error and
an ALPL omitted-neighbour-chain issue. Existing raw data, results and submission files
remain unchanged. No PFOS binding or inhibition claim is an endpoint of this stage.

## Locked stage-A comparisons (before any new docking results)

1. ALPL 9SH5 chain A+B, neutral A1JNY. Primary corrected receptor.
2. ALPL 9SH5 chain A only, same A1JNY. Matched receptor-context sensitivity.
3. PLAU 6NMB chain A, chemically corrected AMH in its zwitterionic state. Primary.
4. PLAU 6NMB chain A, chemically corrected neutral AMH. Protonation sensitivity.

All receptors are dry. ALPL retains experimental Zn, Mg and Ca coordinates. ADT
hydrogen preparation is retained to isolate these corrections; its warnings and
limitations are preserved. Vina default scoring does not use supplied partial charges;
assigning ion charges is not claimed to validate metal coordination chemistry.
Both chemical states of AMH must have C8H15NO2. The previous C8H17NO2 input is invalid.

## Input gates

- Bound reference heavy-atom coordinates must match the original experimental model.
- Chemical graphs must agree with source SDF/CCD, including correct carbonyl bond order.
- Zwitterionic AMH uses NH3+ and COO-; neutral uses NH2 and COOH. Charges are inspected
  atom-by-atom, not only by net molecular charge.
- Prepared receptor heavy-atom coordinates must match the source-selected atoms.
- A+B receptor must contain B-chain Tyr388 and all retained metals.
- No experimental reference minimization or independent ligand superposition is allowed.
- Raw input, scripts and executable SHA256 values are recorded.

## Docking parameters

AutoDock Vina 1.2.7, default Vina scoring, rigid receptor, flexible ligand.
Seeds: 20260920, 20260921, 20260922. CPU=4, exhaustiveness=32, num_modes=20,
energy_range=5 kcal/mol. The search setting is fixed for all four variants.
Each job has a 30-minute hard runtime limit; nonzero exits stop that job and remain logged.
No failed calculation is silently retried or overwritten.

ALPL centre (114.468,134.639,145.323), size (22.000,28.220,22.000) Angstrom.
PLAU centre (56.467,-5.942,108.695), size (22.000,22.381,22.000) Angstrom.
These are the archived native-pocket boxes, not newly optimized boxes.

## Evaluation and stopping rules

The primary validation endpoint remains Top-1 heavy-atom RMSD <=2.0 Angstrom in all
three seeds. This is this project's strict criterion, not a universal literature rule.
RMSD uses the fixed receptor coordinate frame, with chemical graph automorphisms and
explicit terminal-group symmetry handling. No element-only Hungarian fallback is used.
Also report atom-identity RMSD, all pose RMSDs, best-sampled RMSD and rank, scores and
per-seed outcomes. Best-sampled success does not substitute for Top-1 success.

Preparation is checked before docking. For a successful primary variant, the frozen
protocol may subsequently be used for PFOS and matched controls in a separately recorded
stage. A failed primary cannot be silently replaced by a favourable sensitivity result.
If sampling succeeds but ranking fails, at most one separately documented alternative
scoring branch may be evaluated. Such development is exploratory and, where possible,
requires a separate experimental complex for validation. No tune-until-pass search.

This stage does not update manuscript, response, figures or public repository files.
Results are reported whether positive or negative. Multiple seeds are computational
search replicates, not independent biological experiments.

## Literature supporting the approach

- Sastry et al. 2013, doi:10.1007/s10822-013-9644-8 (chemical preparation).
- Wu et al. 2019, doi:10.1182/bloodadvances.2018025429 (6NMB/TXA experimental complex).
- Drevet Mulard et al. 2025, doi:10.1038/s42003-025-08901-3 (9SH5/MLS structure).
- McNutt et al. 2021, doi:10.1186/s13321-021-00522-2 (conditional rescoring rationale).
- Ng and Hungerbuehler 2015, doi:10.1021/acs.est.5b03000 (PFOS-HSA reference precedent,
  not a substitute for target-specific validation and not executed in stage A).

===== SOURCE RECORD: corrected_baseline/STAGE_B_PLAU_PROTOCOL.md =====
# Stage B: PFOS on the validated PLAU preparation

Initiated only after the predeclared zwitterionic-TXA primary variant passed Top-1
RMSD <=2 A in all three seeds and independent RMSD reconstruction agreed.
ALPL did not pass, and no ALPL PFOS result is promoted as validated.

Use the unchanged dry PLAU receptor and Vina 1.2.7, seeds 20260920/21/22,
exhaustiveness 32, modes 20, energy range 5, CPU 4. The PFOS ligand must be the
audited C8F17O3S anion (-1), without a sulfonic acid proton, with chemistry and
PDBQT export checked before running. Freeze all files and record checksums.

Native pocket centre: 56.467, -5.942, 108.695; size: 22,22.381,22 A.
Archived surface-reference centre: 79.393,-20.244,133.719; size:22,22,22 A.
Use both boxes across all three seeds. Surface docking is a spatial computational
reference, not an experimentally established non-binding negative control.
No native-ligand/PFOS affinity ranking or competitive inhibition conclusion is made.

Repeat native primary seed 20260921 once with identical frozen inputs to assess
deterministic replay. This duplicate is not a fourth independent validation seed.
Display structures, if supplied, use the predesignated first seed 20260920 and
top-ranked pose, not a pose chosen for the smallest RMSD or most favourable image.
Do not use stability or score alone to claim experimental binding.

This bounded stage does not run hydration sensitivity, molecular dynamics,
experimental binding assays or additional structural-engine tuning, and does not
update manuscript/response/public repository files.

===== SOURCE RECORD: WATER_SENSITIVITY_PROTOCOL.md =====
# Frozen corrective water-oxygen sensitivity protocol

Freeze date: 2026-10-16. This is post-review corrective analysis, not preregistration.

The original corrected bundle is copied byte-for-byte to corrected_baseline. No old file is modified.
Use its PLAU_A dry receptor, chemically corrected AMH zwitterion, and PFOS anion without changing their chemical graphs, protein coordinates or atom types.
Add only the original 6NMB chain A water O atoms at residue IDs 412, 435 and 440 as rigid, neutral OA atom-type sites. No explicit water hydrogen or orientational sampling is included. This is a fixed-water-oxygen geometric sensitivity, not full hydration or water thermodynamics.

Vina 1.2.7; default Vina score; original native pocket center (56.467,-5.942,108.695), size (22,22.381,22) Angstrom. CPU 4; exhaustiveness 32; num_modes 20; energy_range 5; seeds 20260920/21/22. No search-box or ranking optimization.

First execute three native zwitterionic AMH wet jobs, then three PFOS wet jobs. A native wet failure must be reported and does not trigger parameter adjustment; PFOS wet remains exploratory sensitivity. Repeat native wet seed 20260920 exactly once as deterministic replay, not a fourth independent seed.
Each job hard timeout 1800 seconds. Any failed or timed-out output/log is retained without automatic retry. Outputs are never overwritten by the execution stage.

Primary validation endpoint: native top-ranked heavy-atom fixed-receptor-frame RMSD <=2.0 Angstrom for all three fixed seeds. Atom mapping uses the audited Meeko index correspondence and chemical-graph automorphisms with explicit carboxylate oxygen resonance equivalence; no ligand superposition or element-only Hungarian assignment. Best-pose RMSD is diagnostic only.

ALPL A+B failure is retained without a new PFOS run or rescue search. All primary figures use first fixed seed 20260920 rank1. Reference-vs-native-redock overlays are separate from PLAU reference-vs-PFOS overlays, which do not indicate simultaneous occupancy. Atom contacts are geometric heavy-atom distances; distance alone is not called a hydrogen bond. Display-pose distances and across-three-seed means are reported separately.

===== SOURCE RECORD: corrected_baseline/qa_symmetry_method_note.md =====
# Independent RMSD cross-check note

The first independent check used RDKit CalcRMS default atom permutations and stopped
at PLAU primary seed20260920 because it returned 1.1831189715 A instead of the primary
chirality-checked 1.910778 A. This is a mapping-policy discrepancy, not evidence of
receptor alignment or a change in the underlying coordinates. The discrepancy is not
hidden and the more favourable number is not substituted into the primary endpoint.

The revised cross-check reconstructs BOTH the ORIGINAL prepared input and the output
using Meeko SMILES/IDX metadata, derives atom identities from the input coordinates,
and independently calculates the unaligned identity RMSD using RDKit CalcRMS with an
explicit identity map. It also reports the unrestricted RDKit symmetry result. The
primary results and 2 A criterion remain unchanged. A result passing even identity
RMSD does not depend on a more permissive symmetry correction to qualify.
