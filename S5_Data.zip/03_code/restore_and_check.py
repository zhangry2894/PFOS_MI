"""Verify the essential S5 package and optionally recreate its archived run layout.

python 03_code/restore_and_check.py --verify
python 03_code/restore_and_check.py --verify --rdkit-path /path/to/site-packages
python 03_code/restore_and_check.py --restore /NEW/path

No Vina job, preparation, figure renderer or network call is started by this tool.
The default verification checks all source slices, recorded input/output hashes,
310 identity RMSDs (includes one duplicate water replay), nine PFOS scores and
14 Fig4 contacts. RDKit additionally checks the original chemical symmetries.
"""
from pathlib import Path
import argparse,csv,hashlib,io,json,math,statistics,sys

ROOT=Path(__file__).resolve().parents[1]
sha=lambda b:hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--verify',action='store_true')
    ap.add_argument('--restore',type=Path)
    ap.add_argument('--rdkit-path',type=Path)
    a=ap.parse_args()
    manifest=list(csv.DictReader((ROOT/'MANIFEST_SHA256.csv').open(encoding='utf-8-sig')))
    for r in manifest:
        p=(ROOT/r['file']).resolve()
        assert p.is_relative_to(ROOT)
        b=p.read_bytes();assert len(b)==int(r['bytes']) and sha(b)==r['sha256'],r['file']
    index=list(csv.DictReader((ROOT/'SOURCE_MAP.csv').open(encoding='utf-8-sig')))
    lookup={}
    for r in index:
        p=(ROOT/r['stored_file']).resolve();assert p.is_relative_to(ROOT)
        start=int(r['byte_offset']);b=p.read_bytes()[start:start+int(r['byte_length'])]
        assert sha(b)==r['sha256'],r['source_member'];lookup[r['source_member']]=b
    def text(n):return lookup[n].decode('utf-8-sig').replace('\r\r\n','\n').replace('\r\n','\n')
    def data(n):return json.loads(text(n))
    def rows(n):return list(csv.DictReader(io.StringIO(text(n))))
    def relocate(v):
        v=str(v).replace('\\','/')
        if '/docking_rescue_v2_20261016/' in v:return 'corrected_baseline/'+v.split('/docking_rescue_v2_20261016/',1)[1]
        if '/04_docking/' in v:return v.split('/04_docking/',1)[1]
        raise ValueError(v)
    def models(n):
        result=[]
        for line in text(n).splitlines():
            if line.startswith('MODEL '):atoms={};rank=int(line.split()[1]);score=None
            elif line.startswith('REMARK VINA RESULT:'):score=float(line.split()[3])
            elif line.startswith(('ATOM  ','HETATM')):atoms[str(int(line[6:11]))]=tuple(float(line[k:k+8]) for k in (30,38,46))
            elif line.startswith('ENDMDL'):result.append((rank,score,atoms))
        return result
    def coords(n):
        lines=text(n).splitlines();count=int(lines[3][:3])
        return [tuple(float(line[k:k+10]) for k in (0,10,20)) for line in lines[4:4+count]]
    report={'status':'PASS','manifest_files_verified':len(manifest),'exact_source_records_verified':len(index),'no_docking_or_preparation_rerun':True}
    if a.verify:
        hashchecks=0
        for name in ['corrected_baseline/run_manifest.json','corrected_baseline/stage_b_manifest.json','water_run_manifest.json']:
            for job in data(name)['jobs']:
                assert job['status']=='COMPLETED'
                for old,digest in job['input_sha256'].items():assert sha(lookup[relocate(old)])==digest;hashchecks+=1
                assert sha(lookup[relocate(job['output'])])==job['output_sha256'];hashchecks+=1
        dry={(r['variant'],int(r['seed']),int(r['rank'])):r for r in rows('corrected_baseline/results/all_pose_RMSD.csv')}
        wet={(r['job_id'],int(r['rank'])):r for r in rows('results/water_all_native_pose_RMSD.csv')}
        cases=[]
        for job in data('corrected_baseline/run_manifest.json')['jobs']:
            for rank,score,atoms in models(relocate(job['output'])):
                r=dry[job['name'],job['seed'],rank]
                cases.append((job['ligand'],atoms,float(r['identity_RMSD_A']),float(r['symmetry_corrected_RMSD_A'])))
                assert score==float(r['vina_score_kcal_mol'])
        for job in data('water_run_manifest.json')['jobs']:
            if job['analysis']=='PFOS':continue
            for rank,score,atoms in models(relocate(job['output'])):
                r=wet[job['id'],rank]
                cases.append(('PLAU_AMH_zwitterion',atoms,float(r['identity_RMSD_A']),float(r['RMSD_A'])))
                assert score==float(r['score_kcal_mol'])
        identities=[];symmetries=[];liganddata={}
        if a.rdkit_path:sys.path.insert(0,str(a.rdkit_path.resolve()))
        try:
            from rdkit import Chem,rdBase
        except ImportError:
            Chem=None
        for ligand in ['ALPL_A1JNY_neutral','PLAU_AMH_neutral','PLAU_AMH_zwitterion']:
            folder='corrected_baseline/prepared/ligands/'+ligand
            xyz=coords(folder+'/reference.sdf');mapping=data(folder+'/atom_mapping.json')['pdbqt_serial_to_reference_index']
            permutations=[]
            if Chem:
                mol=Chem.MolFromMolBlock(text(folder+'/reference.sdf'),removeHs=True);assert mol
                permutations=set(mol.GetSubstructMatches(mol,uniquify=False,useChirality=True,maxMatches=100000))
                if ligand=='PLAU_AMH_zwitterion':
                    group=mol.GetSubstructMatch(Chem.MolFromSmarts('[CX3](=[OX1])[O-]'));assert len(group)==3
                    i,j=group[1:];permutations.update(tuple(j if k==i else i if k==j else k for k in p) for p in list(permutations))
            liganddata[ligand]=(xyz,mapping,permutations)
        for ligand,atoms,identity_expected,symmetry_expected in cases:
            xyz,mapping,permutations=liganddata[ligand];pose=[None]*len(xyz)
            for serial,idx in mapping.items():pose[idx]=atoms[serial]
            def rmsd(p):return math.sqrt(sum(sum((xyz[i][k]-pose[p[i]][k])**2 for k in range(3)) for i in range(len(xyz)))/len(xyz))
            err=abs(rmsd(range(len(xyz)))-identity_expected);assert err<0.00000051;identities.append(err)
            if permutations:
                err=abs(min(rmsd(p) for p in permutations)-symmetry_expected);assert err<0.00000051;symmetries.append(err)
        scores=rows('figure_source_data/PFOS_scores_per_seed.csv');assert len(scores)==9
        for r in scores:
            c=r['condition'];s=r['seed']
            n=f'water_outputs/PFOS_PLAU_water_oxygen_seed{s}.pdbqt' if c=='fixed_water_oxygen' else f'corrected_baseline/stage_b_outputs/PFOS_PLAU_{"pocket" if c=="dry_pocket" else "surface_reference"}_seed{s}.pdbqt'
            assert models(n)[0][1]==float(r['top1_score_kcal_mol'])
        contacts=rows('figure_source_data/PLAU_PFOS_display_seed20260920_contacts_le4A.csv');assert len(contacts)==14
        for r in contacts:
            distance=math.sqrt(sum((float(r['receptor_'+k])-float(r['ligand_'+k]))**2 for k in 'xyz'))
            assert abs(distance-float(r['distance_A']))<1e-10 and distance<=4 and r['seed']=='20260920'
        native=rows('corrected_baseline/results/per_seed_results.csv');water=rows('results/water_native_per_seed.csv')
        assert len(native)==12 and len(water)==3
        for r in rows('corrected_baseline/results/validation_summary.csv'):
            v=[float(x['top1_RMSD_A']) for x in native if x['variant']==r['variant']]
            assert len(v)==3 and abs(statistics.mean(v)-float(r['top1_RMSD_mean_A']))<0.00000051
            assert abs(statistics.stdev(v)-float(r['top1_RMSD_sd_A']))<0.00000051 and sum(x<=2 for x in v)==int(r['top1_pass_count'])
        report.update(recorded_input_output_hashes=hashchecks,native_conditions_and_seeds=15,identity_RMSDs=len(identities),identity_max_abs_error_A=max(identities),symmetry_RMSDs=len(symmetries),symmetry_max_abs_error_A=max(symmetries) if symmetries else None,rdkit_version=rdBase.rdkitVersion if Chem else 'not available; identity check only',PFOS_scores_verified=9,Fig4_contacts_verified=14)
    if a.restore:
        target=a.restore.resolve()
        if target.exists():raise FileExistsError('Restore target must be a new directory')
        if target==ROOT or ROOT.is_relative_to(target):raise ValueError('Refusing package root or ancestor')
        for old,b in lookup.items():
            dest=(target/old).resolve();assert dest.is_relative_to(target)
        target.mkdir(parents=True)
        for old,b in lookup.items():
            dest=target/old;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        report['restored_to']=str(target);report['restored_records']=len(lookup)
    print(json.dumps(report,indent=2))
if __name__=='__main__':main()
