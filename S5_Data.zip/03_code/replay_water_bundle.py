"""Relocate and verify/replay frozen water-sensitivity jobs without modifying history.
Python 3.10+ standard library only. No H: drive is required after extraction.
"""
from pathlib import Path
import argparse,hashlib,json,subprocess,time
from datetime import datetime,timezone

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def relocate(value,root):
    parts=str(value).replace('\\','/').split('/')
    if '04_docking' not in parts:raise ValueError('Unknown archived path: '+str(value))
    p=(root/Path(*parts[parts.index('04_docking')+1:])).resolve()
    if not p.is_relative_to(root):raise ValueError('Path escapes extracted bundle')
    return p

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--vina',type=Path,help='Exact archived Vina 1.2.7 executable, SHA256 checked')
    ap.add_argument('--output',type=Path,help='New directory for replay; historical data never overwritten')
    ap.add_argument('--job',help='Exact archived job ID, default all seven archived jobs')
    ap.add_argument('--verify-only',action='store_true',help='Read-only input/output hash verification; no docking')
    a=ap.parse_args();root=a.root.resolve()
    manifest=json.loads((root/'water_run_manifest.json').read_text());jobs=manifest['jobs']
    if a.job:
        jobs=[j for j in jobs if j['id']==a.job]
        if len(jobs)!=1:raise ValueError('Job ID not uniquely found')
    report={'mode':'verify_only' if a.verify_only else 'replay','started_utc':datetime.now(timezone.utc).isoformat(),'jobs':[]}
    for job in jobs:
        for p,h in job['input_sha256'].items():
            if digest(relocate(p,root))!=h:raise ValueError('Frozen input hash mismatch: '+p)
        if digest(relocate(job['output'],root))!=job['output_sha256']:raise ValueError('Archived output mismatch: '+job['id'])
    report['frozen_input_output_hashes_verified']=True
    if a.verify_only:
        report['jobs']=[{'id':j['id'],'status':j['status']} for j in jobs]
        print(json.dumps(report,indent=2));return
    if not a.vina or not a.output:ap.error('--vina and --output required for replay')
    binary=a.vina.resolve();out=a.output.resolve()
    if digest(binary)!=manifest['vina_sha256']:raise ValueError('Vina executable checksum differs from archived build')
    if out.exists():raise FileExistsError('Output must be new: '+str(out))
    if out==root or root.is_relative_to(out):raise ValueError('Refusing ancestor/root output directory')
    out.mkdir(parents=True)
    report['vina_sha256']=digest(binary)
    for job in jobs:
        config={}
        for line in relocate(job['config'],root).read_text().splitlines():
            if '=' in line:
                k,v=line.split('=',1);config[k.strip()]=v.strip()
        for k in ('receptor','ligand'):config[k]=str(relocate(config[k],root))
        config['out']=str(out/(job['id']+'.pdbqt'));cfg=out/(job['id']+'.txt');cfg.write_text('\n'.join(f'{k} = {v}' for k,v in config.items())+'\n')
        row={'id':job['id'],'config':str(cfg),'started_utc':datetime.now(timezone.utc).isoformat()};t=time.monotonic()
        try:
            with (out/(job['id']+'.log')).open('w') as log:
                r=subprocess.run([str(binary),'--config',str(cfg)],stdout=log,stderr=subprocess.STDOUT,timeout=1800,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
            row['exit_code']=r.returncode;row['status']='COMPLETED' if r.returncode==0 else 'FAILED'
        except subprocess.TimeoutExpired:row['status']='TIMEOUT'
        p=Path(config['out']);row['elapsed_seconds']=time.monotonic()-t
        if p.exists():row.update(output_sha256=digest(p),archived_sha256=job['output_sha256'],byte_identical=digest(p)==job['output_sha256'])
        report['jobs'].append(row);(out/'replay_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(row),flush=True)
        if row['status']!='COMPLETED' or not p.exists():raise RuntimeError('Replay failed; logs retained; no automatic retry')

if __name__=='__main__':main()
