"""Traceable display structures, atom/bond/coordinate tables and distance contacts.
No independent ligand fitting. Rendering is delegated to the manuscript R workflow.
"""
from pathlib import Path
import argparse,sys,json,csv,statistics,itertools,shutil
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--packages',type=Path);a=p.parse_args();ROOT=a.root.resolve();BASE=ROOT/'corrected_baseline'
if a.packages:sys.path.insert(0,str(a.packages))
import numpy as np
from rdkit import Chem
from rdkit.Chem import rdDepictor
from meeko import PDBQTMolecule,RDKitMolCreate
OUT=ROOT/'display_structures';OUT.mkdir(exist_ok=True);DATA=ROOT/'figure_source_data';DATA.mkdir(exist_ok=True)
def csvout(path,rows):
    if rows:
        with path.open('w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def readmol(path):return next(m for m in Chem.SDMolSupplier(str(path),removeHs=True) if m is not None)
def dockmol(path):
    m=RDKitMolCreate.from_pdbqt_mol(PDBQTMolecule.from_file(str(path),skip_typing=True));assert len(m)==1 and m[0] is not None;return Chem.RemoveHs(m[0])
def savemol(m,name,conf=0):
    w=Chem.SDWriter(str(OUT/(name+'.sdf')));m.SetProp('_Name',name);m.SetProp('coordinate_frame','Original experimental receptor frame; no ligand alignment');w.write(m,confId=conf);w.close()
    return OUT/(name+'.sdf')
def recatoms(path):
    rows=[]
    for l in Path(path).read_text().splitlines():
        if l.startswith(('ATOM  ','HETATM')) and not l[77:].strip().startswith('H'):
            rows.append({'serial':int(l[6:11]),'atom_name':l[12:16].strip(),'residue_name':l[17:20].strip(),'chain':l[21],'residue_number':int(l[22:26]),'insertion_code':l[26].strip(),'atom_type':l[77:].strip(),'x':float(l[30:38]),'y':float(l[38:46]),'z':float(l[46:54])})
    return rows
def residuekey(r):return f"{r['residue_name']}:{r['chain']}:{r['residue_number']}{r['insertion_code']}"
def makecomplex(receptor,m,name):
    lines=[l for l in Path(receptor).read_text().splitlines() if l.startswith(('ATOM  ','HETATM','TER'))]
    # SDF is authoritative for ligand chemistry; PDB is a display convenience.
    offset=max([int(l[6:11]) for l in lines if l.startswith(('ATOM  ','HETATM'))]+[0]);xyz=m.GetConformer(0).GetPositions()
    for i,atom in enumerate(m.GetAtoms()):
        x,y,z=xyz[i];atomname=f'{atom.GetSymbol()}{i+1}'[:4]
        lines.append(f'HETATM{offset+i+1:5d} {atomname:<4} LIG X   1    {x:8.3f}{y:8.3f}{z:8.3f}{1.:6.2f}{0.:6.2f}          {atom.GetSymbol():>2}')
    for b in m.GetBonds():lines.append(f'CONECT{offset+b.GetBeginAtomIdx()+1:5d}{offset+b.GetEndAtomIdx()+1:5d}')
    (OUT/(name+'_complex.pdb')).write_text('REMARK SDF companion is authoritative for ligand bond orders and formal charges.\n'+'\n'.join(lines)+'\nEND\n')

def main():
    first=20260920;atoms=[];bonds=[];receptr=[];spec=[]
    for target,variant,ligand,recname in [('ALPL','ALPL_AB_primary','ALPL_A1JNY_neutral','ALPL_AB'),('PLAU','PLAU_zwitterion_primary','PLAU_AMH_zwitterion','PLAU_A')]:
        receptor=BASE/'prepared/receptors'/recname/'receptor.pdb';shutil.copy2(receptor,OUT/f'{target}_receptor_dry.pdb')
        pdbqt=BASE/'prepared/receptors'/recname/'receptor.pdbqt';shutil.copy2(pdbqt,OUT/f'{target}_receptor_dry.pdbqt')
        for r in recatoms(pdbqt):receptr.append({'target':target,**r})
        native=readmol(BASE/'prepared/ligands'/ligand/'reference.sdf');redocked=readmol(BASE/'poses_sdf'/variant/f'seed_{first}_top1.sdf')
        for label,m in [('native_reference',native),('native_redocked_top1',redocked)]:
            name=f'{target}_{label}_seed{first}' if 'redocked' in label else f'{target}_{label}'
            savemol(m,name);makecomplex(receptor,m,name);spec.append((target,label,m,name))
        if target=='PLAU':
            wet=dockmol(ROOT/'water_outputs'/f'native_PLAU_water_oxygen_seed{first}.pdbqt')
            wetdisplay=Chem.Mol(wet);conf=Chem.Conformer(wet.GetConformer(0));wetdisplay.RemoveAllConformers();wetdisplay.AddConformer(conf,assignId=True)
            name=f'PLAU_native_redocked_water_top1_seed{first}'
            savemol(wetdisplay,name);makecomplex(ROOT/'prepared/PLAU_A_water_oxygen/receptor.pdb',wetdisplay,name);spec.append((target,'native_redocked_water_top1',wetdisplay,name))
    pfos={};scores=[];contacts=[];rec=recatoms(BASE/'prepared/receptors/PLAU_A/receptor.pdbqt')
    for condition in ('dry_pocket','fixed_water_oxygen','surface_reference'):
        for seed in (20260920,20260921,20260922):
            path=(ROOT/'water_outputs'/f'PFOS_PLAU_water_oxygen_seed{seed}.pdbqt') if condition=='fixed_water_oxygen' else BASE/'stage_b_outputs'/f'PFOS_PLAU_{"pocket" if condition=="dry_pocket" else "surface_reference"}_seed{seed}.pdbqt'
            m=dockmol(path);assert Chem.GetFormalCharge(m)==-1 and m.GetNumAtoms()==29;pfos[(condition,seed)]=m
            xyz=np.asarray(m.GetConformer(0).GetPositions());score=next(float(l.split()[3]) for l in path.read_text().splitlines() if l.startswith('REMARK VINA RESULT:'));scores.append({'condition':condition,'seed':seed,'top1_score_kcal_mol':score})
            if condition=='dry_pocket':
                minima={}
                for r in rec:
                    d=np.linalg.norm(xyz-np.array([r['x'],r['y'],r['z']]),axis=1);i=int(np.argmin(d));key=residuekey(r)
                    row={'condition':condition,'seed':seed,'residue':key,'residue_name':r['residue_name'],'chain':r['chain'],'residue_number':r['residue_number'],'insertion_code':r['insertion_code'],'receptor_atom':r['atom_name'],'receptor_atom_type':r['atom_type'],'ligand_atom_index_0based':i,'ligand_element':m.GetAtomWithIdx(i).GetSymbol(),'distance_A':float(d[i]),'receptor_x':r['x'],'receptor_y':r['y'],'receptor_z':r['z'],'ligand_x':float(xyz[i,0]),'ligand_y':float(xyz[i,1]),'ligand_z':float(xyz[i,2]),'interpretation':'geometric proximity only; not automatic hydrogen bond'}
                    if key not in minima or row['distance_A']<minima[key]['distance_A']:minima[key]=row
                contacts.extend(minima.values())
    m=pfos[('dry_pocket',first)];display=Chem.Mol(m);conf=Chem.Conformer(m.GetConformer(0));display.RemoveAllConformers();display.AddConformer(conf,assignId=True)
    savemol(display,f'PLAU_PFOS_dry_top1_seed{first}');makecomplex(BASE/'prepared/receptors/PLAU_A/receptor.pdb',display,f'PLAU_PFOS_dry_top1_seed{first}');spec.append(('PLAU','PFOS_dry_top1',display,f'PLAU_PFOS_dry_top1_seed{first}'))
    shutil.copy2(BASE/'prepared/ligands/PFOS_anion/prepared.pdbqt',OUT/'PFOS_anion_input.pdbqt')
    for target,label,m,name in spec:
        xyz=m.GetConformer(0).GetPositions()
        for i,atom in enumerate(m.GetAtoms()):atoms.append({'target':target,'molecule':label,'file_stem':name,'atom_index_0based':i,'element':atom.GetSymbol(),'formal_charge':atom.GetFormalCharge(),'x':float(xyz[i,0]),'y':float(xyz[i,1]),'z':float(xyz[i,2])})
        for b in m.GetBonds():bonds.append({'target':target,'molecule':label,'atom_i_0based':b.GetBeginAtomIdx(),'atom_j_0based':b.GetEndAtomIdx(),'bond_order':b.GetBondTypeAsDouble(),'aromatic':b.GetIsAromatic()})
    flat=Chem.Mol(display);rdDepictor.Compute2DCoords(flat);xy=flat.GetConformer().GetPositions();csvout(DATA/'PLAU_PFOS_2D_atom_coordinates.csv',[{'atom_index_0based':i,'element':at.GetSymbol(),'formal_charge':at.GetFormalCharge(),'x2d':xy[i,0],'y2d':xy[i,1]} for i,at in enumerate(flat.GetAtoms())])
    csvout(DATA/'overlay_ligand_atom_coordinates.csv',atoms);csvout(DATA/'overlay_ligand_bonds.csv',bonds);csvout(DATA/'receptor_heavy_atom_coordinates.csv',receptr);csvout(DATA/'PFOS_scores_per_seed.csv',scores)
    csvout(DATA/'PLAU_PFOS_all_residue_minimum_distances_by_seed.csv',contacts)
    display_contacts=sorted([r for r in contacts if r['seed']==first and r['distance_A']<=4],key=lambda r:r['distance_A']);csvout(DATA/'PLAU_PFOS_display_seed20260920_contacts_le4A.csv',display_contacts)
    means=[]
    for key in sorted(set(r['residue'] for r in contacts)):
        rows=[r for r in contacts if r['residue']==key];assert len(rows)==3;frequency=sum(r['distance_A']<=4 for r in rows)
        if frequency:means.append({'residue':key,'n_contacting_seeds_le4A':frequency,'n_seeds':3,'mean_min_heavy_atom_distance_A':statistics.mean(r['distance_A'] for r in rows),'sd_min_heavy_atom_distance_A':statistics.stdev(r['distance_A'] for r in rows),'display_first_seed_distance_A':next(r['distance_A'] for r in rows if r['seed']==first),'note':'mean across search seeds; not distance in any one pose'})
    csvout(DATA/'PLAU_PFOS_residue_contacts_three_seed_summary.csv',means)
    pairrows=[]
    for condition in ('dry_pocket','fixed_water_oxygen','surface_reference'):
        for s1,s2 in itertools.combinations((20260920,20260921,20260922),2):
            m1,m2=pfos[(condition,s1)],pfos[(condition,s2)];x1=np.asarray(m1.GetConformer(0).GetPositions());x2=np.asarray(m2.GetConformer(0).GetPositions());assert Chem.MolToSmiles(m1)==Chem.MolToSmiles(m2)
            pairrows.append({'condition':condition,'seed_1':s1,'seed_2':s2,'identity_fixed_frame_top1_RMSD_A':float(np.sqrt(np.mean(np.sum((x1-x2)**2,axis=1)))),'no_ligand_alignment':True,'interpretation':'search-repeatability; not accuracy or physical stability'})
    csvout(DATA/'PFOS_top1_pairwise_repeatability.csv',pairrows)
    native=json.loads((BASE/'results/validation_summary.json').read_text());wet=json.loads((ROOT/'water_summary.json').read_text());scorestats=[]
    for condition in ('dry_pocket','fixed_water_oxygen','surface_reference'):
        vals=[r['top1_score_kcal_mol'] for r in scores if r['condition']==condition];scorestats.append({'condition':condition,'n':3,'mean':statistics.mean(vals),'sd':statistics.stdev(vals),'units':'kcal/mol'})
    summary={'native_dry_summary':native['summary'],'native_dry_per_seed':native['seeds'],'native_water':wet['native_wet'],'PFOS_scores':scorestats,'PFOS_scores_per_seed':scores,'wet_minus_dry_score_kcal_mol':wet['wet_minus_dry_score_kcal_mol'],'surface_minus_dry_pocket_score_kcal_mol':scorestats[2]['mean']-scorestats[0]['mean'],'PFOS_repeatability':pairrows,'display_selection':'First fixed seed 20260920, rank1; original receptor coordinate frame; no ligand alignment','display_contacts':display_contacts,'contact_three_seed_summary':means,'water_replay':wet['deterministic_replay'],'water_model':wet['water_model'],'warnings':['ALPL corrected A+B native redocking fails; no new ALPL PFOS claim.','PLAU dry zwitterion passes this narrow control; neutral and fixed-water-oxygen sensitivities fail top1.','PFOS display is specific to the dry protocol, exploratory and not a binding/inhibition claim.','Native and PFOS overlays show alternative occupancy states, not simultaneous binding.','Seeds are computational search replicates, not biological replicates.']}
    (ROOT/'final_summary.json').write_text(json.dumps(summary,indent=2));(OUT/'selection_manifest.json').write_text(json.dumps({'selection':summary['display_selection'],'warnings':summary['warnings'],'structures':[r[3]+'.sdf' for r in spec],'source_data_directory':'../figure_source_data'},indent=2))
    print('FINAL_SUMMARY',ROOT/'final_summary.json');print('DISPLAY_CONTACTS',len(display_contacts));print('STRUCTURES',OUT)
if __name__=='__main__':main()
