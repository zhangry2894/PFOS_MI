"""Run the frozen 12-job native validation; no automatic retries."""
from __future__ import annotations
import concurrent.futures
import hashlib
import json
import os
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCK = threading.Lock()

def now(): return datetime.now(timezone.utc).isoformat()
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    manifest = json.loads((ROOT/'inputs_manifest.json').read_text(encoding='utf-8'))
    assert manifest['preparation_gate'] == 'PASS'
    for path, digest in manifest['software_checksums'].items():
        assert sha(path) == digest, f'Frozen input/protocol changed: {path}'
    if (ROOT/'run_manifest.json').exists():
        raise RuntimeError('Run manifest exists. Inspect before any resumption; no automatic rerun.')
    jobs = []
    for variant in manifest['variants']:
        for seed in manifest['seeds']:
            job_id = variant['name'] + '_seed' + str(seed)
            output = ROOT/'docking'/variant['name']/f'seed_{seed}.pdbqt'
            config = ROOT/'configs'/f'{job_id}.txt'
            log = ROOT/'logs/docking'/f'{job_id}.log'
            for p in [output, config, log]: p.parent.mkdir(parents=True, exist_ok=True)
            receptor = ROOT/'prepared/receptors'/variant['receptor']/'receptor.pdbqt'
            ligand = ROOT/'prepared/ligands'/variant['ligand']/'prepared.pdbqt'
            box = manifest['boxes'][variant['target']]
            settings = {'receptor':str(receptor), 'ligand':str(ligand),
                        **{f'center_{a}':v for a,v in zip('xyz',box['center'])},
                        **{f'size_{a}':v for a,v in zip('xyz',box['size'])},
                        'exhaustiveness':manifest['exhaustiveness'], 'num_modes':manifest['num_modes'],
                        'energy_range':manifest['energy_range'], 'seed':seed, 'cpu':manifest['cpu'],
                        'out':str(output), 'verbosity':1}
            config.write_text('\n'.join(f'{k} = {v}' for k,v in settings.items())+'\n', encoding='utf-8')
            jobs.append({**variant, 'id':job_id, 'seed':seed, 'status':'PLANNED',
                         'output':str(output), 'config':str(config), 'log':str(log),
                         'input_sha256':{str(p):sha(p) for p in [receptor,ligand,config]}})
    record = {'created_utc':now(), 'protocol_sha256':sha(ROOT/'PROTOCOL.md'),
              'runner_sha256':sha(__file__), 'max_concurrent_jobs':2, 'logical_cpu_count':os.cpu_count(),
              'per_job_timeout_seconds':1800, 'jobs':jobs}
    def save():
        (ROOT/'run_manifest.json').write_text(json.dumps(record,indent=2)+'\n', encoding='utf-8')
    save()
    def execute(job):
        cmd = [manifest['vina'],'--config',job['config']]
        with LOCK:
            job.update(status='RUNNING',started_utc=now(),command=cmd); save()
            print('START',job['id'],flush=True)
        started = time.monotonic()
        try:
            with open(job['log'],'w',encoding='utf-8') as log:
                log.write('COMMAND\n'+subprocess.list2cmdline(cmd)+'\n\n'); log.flush()
                process = subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,
                                           creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                with LOCK: job['pid']=process.pid; save()
                while True:
                    try:
                        exit_code = process.wait(timeout=30); break
                    except subprocess.TimeoutExpired:
                        elapsed = time.monotonic()-started
                        with LOCK:
                            job['last_alive_utc']=now(); job['elapsed_seconds']=round(elapsed,2); save()
                        if elapsed >= 1800:
                            print('HARD TIMEOUT: stopping',job['id'],flush=True)
                            process.kill(); process.wait()
                            raise RuntimeError('Per-job 1800 second hard timeout')
            valid = Path(job['output']).exists() and 'REMARK VINA RESULT:' in Path(job['output']).read_text()
            with LOCK:
                job.update(exit_code=exit_code,status='COMPLETED' if exit_code==0 and valid else 'FAILED',
                           elapsed_seconds=round(time.monotonic()-started,2),ended_utc=now())
                if Path(job['output']).exists(): job['output_sha256']=sha(job['output'])
                save(); print(job['status'],job['id'],job['elapsed_seconds'],'s',flush=True)
        except Exception as exc:
            with LOCK:
                job.update(status='FAILED',error=str(exc),ended_utc=now(),elapsed_seconds=round(time.monotonic()-started,2))
                save(); print('FAILED',job['id'],str(exc),flush=True)
    print('Native jobs:',len(jobs),'Concurrency:2 CPU/job:4',flush=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(execute,jobs))
    record['ended_utc']=now()
    record['status']='COMPLETED' if all(j['status']=='COMPLETED' for j in jobs) else 'PARTIAL_OR_FAILED'
    save(); print('FINAL',record['status'],flush=True)
    if record['status']!='COMPLETED': raise SystemExit(1)

if __name__=='__main__': main()
