"""Frozen six-job fixed-water-O sensitivity plus one deterministic replay."""
from pathlib import Path
import sys, json, hashlib, shutil, subprocess, time
from datetime import datetime, timezone
ROOT=Path(__file__).resolve().parent
SOURCE=Path(r'C:\Users\Administrator\Documents\Codex\2026-09-12\new-chat\docking_rescue_v2_20261016')
BASE=ROOT/'corrected_baseline'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def main():
    if (ROOT/'water_run_manifest.json').exists():raise RuntimeError('Manifest exists; no automatic restart or overwrite')
    if not BASE.exists():shutil.copytree(SOURCE,BASE)
    checks=[]
    for p in SOURCE.rglob('*'):
        if p.is_file():
            q=BASE/p.relative_to(SOURCE);assert sha(p)==sha(q)
            checks.append({'path':p.relative_to(SOURCE).as_posix(),'sha256':sha(q),'bytes':q.stat().st_size})
    (ROOT/'baseline_copy_verification.json').write_text(json.dumps(checks,indent=2))
    manifest=json.loads((BASE/'inputs_manifest.json').read_text())
    assert manifest['preparation_gate']=='PASS'
    vina=Path(manifest['vina']);assert sha(vina)==manifest['software_checksums'][str(vina)]
    dry=BASE/'prepared/receptors/PLAU_A/receptor.pdbqt'
    source_pdb=BASE/'raw_snapshot/6NMB.pdb'
    water=[]
    for line in source_pdb.read_text().splitlines():
        if line.startswith('HETATM') and line[17:20]=='HOH' and line[21]=='A' and int(line[22:26]) in (412,435,440) and line[12:16].strip()=='O':water.append(line)
    assert len(water)==3 and {int(l[22:26]) for l in water}=={412,435,440}
    dry_text=dry.read_text();records=[l for l in dry_text.splitlines() if l.startswith(('ATOM  ','HETATM'))]
    assert not any(l[17:20]=='HOH' for l in records)
    max_serial=max(int(l[6:11]) for l in records)
    lines=[];water_qa=[]
    for i,l in enumerate(sorted(water,key=lambda l:int(l[22:26]))):
        # Standard PDBQT columns: partial charge in 71-76, atom type at 78 onward.
        out=f'HETATM{max_serial+i+1:5d}'+l[11:66]+'    '+f'{0.0:6.3f}'+' OA'
        assert out[77:].strip()=='OA' and float(out[70:76])==0
        assert out[30:54]==l[30:54]
        lines.append(out)
        water_qa.append({'residue':f'A:{int(l[22:26])}','source_atom_serial':int(l[6:11]),'water_oxygen_xyz':[float(l[30:38]),float(l[38:46]),float(l[46:54])],'atom_type':'OA','charge':0.0,'source_line':l,'prepared_line':out})
    wetdir=ROOT/'prepared/PLAU_A_water_oxygen';wetdir.mkdir(parents=True)
    wet=wetdir/'receptor.pdbqt';wet.write_text(dry_text.rstrip('\n')+'\n'+'\n'.join(lines)+'\n')
    assert wet.read_text().splitlines()[:len(dry_text.splitlines())]==dry_text.splitlines()
    drypdb=BASE/'prepared/receptors/PLAU_A/receptor.pdb'
    pdbtext='\n'.join(l for l in drypdb.read_text().splitlines() if not l.startswith(('END','MASTER')))
    (wetdir/'receptor.pdb').write_text(pdbtext+'\n'+'\n'.join(water)+'\nEND\n')
    qa={'dry_protein_records_unchanged':True,'water_sites':water_qa,'no_explicit_water_hydrogens':True,'water_orientation_not_sampled':True,'source_structure_sha256':sha(source_pdb),'dry_sha256':sha(dry),'wet_sha256':sha(wet)}
    (ROOT/'water_preparation_qa.json').write_text(json.dumps(qa,indent=2))
    box=manifest['boxes']['PLAU'];jobs=[]
    for analysis,ligandname in [('native','PLAU_AMH_zwitterion'),('PFOS','PFOS_anion')]:
        for seed in manifest['seeds']:
            jobs.append({'id':f'{analysis}_PLAU_water_oxygen_seed{seed}','analysis':analysis,'seed':seed,'ligand_name':ligandname})
    jobs.append({'id':'native_PLAU_water_oxygen_seed20260920_replay','analysis':'native_replay','seed':20260920,'ligand_name':'PLAU_AMH_zwitterion'})
    rec={'created_utc':now(),'protocol_sha256':sha(ROOT/'WATER_SENSITIVITY_PROTOCOL.md'),'runner_sha256':sha(__file__),'status':'RUNNING','vina':str(vina),'vina_sha256':sha(vina),'python':sys.executable,'timeout_seconds':1800,'jobs':jobs}
    def save():(ROOT/'water_run_manifest.json').write_text(json.dumps(rec,indent=2))
    for job in jobs:
        job['status']='PLANNED'
        ligand=BASE/'prepared/ligands'/job['ligand_name']/'prepared.pdbqt'
        output=ROOT/'water_outputs'/f"{job['id']}.pdbqt";cfg=ROOT/'water_configs'/f"{job['id']}.txt";log=ROOT/'water_logs'/f"{job['id']}.log"
        for p in (output,cfg,log):p.parent.mkdir(parents=True,exist_ok=True)
        settings={'receptor':str(wet),'ligand':str(ligand),**{f'center_{k}':v for k,v in zip('xyz',box['center'])},**{f'size_{k}':v for k,v in zip('xyz',box['size'])},'cpu':4,'exhaustiveness':32,'num_modes':20,'energy_range':5,'seed':job['seed'],'out':str(output),'verbosity':1}
        cfg.write_text('\n'.join(f'{k} = {v}' for k,v in settings.items())+'\n')
        job.update(receptor=str(wet),ligand=str(ligand),output=str(output),config=str(cfg),log=str(log),input_sha256={str(p):sha(p) for p in (wet,ligand,cfg)})
    save();print('INPUT QA PASS; commencing 6 wet jobs + 1 replay',flush=True)
    for job in jobs:
        cmd=[str(vina),'--config',job['config']];job.update(status='RUNNING',started_utc=now(),command=cmd);save();print('START',job['id'],flush=True);t=time.monotonic()
        try:
            with open(job['log'],'w') as log:
                log.write('COMMAND\n'+subprocess.list2cmdline(cmd)+'\n\n');log.flush()
                p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));job['pid']=p.pid;save()
                while True:
                    try:code=p.wait(timeout=30);break
                    except subprocess.TimeoutExpired:
                        job['last_alive_utc']=now();job['elapsed_seconds']=round(time.monotonic()-t,3);save()
                        if time.monotonic()-t>=1800:
                            print('HARD TIMEOUT stopping',job['id'],flush=True);p.kill();p.wait();raise RuntimeError('1800s hard timeout')
            out=Path(job['output']);valid=out.exists() and 'REMARK VINA RESULT:' in out.read_text()
            job.update(status='COMPLETED' if code==0 and valid else 'FAILED',exit_code=code)
            if out.exists():job['output_sha256']=sha(out)
        except Exception as e:job.update(status='FAILED',error=str(e))
        job.update(ended_utc=now(),elapsed_seconds=round(time.monotonic()-t,3));save();print(job['status'],job['id'],flush=True)
    rec.update(ended_utc=now(),status='COMPLETED' if all(j['status']=='COMPLETED' for j in jobs) else 'PARTIAL_OR_FAILED');save();print('FINAL',rec['status'],flush=True)
if __name__=='__main__':main()
