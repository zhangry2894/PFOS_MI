"""Fixed-frame pose analysis using input atom identities and molecular symmetry.

Output PDBQT is never converted by re-inferring bonds from pose distances.
No ligand fitting and no element-only assignment fallback is used.
"""
from __future__ import annotations
import csv
import hashlib
import json
import math
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, r'H:\NT\xinnei\MI\PFOS\tougao\revise\tmp\12_docking_rescue\00_protocol\software\python_packages')
import numpy as np
import gemmi
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors

def csvout(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows: return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def models(path):
    out=[]; atoms={};score=None;rank=None
    for l in Path(path).read_text().splitlines():
        if l.startswith('MODEL '): atoms={};score=None;rank=int(l.split()[1])
        elif l.startswith('REMARK VINA RESULT:'): score=float(l.split()[3])
        elif l.startswith(('ATOM  ','HETATM')):
            serial=str(int(l[6:11]))
            if serial in atoms: raise RuntimeError('Duplicate pose atom serial')
            atoms[serial]=[float(l[30:38]),float(l[38:46]),float(l[46:54])]
        elif l.startswith('ENDMDL'):
            assert score is not None and rank is not None
            out.append({'rank':rank,'score':score,'atoms':atoms})
    return out

def permutations(mol, ligand_name):
    base=set(mol.GetSubstructMatches(mol,uniquify=False,useChirality=True,maxMatches=100000))
    assert tuple(range(mol.GetNumAtoms())) in base
    method='graph_automorphisms_chirality_checked'
    if ligand_name=='PLAU_AMH_zwitterion':
        group=mol.GetSubstructMatch(Chem.MolFromSmarts('[CX3](=[OX1])[O-]'))
        assert len(group)==3
        a,b=group[1:]
        for match in list(base):
            swapped=tuple(b if x==a else a if x==b else x for x in match)
            base.add(swapped)
        method+='_plus_resonance_equivalent_carboxylate_oxygen_exchange'
    return sorted(base),method

def calculate(reference_xyz, pose_xyz, perms):
    identity=float(np.sqrt(np.mean(np.sum((reference_xyz-pose_xyz)**2,axis=1))))
    values=[float(np.sqrt(np.mean(np.sum((reference_xyz-pose_xyz[np.asarray(p)])**2,axis=1)))) for p in perms]
    i=int(np.argmin(values))
    return identity,values[i],perms[i]

def independent_input_qa():
    manifest=json.loads((ROOT/'inputs_manifest.json').read_text())
    sources={}
    for target, filename, resname in [('ALPL','9SH5.cif','A1JNY'),('PLAU','6NMB.pdb','AMH')]:
        s=gemmi.read_structure(str(ROOT/'raw_snapshot'/filename))
        r=next(r for r in s[0]['A'] if r.name==resname)
        sources[target]={a.name.strip():np.array([a.pos.x,a.pos.y,a.pos.z]) for a in r if a.element.atomic_number>1}
    reports=[]
    for name in manifest['ligand_checks']:
        folder=ROOT/'prepared/ligands'/name
        mol=next(m for m in Chem.SDMolSupplier(str(folder/'reference.sdf'),removeHs=True) if m is not None)
        prepared=next(m for m in Chem.SDMolSupplier(str(folder/'prepared.sdf'),removeHs=False) if m is not None)
        mapping=json.loads((folder/'atom_mapping.json').read_text())
        names=mapping['reference_atom_names'];target=name.split('_')[0]
        coords=np.array(mol.GetConformer().GetPositions())
        exact=np.array([sources[target][n] for n in names])
        max_change=float(np.max(np.linalg.norm(coords-exact,axis=1)))
        assert max_change<1e-7
        formula=rdMolDescriptors.CalcMolFormula(prepared)
        assert formula==('C17H16N2O4S' if target=='ALPL' else 'C8H15NO2')
        ps,method=permutations(mol,name)
        _,self_rmsd,_=calculate(coords,coords,ps)
        assert self_rmsd<1e-10
        translated=coords+np.array([10,20,30])
        identity,shifted,_=calculate(coords,translated,ps)
        assert abs(identity-math.sqrt(1400))<1e-8
        assert shifted>30, 'RMSD implementation appears to remove translations'
        typed=[]
        for l in (folder/'prepared.pdbqt').read_text().splitlines():
            if l.startswith(('ATOM  ','HETATM')) and l[77:].strip() in ('N','NA','O','OA'):
                typed.append({'atom':l[12:16].strip(),'type':l[77:].strip(),'partial_charge':float(l[70:76])})
        reports.append({'ligand':name,'formula':formula,'max_reference_coordinate_change_A':max_change,
                        'n_allowed_mappings':len(ps),'rmsd_method':method,'self_rmsd_A':self_rmsd,
                        'translated_identity_rmsd_A':identity,'polar_atom_types':typed})
    return reports

def main():
    qa=independent_input_qa()
    out=ROOT/'results';out.mkdir(exist_ok=True)
    (out/'independent_input_qa.json').write_text(json.dumps(qa,indent=2)+'\n')
    run=json.loads((ROOT/'run_manifest.json').read_text())
    detail=[];seedrows=[]
    for job in run['jobs']:
        if job['status']!='COMPLETED': continue
        folder=ROOT/'prepared/ligands'/job['ligand']
        mol=next(m for m in Chem.SDMolSupplier(str(folder/'reference.sdf'),removeHs=True) if m is not None)
        xyz=np.array(mol.GetConformer().GetPositions())
        mapping=json.loads((folder/'atom_mapping.json').read_text())['pdbqt_serial_to_reference_index']
        perms,method=permutations(mol,job['ligand'])
        writer_path=ROOT/'poses_sdf'/job['name']/f"seed_{job['seed']}_all_poses.sdf"
        writer_path.parent.mkdir(parents=True,exist_ok=True)
        writer=Chem.SDWriter(str(writer_path))
        rows=[]
        for model in models(job['output']):
            assert set(mapping).issubset(model['atoms'])
            pose=np.zeros_like(xyz)
            for serial,index in mapping.items(): pose[index]=model['atoms'][serial]
            identity,rmsd,match=calculate(xyz,pose,perms)
            row={'variant':job['name'],'target':job['target'],'role':job['role'],'seed':job['seed'],
                 'rank':model['rank'],'vina_score_kcal_mol':model['score'],
                 'identity_RMSD_A':round(identity,6),'symmetry_corrected_RMSD_A':round(rmsd,6),
                 'RMSD_le_2A':rmsd<=2.0,'method':method,'ligand_superposition':False}
            rows.append(row);detail.append(row)
            pose_mol=Chem.Mol(mol);conf=pose_mol.GetConformer()
            for i,p in enumerate(pose):conf.SetAtomPosition(i,tuple(p))
            for k,v in row.items():pose_mol.SetProp(k,str(v))
            pose_mol.SetProp('_Name',f"{job['id']}_rank{model['rank']}")
            writer.write(pose_mol)
            if model['rank']==1:
                w=Chem.SDWriter(str(writer_path.with_name(f"seed_{job['seed']}_top1.sdf")));w.write(pose_mol);w.close()
        writer.close()
        assert rows and rows[0]['rank']==1
        best=min(rows,key=lambda r:r['symmetry_corrected_RMSD_A'])
        seedrows.append({'variant':job['name'],'target':job['target'],'role':job['role'],'seed':job['seed'],
                         'top1_score_kcal_mol':rows[0]['vina_score_kcal_mol'],
                         'top1_identity_RMSD_A':rows[0]['identity_RMSD_A'],
                         'top1_RMSD_A':rows[0]['symmetry_corrected_RMSD_A'],'top1_pass':rows[0]['RMSD_le_2A'],
                         'best_sampled_RMSD_A':best['symmetry_corrected_RMSD_A'],'best_sampled_rank':best['rank'],
                         'number_of_poses':len(rows),'runtime_seconds':job['elapsed_seconds']})
    summary=[]
    for name in dict.fromkeys(j['name'] for j in run['jobs']):
        rows=[r for r in seedrows if r['variant']==name]
        if not rows:continue
        top=[r['top1_RMSD_A'] for r in rows]; passed=sum(r['top1_pass'] for r in rows)
        summary.append({'variant':name,'target':rows[0]['target'],'role':rows[0]['role'],
                        'n_completed':len(rows),'top1_pass_count':passed,'planned_seeds':3,
                        'top1_RMSD_mean_A':round(statistics.mean(top),6),
                        'top1_RMSD_sd_A':round(statistics.stdev(top),6) if len(top)>1 else '',
                        'top1_RMSD_min_A':min(top),'top1_RMSD_max_A':max(top),
                        'best_sampled_RMSD_min_A':min(r['best_sampled_RMSD_A'] for r in rows),
                        'status':'PASS' if len(rows)==3 and passed==3 else 'FAIL' if len(rows)==3 else 'INCOMPLETE'})
    csvout(out/'all_pose_RMSD.csv',detail);csvout(out/'per_seed_results.csv',seedrows);csvout(out/'validation_summary.csv',summary)
    (out/'validation_summary.json').write_text(json.dumps({'run_status':run.get('status','RUNNING'),'summary':summary,'seeds':seedrows},indent=2)+'\n')
    print(json.dumps({'complete_jobs':len(seedrows),'summary':summary},indent=2),flush=True)

if __name__=='__main__':main()
