import csv,hashlib,itertools,json,shutil,statistics,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,r'H:\NT\xinnei\MI\PFOS\tougao\revise\tmp\12_docking_rescue\00_protocol\software\python_packages')
import numpy as np
from rdkit import Chem
from meeko import PDBQTMolecule,RDKitMolCreate

def models(path):
    out=[];atoms=[];score=None
    for l in Path(path).read_text().splitlines():
        if l.startswith('MODEL'):atoms=[];score=None
        elif l.startswith('REMARK VINA RESULT:'):score=float(l.split()[3])
        elif l.startswith(('ATOM  ','HETATM')):atoms.append(l)
        elif l.startswith('ENDMDL'):out.append({'score':score,'atoms':atoms})
    return out
def write_csv(path,rows):
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    m=json.loads((ROOT/'stage_b_manifest.json').read_text());assert m['status']=='COMPLETED'
    results=ROOT/'results';rows=[];top_mols={};contacts=[]
    rec=[]
    receptor=ROOT/'prepared/receptors/PLAU_A/receptor.pdbqt'
    for l in receptor.read_text().splitlines():
        if l.startswith(('ATOM  ','HETATM')) and not l[77:].strip().startswith('H'):
            rec.append((f"{l[17:20].strip()}:{l[21]}:{l[22:26].strip()}{l[26].strip()}",np.array([float(l[30:38]),float(l[38:46]),float(l[46:54])])))
    figure_dir=ROOT/'display_structures';figure_dir.mkdir(exist_ok=True)
    for j in m['jobs']:
        assert j['status']=='COMPLETED'
        if j['analysis']!='PFOS':continue
        docked=models(j['output']);assert docked
        rows.append({'condition':j['condition'],'seed':j['seed'],'top1_Vina_score_kcal_mol':docked[0]['score'],
                     'n_poses':len(docked),'output':j['output'],'config':j['config']})
        mols=RDKitMolCreate.from_pdbqt_mol(PDBQTMolecule.from_file(j['output'],skip_typing=True))
        assert len(mols)==1 and mols[0] is not None
        mol=Chem.RemoveHs(mols[0]);assert mol.GetNumAtoms()==29 and Chem.GetFormalCharge(mol)==-1
        top_mols[(j['condition'],j['seed'])]=mol
        output=ROOT/'poses_sdf/PFOS_PLAU'/j['condition'];output.mkdir(parents=True,exist_ok=True)
        writer=Chem.SDWriter(str(output/f"seed_{j['seed']}_all_poses.sdf"))
        for i in range(mol.GetNumConformers()):
            mol.SetProp('rank',str(i+1));mol.SetProp('Vina_score_kcal_mol',str(docked[i]['score']))
            writer.write(mol,confId=i)
        writer.close()
        xyz=np.array(mol.GetConformer(0).GetPositions());group={}
        for residue,p in rec:
            d=float(np.min(np.linalg.norm(xyz-p,axis=1)))
            group[residue]=min(group.get(residue,float('inf')),d)
        if j['condition']=='pocket':
            contacts.extend({'seed':j['seed'],'residue':k,'min_heavy_atom_distance_A':round(v,4),'contact_cutoff_A':4.0} for k,v in sorted(group.items()) if v<=4.0)
        if j['condition']=='pocket' and j['seed']==20260920:
            w=Chem.SDWriter(str(figure_dir/'PLAU_PFOS_top1_seed20260920.sdf'))
            mol.SetProp('rank','1');mol.SetProp('Vina_score_kcal_mol',str(docked[0]['score']));w.write(mol,confId=0);w.close()
    stats=[]
    for cond in ['pocket','surface_reference']:
        values=[r['top1_Vina_score_kcal_mol'] for r in rows if r['condition']==cond]
        assert len(values)==3
        stats.append({'condition':cond,'n_search_seeds':3,'mean_Vina_score_kcal_mol':statistics.mean(values),
                      'sd_Vina_score_kcal_mol':statistics.stdev(values),'min':min(values),'max':max(values)})
    original=ROOT/'docking/PLAU_zwitterion_primary/seed_20260921.pdbqt'
    replay=next(j for j in m['jobs'] if j['analysis']=='native_deterministic_replay')
    original_data=models(original);replay_data=models(replay['output'])
    replay_check={'same_seed':20260921,'n_original_poses':len(original_data),'n_replay_poses':len(replay_data),
                  'scores_identical':[r['score'] for r in original_data]==[r['score'] for r in replay_data],
                  'atom_records_identical':[r['atoms'] for r in original_data]==[r['atoms'] for r in replay_data],
                  'file_bytes_identical':sha(original)==sha(replay['output']),
                  'original_sha256':sha(original),'replay_sha256':sha(replay['output'])}
    assert replay_check['scores_identical'] and replay_check['atom_records_identical']
    shutil.copy2(ROOT/'prepared/receptors/PLAU_A/receptor.pdb',figure_dir/'PLAU_receptor_dry.pdb')
    shutil.copy2(ROOT/'prepared/ligands/PLAU_AMH_zwitterion/reference.sdf',figure_dir/'PLAU_native_experimental_reference.sdf')
    shutil.copy2(ROOT/'poses_sdf/PLAU_zwitterion_primary/seed_20260920_top1.sdf',figure_dir/'PLAU_native_redocked_top1_seed20260920.sdf')
    display={'selection':'Predesignated first seed 20260920, rank 1; not selected by lowest RMSD or strongest score.',
             'protein':'PLAU_receptor_dry.pdb','experimental_native':'PLAU_native_experimental_reference.sdf',
             'redocked_native':'PLAU_native_redocked_top1_seed20260920.sdf','PFOS':'PLAU_PFOS_top1_seed20260920.sdf',
             'frame':'Original 6NMB coordinates, no ligand superposition.',
             'warning':'Experimental native, redocked native and PFOS represent separate occupancy states; do not interpret their overlay as simultaneous binding.'}
    (figure_dir/'manifest.json').write_text(json.dumps(display,indent=2)+'\n')
    write_csv(results/'PLAU_PFOS_per_seed.csv',rows);write_csv(results/'PLAU_PFOS_summary.csv',stats)
    write_csv(results/'PLAU_PFOS_pocket_contacts.csv',contacts)
    delta=stats[1]['mean_Vina_score_kcal_mol']-stats[0]['mean_Vina_score_kcal_mol']
    payload={'summary':stats,'surface_minus_pocket_kcal_mol':delta,'native_deterministic_replay':replay_check,
             'interpretation':'Model-specific docking scores only, not experimental affinity, specificity, binding or inhibition.',
             'ALPL':'No validated PFOS rerun: native redocking failed.',
             'not_performed':'No new water sensitivity, MD, HSA reference rerun or wet-lab binding assay in this bounded stage.'}
    (results/'stage_b_summary.json').write_text(json.dumps(payload,indent=2)+'\n')
    print(json.dumps(payload,indent=2))

if __name__=='__main__':main()
