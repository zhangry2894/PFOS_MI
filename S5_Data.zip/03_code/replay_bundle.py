"""Replay frozen docking inputs into a NEW directory; Python standard library only."""
import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def local_path(archived):
    # Configs intentionally retain the original runtime's absolute paths.
    parts = str(archived).replace('\\', '/').split('/')
    marker = 'docking_rescue_v2_20261016'
    if marker not in parts:
        raise ValueError('Unrecognized archived path: ' + str(archived))
    relative = Path(*parts[parts.index(marker) + 1:])
    result = (ROOT / relative).resolve()
    if not result.is_relative_to(ROOT.resolve()):
        raise ValueError('Path escapes bundle')
    return result

def scientific_records(path):
    return [line for line in Path(path).read_text().splitlines()
            if line.startswith(('REMARK VINA RESULT:', 'ATOM  ', 'HETATM'))]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--vina', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--job', help='One exact job ID; omitted means all archived jobs')
    args = parser.parse_args()
    binary = Path(args.vina).resolve()
    destination = Path(args.output).resolve()
    if destination.exists():
        raise FileExistsError('Output must be new; refusing overwrite: ' + str(destination))
    if destination.is_relative_to(ROOT.resolve()):
        raise ValueError('Output must be outside the immutable result bundle')
    inputs = json.loads((ROOT / 'inputs_manifest.json').read_text())
    expected = inputs['software_checksums'][inputs['vina']]
    if sha(binary) != expected:
        raise ValueError('Vina binary SHA256 does not match recorded executable')
    jobs = []
    for name in ['run_manifest.json', 'stage_b_manifest.json']:
        jobs.extend(json.loads((ROOT / name).read_text())['jobs'])
    if args.job:
        jobs = [j for j in jobs if j['id'] == args.job]
        if len(jobs) != 1:
            raise ValueError('Job ID not uniquely found')
    # Check all frozen inputs before creating any output or running Vina.
    for job in jobs:
        for old_path, digest in job['input_sha256'].items():
            if sha(local_path(old_path)) != digest:
                raise ValueError('Frozen input mismatch: ' + old_path)
    destination.mkdir(parents=True)
    report = {'started_utc': datetime.now(timezone.utc).isoformat(),
              'bundle': str(ROOT), 'vina_sha256': sha(binary), 'jobs': []}
    for job in jobs:
        config = {}
        for line in local_path(job['config']).read_text().splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                config[k.strip()] = v.strip()
        for key in ['receptor', 'ligand']:
            config[key] = str(local_path(config[key]))
        output = destination / (job['id'] + '.pdbqt')
        config['out'] = str(output)
        config_path = destination / (job['id'] + '.txt')
        config_path.write_text('\n'.join(f'{k} = {v}' for k, v in config.items()) + '\n')
        log_path = destination / (job['id'] + '.log')
        with log_path.open('w') as log:
            result = subprocess.run([str(binary), '--config', str(config_path)], stdout=log,
                                    stderr=subprocess.STDOUT, timeout=1800,
                                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        row = {'job': job['id'], 'exit_code': result.returncode, 'output': str(output)}
        if output.exists():
            archived = local_path(job['output'])
            row.update(output_sha256=sha(output), archived_sha256=sha(archived),
                       file_bytes_identical=sha(output) == sha(archived),
                       scientific_records_identical=scientific_records(output) == scientific_records(archived))
        report['jobs'].append(row)
        report['ended_utc'] = datetime.now(timezone.utc).isoformat()
        (destination / 'replay_report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(row), flush=True)
        if result.returncode or not output.exists():
            raise RuntimeError('Replay failed; recorded, no automatic retry')

if __name__ == '__main__':
    main()
