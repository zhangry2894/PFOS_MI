# Native PyMOL renders are assembled without resampling coordinates or pose fitting.
suppressPackageStartupMessages({library(ggplot2);library(grid);library(ragg);library(svglite);library(png)})
f<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
root<-dirname(normalizePath(f,winslash='/'))
out<-file.path(root,'outputs');dir.create(out,showWarnings=FALSE)
pr<-file.path(dirname(root),'pymol','renders')
read<-function(n)read.csv(file.path(root,'inputs',n),fileEncoding='UTF-8-BOM',check.names=FALSE)
contacts<-read('PLAU_PFOS_display_seed20260920_contacts_le4A.csv')
xy<-read('PLAU_PFOS_2D_atom_coordinates.csv')
bond<-read('overlay_ligand_bonds.csv');atoms<-read('overlay_ligand_atom_coordinates.csv')
stopifnot(nrow(contacts)==14,all(contacts$seed==20260920),all(contacts$distance_A<=4),nrow(xy)==29,sum(xy$formal_charge)==-1)
check<-sqrt((contacts$receptor_x-contacts$ligand_x)^2+(contacts$receptor_y-contacts$ligand_y)^2+(contacts$receptor_z-contacts$ligand_z)^2)
stopifnot(max(abs(check-contacts$distance_A))<1e-10)
pb<-subset(bond,target=='PLAU' & molecule=='PFOS_dry_top1')
pb$x<-xy$x2d[match(pb$atom_i_0based,xy$atom_index_0based)];pb$y<-xy$y2d[match(pb$atom_i_0based,xy$atom_index_0based)]
pb$xend<-xy$x2d[match(pb$atom_j_0based,xy$atom_index_0based)];pb$yend<-xy$y2d[match(pb$atom_j_0based,xy$atom_index_0based)]
pb2<-subset(pb,bond_order==2)
d<-sqrt((pb2$xend-pb2$x)^2+(pb2$yend-pb2$y)^2)
dx<--.07*(pb2$yend-pb2$y)/d;dy<-.07*(pb2$xend-pb2$x)/d
pb2$x<-pb2$x+dx;pb2$xend<-pb2$xend+dx;pb2$y<-pb2$y+dy;pb2$yend<-pb2$yend+dy
top<-c('SER:A:195','GLY:A:193','GLY:A:216','CYS:A:191','VAL:A:213','SER:A:190','GLY:A:226')
bottom<-c('HIS:A:57','GLN:A:192','GLY:A:218','TRP:A:215','CYS:A:219','SER:A:214','ASP:A:189')
node<-data.frame(residue=c(top,bottom),nx=rep(seq(-8.2,9.4,length.out=7),2),ny=rep(c(4.3,-4.6),each=7))
contacts<-merge(contacts,node,by='residue',sort=FALSE)
contacts$lx<-xy$x2d[match(contacts$ligand_atom_index_0based,xy$atom_index_0based)]
contacts$ly<-xy$y2d[match(contacts$ligand_atom_index_0based,xy$atom_index_0based)]
contacts$edge_y<-contacts$ny-ifelse(contacts$ny>0,.75,-.75)
contacts$label<-sprintf('%s%s\n%s  %.2f \u00c5',contacts$residue_name,contacts$residue_number,contacts$receptor_atom,contacts$distance_A)
xy$label<-ifelse(xy$element=='C','',ifelse(xy$formal_charge==-1,paste0(xy$element,'-'),xy$element))
pa<-ggplot()+
 geom_segment(data=contacts,aes(x=nx,y=edge_y,xend=lx,yend=ly),linetype=3,linewidth=.3,colour='#A5ADB3')+
 geom_segment(data=pb,aes(x=x,y=y,xend=xend,yend=yend),linewidth=.5,colour='#3D4A52')+
 geom_segment(data=pb2,aes(x=x,y=y,xend=xend,yend=yend),linewidth=.5,colour='#3D4A52')+
 geom_point(data=subset(xy,element=='C'),aes(x2d,y2d),size=.65,colour='#3D4A52')+
 geom_label(data=subset(xy,element!='C'),aes(x2d,y2d,label=label,colour=element),size=8/ggplot2::.pt,family='Arial',fill='white',label.size=0,label.padding=unit(.12,'mm'),show.legend=FALSE)+
 scale_colour_manual(values=c(F='#327749',O='#BB3F43',S='#876418',C='#283741'))+
 geom_label(data=contacts,aes(nx,ny,label=label),size=8/ggplot2::.pt,family='Arial',fill='#F4F6F8',colour='#202830',label.size=.2,label.padding=unit(.8,'mm'),lineheight=1.05)+
 coord_equal(xlim=c(-9.7,11),ylim=c(-5.55,5.4),expand=FALSE,clip='off')+
 theme_void(base_family='Arial',base_size=9)+theme(plot.margin=margin(0,0,0,0))

txt<-function(label,x,y,size=9,bold=FALSE,just='left',colour='#202830')grid.text(label,x=unit(x,'npc'),y=unit(y,'npc'),just=just,gp=gpar(fontfamily='Arial',fontsize=size,fontface=if(bold)'bold'else'plain',col=colour))
raster_panel<-function(name,x,y,w,h){
 im<-readPNG(file.path(pr,paste0(name,'.png')))
 pushViewport(viewport(x=x,y=y,width=w,height=h))
 # Both physical panel dimensions and native aspect ratio determine the fit.
 W<-convertWidth(unit(1,'npc'),'mm',valueOnly=TRUE);H<-convertHeight(unit(1,'npc'),'mm',valueOnly=TRUE)
 ratio<-dim(im)[2]/dim(im)[1];ww<-min(W,H*ratio);hh<-ww/ratio
 grid.raster(im,width=unit(ww,'mm'),height=unit(hh,'mm'),interpolate=FALSE)
 popViewport()
}
fig4<-function(){
 grid.newpage()
 txt('A',.018,.975,12,TRUE);txt('PFOS\u2013PLAU residue proximity',.06,.975,10,TRUE)
 print(pa,newpage=FALSE,vp=viewport(x=.5,y=.75,width=.98,height=.42))
 txt('Distances are geometric proximity, not assigned hydrogen bonds.',.035,.525,8)
 txt('B',.018,.493,12,TRUE);txt('Protein overview',.06,.493,10,TRUE)
 txt('C',.385,.493,12,TRUE);txt('Pocket detail',.425,.493,10,TRUE)
 raster_panel('Fig4B_PLAU_overview',.19,.278,.36,.40)
 raster_panel('Fig4C_PLAU_pocket',.682,.278,.62,.40)
 txt('Carbon: PFOS',.08,.045,8,colour='#098F8F');txt('AMH crystal reference',.32,.045,8,colour='#E37826')
 txt('O red  |  N blue  |  S yellow  |  F green',.60,.045,8)
 txt('First predefined seed 20260920; dry-pocket rank 1. Alternative poses, not simultaneous occupancy.',.035,.018,8)
}
s4<-function(){
 grid.newpage()
 titles<-c('ALPL A+B | dry','PLAU | dry','PLAU | fixed water O')
 names<-c('S4A_ALPL_AB_dry','S4B_PLAU_dry','S4C_PLAU_fixed_water')
 values<-c(9.036,1.911,4.976)
 for(i in 1:3){
   left<-(i-1)/3
   txt(LETTERS[i],left+.018,.96,12,TRUE)
   txt(titles[i],left+1/6,.88,9,TRUE,just='center')
   raster_panel(names[i],left+1/6,.57,.323,.53)
   txt(sprintf('Top1 RMSD %.3f \u00c5',values[i]),left+1/6,.25,9,just='center')
   txt(if(i==2)'PASS (\u22642 \u00c5)'else'FAIL (>2 \u00c5)',left+1/6,.18,9,TRUE,just='center',colour=if(i==2)'#176B82'else'#C46C2B')
 }
 txt('Carbon: native reference',.04,.08,8,colour='#098F8F')
 txt('Redocked rank 1',.40,.08,8,colour='#E37826')
 txt('Fixed water oxygen',.70,.08,8,colour='#52ADDE')
 txt('First predefined seed 20260920; unchanged receptor frame. PLAU panels share camera and scale.',.04,.025,8)
}
save<-function(draw,stem,w,h){
 ww<-w/25.4;hh<-h/25.4
 cairo_pdf(file.path(out,paste0(stem,'.pdf')),width=ww,height=hh,family='Arial');draw();dev.off()
 svglite(file.path(out,paste0(stem,'.svg')),width=ww,height=hh,bg='white');draw();dev.off()
 agg_tiff(file.path(out,paste0(stem,'.tif')),width=ww,height=hh,units='in',res=600,compression='lzw',background='white');draw();dev.off()
 agg_jpeg(file.path(out,paste0(stem,'.jpg')),width=ww,height=hh,units='in',res=600,quality=98,background='white');draw();dev.off()
 agg_png(file.path(out,paste0(stem,'_preview.png')),width=ww,height=hh,units='in',res=250,background='white');draw();dev.off()
}
save(fig4,'Fig4',190,220)
save(s4,'S4_Fig',190,94)
write.csv(contacts,file.path(out,'Fig4A_all14_contacts_and_layout.csv'),row.names=FALSE)
writeLines(c('Core conclusion: the retained PFOS pose can be visualized but does not establish binding.','Fig4A all14 nearest-residue contacts retained; B whole receptor; C pocket.','S4 all three original first-seed Top1 controls, including failed ALPL and fixed-water PLAU.','Only display label layout, camera and graphics changed. No new docking or independent ligand alignment.','Structure panels are native PyMOL rasters embedded in R PDF/SVG; only 2D maps and layout text are editable vector objects.'),file.path(out,'STRUCTURAL_FIGURE_CONTRACT.txt'))
cat('STRUCTURAL_PLATES_COMPLETE\n')
