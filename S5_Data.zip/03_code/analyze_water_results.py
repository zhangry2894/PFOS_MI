"""Analyse frozen water-site jobs, without fitting or superposing ligand coordinates.
Usage: python analyze_water_results.py [--root DIR] [--packages OPTIONAL_SITE_PACKAGES]
"""
from pathlib import Path
import argparse, sys, json, csv, statistics, hashlib, itertools
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--packages',type=Path);a=p.parse_args()
ROOT=a.root.resolve();BASE=ROOT/'corrected_baseline'
if a.packages:sys.path.insert(0,str(a.packages))
import numpy as np
from rdkit import Chem
from rdkit.Chem import rdMolAlign,rdMolDescriptors
from meeko import PDBQTMolecule,RDKitMolCreate

def csvout(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if rows:
        with path.open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def models(path):
    out=[];atoms={};score=None;rank=None
    for l in Path(path).read_text().splitlines():
        if l.startswith('MODEL '):atoms={};rank=int(l.split()[1]);score=None
        elif l.startswith('REMARK VINA RESULT:'):score=float(l.split()[3])
        elif l.startswith(('ATOM  ','HETATM')):atoms[str(int(l[6:11]))]=[float(l[30:38]),float(l[38:46]),float(l[46:54])]
        elif l.startswith('ENDMDL'):out.append({'rank':rank,'score':score,'atoms':atoms})
    return out
def reconstruct(path):
    mols=RDKitMolCreate.from_pdbqt_mol(PDBQTMolecule.from_file(str(path),skip_typing=True));assert len(mols)==1 and mols[0] is not None
    return Chem.RemoveHs(mols[0])
def stats(values):return {'n_search_seeds':len(values),'mean':statistics.mean(values),'sd':statistics.stdev(values),'minimum':min(values),'maximum':max(values)}

def main():
    run=json.loads((ROOT/'water_run_manifest.json').read_text());assert run['status']=='COMPLETED'
    folder=BASE/'prepared/ligands/PLAU_AMH_zwitterion'
    ref=next(m for m in Chem.SDMolSupplier(str(folder/'reference.sdf'),removeHs=True) if m is not None)
    xyz=np.asarray(ref.GetConformer().GetPositions());mapping=json.loads((folder/'atom_mapping.json').read_text())['pdbqt_serial_to_reference_index']
    assert rdMolDescriptors.CalcMolFormula(ref)=='C8H15NO2'
    perms=set(ref.GetSubstructMatches(ref,uniquify=False,useChirality=True,maxMatches=100000));group=ref.GetSubstructMatch(Chem.MolFromSmarts('[CX3](=[OX1])[O-]'));assert len(group)==3
    oa,ob=group[1:]
    for match in list(perms):perms.add(tuple(ob if v==oa else oa if v==ob else v for v in match))
    perms=sorted(perms)
    original=reconstruct(folder/'prepared.pdbqt');originalxyz=np.asarray(original.GetConformer().GetPositions());identitymap=[]
    for i,atom in enumerate(original.GetAtoms()):
        candidates=[j for j,b in enumerate(ref.GetAtoms()) if atom.GetAtomicNum()==b.GetAtomicNum() and np.linalg.norm(originalxyz[i]-xyz[j])<0.002];assert len(candidates)==1;identitymap.append((i,candidates[0]))
    detail=[];seedrows=[];independent=[];pfos=[]
    for job in run['jobs']:
        output=ROOT/'water_outputs'/Path(job['output']).name;poses=models(output);assert poses
        if job['analysis']=='PFOS':
            mol=reconstruct(output);assert Chem.GetFormalCharge(mol)==-1 and mol.GetNumAtoms()==29
            assert Chem.MolToSmiles(mol)==Chem.MolToSmiles(reconstruct(BASE/'prepared/ligands/PFOS_anion/prepared.pdbqt'))
            pfos.append({'condition':'fixed_water_oxygen','seed':job['seed'],'top1_Vina_score_kcal_mol':poses[0]['score'],'number_of_poses':len(poses)});continue
        rows=[]
        for model in poses:
            pose=np.zeros_like(xyz)
            for serial,index in mapping.items():pose[index]=model['atoms'][serial]
            identity=float(np.sqrt(np.mean(np.sum((xyz-pose)**2,axis=1))))
            rmsd=min(float(np.sqrt(np.mean(np.sum((xyz-pose[np.asarray(perm)])**2,axis=1)))) for perm in perms)
            rows.append({'job_id':job['id'],'condition':'fixed_water_oxygen','seed':job['seed'],'replay':job['analysis']=='native_replay','rank':model['rank'],'score_kcal_mol':model['score'],'identity_RMSD_A':identity,'RMSD_A':rmsd,'pass_le2A':rmsd<=2})
        detail+=rows
        mol=reconstruct(output);assert Chem.MolToSmiles(mol)==Chem.MolToSmiles(original);before=np.asarray(mol.GetConformer(0).GetPositions()).copy()
        independent_identity=rdMolAlign.CalcRMS(mol,ref,prbId=0,refId=0,map=[identitymap],symmetrizeConjugatedTerminalGroups=False)
        assert abs(independent_identity-rows[0]['identity_RMSD_A'])<1e-6 and np.array_equal(before,mol.GetConformer(0).GetPositions())
        independent.append({'job_id':job['id'],'independent_identity_RMSD_A':independent_identity,'primary_identity_RMSD_A':rows[0]['identity_RMSD_A'],'difference_A':abs(independent_identity-rows[0]['identity_RMSD_A']),'coordinates_not_aligned':True,'chemical_graph_unchanged':True})
        if job['analysis']=='native':
            best=min(rows,key=lambda r:r['RMSD_A']);seedrows.append({'condition':'PLAU_zwitterion_fixed_water_oxygen','seed':job['seed'],'top1_RMSD_A':rows[0]['RMSD_A'],'top1_identity_RMSD_A':rows[0]['identity_RMSD_A'],'top1_score_kcal_mol':rows[0]['score_kcal_mol'],'top1_pass':rows[0]['pass_le2A'],'best_sampled_RMSD_A':best['RMSD_A'],'best_sampled_rank':best['rank']})
    primary=ROOT/'water_outputs/native_PLAU_water_oxygen_seed20260920.pdbqt';replay=ROOT/'water_outputs/native_PLAU_water_oxygen_seed20260920_replay.pdbqt'
    replayqa={'seed':20260920,'file_bytes_identical':sha(primary)==sha(replay),'primary_sha256':sha(primary),'replay_sha256':sha(replay),'duplicate_not_independent_seed':True};assert replayqa['file_bytes_identical']
    dry=json.loads((BASE/'results/stage_b_summary.json').read_text());drymean=next(s['mean_Vina_score_kcal_mol'] for s in dry['summary'] if s['condition']=='pocket')
    summary={'native_wet':{**stats([r['top1_RMSD_A'] for r in seedrows]),'units':'Angstrom','top1_pass_count':sum(r['top1_pass'] for r in seedrows),'status':'PASS' if all(r['top1_pass'] for r in seedrows) else 'FAIL','seeds':seedrows},'pfos_wet_scores':{**stats([r['top1_Vina_score_kcal_mol'] for r in pfos]),'units':'kcal/mol','seeds':pfos},'wet_minus_dry_score_kcal_mol':statistics.mean(r['top1_Vina_score_kcal_mol'] for r in pfos)-drymean,'deterministic_replay':replayqa,'independent_identity_checks':independent,'water_model':'Three fixed neutral OA oxygen sites only; no water hydrogens or orientation sampling; not full hydration','native_rmsd':'fixed receptor frame; chirality-checked graph automorphisms plus carboxylate resonance symmetry; no superposition'}
    (ROOT/'water_summary.json').write_text(json.dumps(summary,indent=2))
    csvout(ROOT/'results/water_all_native_pose_RMSD.csv',detail);csvout(ROOT/'results/water_native_per_seed.csv',seedrows);csvout(ROOT/'results/water_PFOS_per_seed.csv',pfos);csvout(ROOT/'results/water_independent_identity_checks.csv',independent)
    print(json.dumps(summary,indent=2))
if __name__=='__main__':main()
