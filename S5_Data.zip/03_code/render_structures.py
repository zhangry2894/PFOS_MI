"""Native PyMOL ray tracing of frozen first-seed poses.

Execute inside PyMOL using ``run render_structures.py`` or
``pymol -cq render_structures.py``. No docking, fitting, atom transformations,
or synthetic coordinate projection is performed. R assembles final figure plates.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import os
from pymol import cmd

ROOT = Path(os.environ.get('PFOS_PYMOL_ROOT',Path.cwd())).resolve()
INPUT = ROOT / 'inputs'
OUT = ROOT / 'renders'
OUT.mkdir(exist_ok=True)
QA = []
VIEWS = {}

def snapshot(selection):
    return [(a.name,a.symbol,a.resn,a.resi,a.chain,tuple(a.coord)) for a in cmd.get_model(selection).atom]

def coords_unchanged(name,before):
    after=snapshot(name)
    assert before == after, 'Coordinates changed: '+name
    QA.append({'object':name,'atoms':len(after),'coordinates_unchanged_exactly':True})

def load(path,name):
    cmd.load(str(INPUT/path),name)
    assert cmd.count_states(name) == 1
    atoms=snapshot(name)
    lines=(INPUT/path).read_text().splitlines()
    if path.endswith('.sdf'):
        n=int(lines[3][:3])
        source=[tuple(float(r[k:k+10]) for k in (0,10,20)) for r in lines[4:4+n]]
    else:
        source=[tuple(float(r[k:k+8]) for k in (30,38,46)) for r in lines if r.startswith(('ATOM  ','HETATM'))]
    assert len(source)==len(atoms),(name,len(source),len(atoms))
    error=max(abs(x-y) for coords,a in zip(source,atoms) for x,y in zip(coords,a[-1]))
    assert error < 0.0001,(name,error)
    QA.append({'object':name,'source_coordinate_load_error_A':error,'source_coordinate_check':True})
    return atoms

def common():
    cmd.reinitialize()
    cmd.bg_color('white')
    cmd.viewport(1200,900)
    cmd.set('retain_order',1)
    cmd.set('orthoscopic',1)
    cmd.set('ray_opaque_background',1)
    cmd.set('ray_trace_mode',0)
    cmd.set('antialias',2)
    cmd.set('ray_shadows',0)
    cmd.set('depth_cue',0)
    cmd.set('specular',0.18)
    cmd.set('shininess',20)
    cmd.set('ambient',0.48)
    cmd.set('direct',0.65)
    cmd.set('cartoon_fancy_helices',1)
    cmd.set('cartoon_smooth_loops',1)
    cmd.set('cartoon_sampling',14)
    cmd.set('stick_radius',0.18)
    cmd.set('stick_quality',20)
    cmd.set('sphere_quality',3)
    cmd.set('valence',1)
    cmd.set('valence_size',0.12)
    cmd.set('label_color','black')
    cmd.set('label_font_id',7)
    cmd.set('label_size',30)
    cmd.set('label_outline_color','white')
    cmd.set('label_shadow_mode',0)
    cmd.set('float_labels',1)
    cmd.set('label_connector',1)
    cmd.set('dash_color','gray40')
    cmd.set('dash_width',2)
    cmd.set('dash_gap',0.20)
    cmd.set('dash_length',0.20)
    cmd.set_color('protein_gray',[0.76,0.79,0.81])
    cmd.set_color('pocket_gray',[0.56,0.61,0.64])
    cmd.set_color('ligand_teal',[0.04,0.56,0.56])
    cmd.set_color('reference_orange',[0.89,0.47,0.15])
    cmd.set_color('fluorine_green',[0.48,0.76,0.45])
    cmd.set_color('oxygen_red',[0.86,0.21,0.18])
    cmd.set_color('nitrogen_blue',[0.24,0.42,0.81])
    cmd.set_color('sulfur_gold',[0.91,0.71,0.16])
    cmd.set_color('water_blue',[0.32,0.68,0.87])

def elements(selection,carbon):
    cmd.color(carbon,selection)
    for element,color in [('O','oxygen_red'),('N','nitrogen_blue'),('S','sulfur_gold'),('F','fluorine_green')]:
        cmd.color(color,f'({selection}) and elem {element}')

def ligand(name,carbon,radius=.19):
    cmd.hide('everything',name)
    cmd.show('sticks',name)
    cmd.set('stick_radius',radius,name)
    elements(name,carbon)

def receptor(name):
    cmd.hide('everything',name)
    cmd.show('cartoon',f'{name} and polymer.protein')
    cmd.color('protein_gray',name)
    cmd.show('spheres',f'{name} and elem Zn+Mg+Ca')
    cmd.set('sphere_scale',.32,f'{name} and elem Zn+Mg+Ca')
    cmd.color('gray50',f'{name} and elem Zn+Mg+Ca')

def save(name,width=2400,height=1800):
    VIEWS[name]=list(cmd.get_view())
    cmd.deselect()
    cmd.save(str(OUT/(name+'.pse')))
    cmd.png(str(OUT/(name+'.png')),width=width,height=height,dpi=600,ray=1,quiet=0)

def fig4():
    common()
    before={}
    before['plau']=load('PLAU_receptor_dry.pdb','plau')
    before['pfos']=load('PLAU_PFOS_dry_top1_seed20260920.sdf','pfos')
    before['amh_reference']=load('PLAU_native_reference.sdf','amh_reference')
    assert cmd.count_atoms('pfos') == 29
    receptor('plau')
    ligand('pfos','ligand_teal',.23)
    ligand('amh_reference','reference_orange',.15)
    cmd.set('stick_transparency',.12,'amh_reference')
    cmd.orient('plau and polymer.protein')
    cmd.turn('y',25)
    cmd.turn('x',15)
    cmd.zoom('plau and polymer.protein',buffer=2.0)
    save('Fig4B_PLAU_overview',2400,1800)

    cmd.select('pocket','byres ((plau and polymer.protein) within 4.0 of pfos)')
    assert len({(a.chain,a.resi) for a in cmd.get_model('pocket').atom}) == 14
    cmd.show('sticks','pocket')
    cmd.set('stick_radius',.075,'pocket')
    cmd.color('pocket_gray','pocket')
    cmd.set('stick_transparency',.25,'pocket')
    # Overview carries the full cartoon context. In the pocket view the 14
    # actual contacting residues remain as thin sticks; cartoon ribbons are
    # hidden so they cannot obscure ligand atoms or annotations.
    cmd.hide('cartoon','plau')
    cmd.orient('pfos or amh_reference')
    cmd.turn('y',20)
    cmd.turn('x',-15)
    cmd.zoom('pfos or amh_reference',buffer=5.5)
    # Five pre-existing labels are retained. All 14 contacts remain in the source
    # table and panel A. These distances are geometric proximity, not H-bonds.
    label_residues={'SER:A:190','SER:A:195','GLY:A:216','HIS:A:57','ASP:A:189'}
    offsets={'SER:A:190':[0,-11,8], 'SER:A:195':[-6,-7,8],
             'GLY:A:216':[0,8,8], 'HIS:A:57':[-9,9,8],
             'ASP:A:189':[2,-8,8]}
    rows=list(csv.DictReader((INPUT/'PFOS_contacts_le4A.csv').open(encoding='utf-8-sig')))
    contact_checks=[]
    for row in rows:
        index=int(row['ligand_atom_index_0based'])+1
        resi=row['residue_number']+row['insertion_code']
        rsel=f'plau and chain {row["chain"]} and resi {resi} and name {row["receptor_atom"]}'
        psel=f'pfos and index {index}'
        assert cmd.count_atoms(rsel)==1 and cmd.count_atoms(psel)==1
        distance=cmd.get_distance(rsel,psel)
        assert abs(distance-float(row['distance_A']))<.0001
        contact_checks.append({'residue':row['residue'],'distance_A':distance,'matches_source':True})
        if row['residue'] not in label_residues:
            continue
        name='proximity_'+row['residue_name']+resi
        cmd.distance(name,rsel,psel,label=0)
        text=f"{row['residue_name'].title()}{resi}:{row['receptor_atom']}\n{distance:.2f} Å"
        cmd.label(rsel,repr(text))
        cmd.set('label_position',offsets[row['residue']],rsel)
    cmd.clip('slab',80)
    save('Fig4C_PLAU_pocket',2400,1800)
    (OUT/'contact_distance_QA.json').write_text(json.dumps(contact_checks,indent=2))
    for name,record in before.items():
        coords_unchanged(name,record)

def s4_plau():
    common()
    before={}
    for file,name in [('PLAU_receptor_dry.pdb','plau'),('PLAU_receptor_fixed_water.pdb','plau_water'),
                      ('PLAU_native_reference.sdf','native_reference'),
                      ('PLAU_native_redocked_top1_seed20260920.sdf','redocked_dry'),
                      ('PLAU_native_redocked_water_top1_seed20260920.sdf','redocked_water')]:
        before[name]=load(file,name)
    receptor('plau')
    cmd.hide('everything','plau_water')
    ligand('native_reference','ligand_teal',.21)
    ligand('redocked_dry','reference_orange',.17)
    ligand('redocked_water','reference_orange',.17)
    cmd.select('native_neighborhood','byres (plau within 5 of native_reference)')
    cmd.hide('cartoon','plau')
    cmd.show('cartoon','byres ((plau and polymer.protein) within 10 of native_reference)')
    cmd.set('cartoon_transparency',.85,'plau')
    cmd.orient('native_reference or redocked_dry or redocked_water')
    cmd.turn('y',30)
    cmd.turn('x',-10)
    cmd.zoom('native_reference or redocked_dry or redocked_water',buffer=4.0)
    shared_view=cmd.get_view()
    cmd.disable('redocked_water')
    save('S4B_PLAU_dry',2200,1800)
    cmd.disable('redocked_dry')
    cmd.enable('redocked_water')
    waters='plau_water and resn HOH and resi 412+435+440 and name O'
    assert cmd.count_atoms(waters)==3
    cmd.show('spheres',waters)
    cmd.color('water_blue',waters)
    cmd.set('sphere_scale',.35,waters)
    cmd.set_view(shared_view)
    save('S4C_PLAU_fixed_water',2200,1800)
    assert VIEWS['S4B_PLAU_dry'] == VIEWS['S4C_PLAU_fixed_water']
    for name,record in before.items():
        coords_unchanged(name,record)

def s4_alpl():
    common()
    before={}
    before['alpl']=load('ALPL_receptor_dry.pdb','alpl')
    before['native_reference']=load('ALPL_native_reference.sdf','native_reference')
    before['redocked']=load('ALPL_native_redocked_top1_seed20260920.sdf','redocked')
    receptor('alpl')
    ligand('native_reference','ligand_teal',.21)
    ligand('redocked','reference_orange',.17)
    cmd.select('native_neighborhood','byres ((alpl and polymer.protein) within 4 of (native_reference or redocked))')
    cmd.hide('cartoon','alpl')
    cmd.show('cartoon','byres ((alpl and polymer.protein) within 10 of (native_reference or redocked))')
    cmd.set('cartoon_transparency',.85,'alpl')
    cmd.orient('native_reference or redocked')
    cmd.turn('x',15)
    cmd.turn('y',25)
    cmd.zoom('native_reference or redocked',buffer=4.0)
    save('S4A_ALPL_AB_dry',2200,1800)
    for name,record in before.items():
        coords_unchanged(name,record)

version={'pymol':list(cmd.get_version()),'renderer':'PyMOL native ray tracer','seed':20260920,'rank':1,
         'coordinate_transforms':'None. Only camera orient/turn/zoom.',
         'structural_claim':'Preparation-dependent illustrative poses, not binding/inhibition evidence.'}
(OUT/'runtime_version.json').write_text(json.dumps(version,indent=2))
fig4()
s4_plau()
s4_alpl()
(OUT/'render_coordinate_QA.json').write_text(json.dumps(QA,indent=2))
(OUT/'camera_views.json').write_text(json.dumps(VIEWS,indent=2))
manifest=[{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.iterdir()) if p.suffix in {'.png','.pse'}]
(OUT/'render_sha256.json').write_text(json.dumps(manifest,indent=2))
print('PYMOL_RENDER_COMPLETE',len(manifest),'image/session files',flush=True)
cmd.quit()
