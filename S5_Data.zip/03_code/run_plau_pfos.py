"""Bounded follow-up on the passed PLAU primary preparation only."""
from __future__ import annotations
import hashlib,json,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(r'H:\NT\xinnei\MI\PFOS\tougao\revise\tmp\12_docking_rescue')
sys.path.insert(0,str(SOURCE/'00_protocol/software/python_packages'))
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
from meeko import MoleculePreparation,PDBQTWriterLegacy

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.now(timezone.utc).isoformat()
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')

def main():
    summary=json.loads((ROOT/'results/validation_summary.json').read_text())
    assert next(v for v in summary['summary'] if v['variant']=='PLAU_zwitterion_primary')['status']=='PASS'
    independent=json.loads((ROOT/'results/independent_rmsd_check.json').read_text())
    assert independent['status']=='PASS_IDENTITY_CROSSCHECK'
    assert all(r['identity_pass_le2A'] for r in independent['results'] if r['variant']=='PLAU_zwitterion_primary')
    if (ROOT/'stage_b_manifest.json').exists():raise RuntimeError('Stage B already exists; do not overwrite')
    m=json.loads((ROOT/'inputs_manifest.json').read_text())
    raw=SOURCE/'01_raw_inputs/ligands/PFOS_CID74483/PFOS.sdf'
    mol=next(m for m in Chem.SDMolSupplier(str(raw),removeHs=False) if m is not None)
    mol=Chem.RemoveHs(mol)
    candidates=[]
    for a in mol.GetAtoms():
        if a.GetAtomicNum()==16:
            for n in a.GetNeighbors():
                if n.GetAtomicNum()==8 and mol.GetBondBetweenAtoms(a.GetIdx(),n.GetIdx()).GetBondType()==Chem.BondType.SINGLE:
                    candidates.append(n.GetIdx())
    assert len(candidates)==1
    oxygen=mol.GetAtomWithIdx(candidates[0]);oxygen.SetFormalCharge(-1);oxygen.SetNumExplicitHs(0);oxygen.SetNoImplicit(True)
    Chem.SanitizeMol(mol)
    assert Chem.GetFormalCharge(mol)==-1 and mol.GetNumHeavyAtoms()==29
    assert sum(a.GetTotalNumHs() for a in mol.GetAtoms())==0
    assert rdMolDescriptors.CalcMolFormula(mol)=='C8F17O3S-'
    folder=ROOT/'prepared/ligands/PFOS_anion';folder.mkdir(parents=True,exist_ok=True)
    w=Chem.SDWriter(str(folder/'prepared.sdf'));w.write(mol);w.close()
    setups=MoleculePreparation().prepare(mol);assert len(setups)==1
    text,ok,error=PDBQTWriterLegacy.write_string(setups[0]);assert ok,error
    (folder/'prepared.pdbqt').write_text(text,encoding='ascii')
    charges=sum(float(l[70:76]) for l in text.splitlines() if l.startswith(('ATOM  ','HETATM')))
    assert abs(charges+1)<0.02
    qa={'source':str(raw),'source_sha256':sha(raw),'formula':rdMolDescriptors.CalcMolFormula(mol),
        'formal_charge':-1,'hydrogen_count':0,'heavy_atoms':29,'PDBQT_charge_sum':charges,
        'smiles':Chem.MolToSmiles(mol)}
    dump(folder/'chemistry_qa.json',qa)
    jobs=[]
    receptor=ROOT/'prepared/receptors/PLAU_A/receptor.pdbqt'
    for condition,center,size in [('pocket',[56.467,-5.942,108.695],[22,22.381,22]),
                                  ('surface_reference',[79.393,-20.244,133.719],[22,22,22])]:
        for seed in m['seeds']:
            jobs.append({'id':f'PFOS_PLAU_{condition}_seed{seed}','analysis':'PFOS','condition':condition,'seed':seed,
                         'receptor':str(receptor),'ligand':str(folder/'prepared.pdbqt'),'center':center,'size':size})
    jobs.append({'id':'PLAU_native_replay_seed20260921','analysis':'native_deterministic_replay','condition':'pocket','seed':20260921,
                 'receptor':str(receptor),'ligand':str(ROOT/'prepared/ligands/PLAU_AMH_zwitterion/prepared.pdbqt'),
                 'center':[56.467,-5.942,108.695],'size':[22,22.381,22]})
    record={'created_utc':now(),'protocol_sha256':sha(ROOT/'STAGE_B_PLAU_PROTOCOL.md'),'runner_sha256':sha(__file__),
            'PFOS_input_qa':qa,'jobs':jobs}
    for j in jobs:
        out=ROOT/'stage_b_outputs'/f"{j['id']}.pdbqt";out.parent.mkdir(exist_ok=True)
        config=ROOT/'configs/stage_b'/f"{j['id']}.txt";config.parent.mkdir(exist_ok=True)
        log=ROOT/'logs/stage_b'/f"{j['id']}.log";log.parent.mkdir(exist_ok=True)
        settings={'receptor':j['receptor'],'ligand':j['ligand'],
                  **{f'center_{a}':v for a,v in zip('xyz',j['center'])},
                  **{f'size_{a}':v for a,v in zip('xyz',j['size'])},
                  'exhaustiveness':32,'num_modes':20,'energy_range':5,'seed':j['seed'],'cpu':4,'out':str(out),'verbosity':1}
        config.write_text('\n'.join(f'{k} = {v}' for k,v in settings.items())+'\n')
        j.update(status='RUNNING',started_utc=now(),output=str(out),config=str(config),log=str(log),
                 input_sha256={str(p):sha(p) for p in [Path(j['receptor']),Path(j['ligand']),config]})
        dump(ROOT/'stage_b_manifest.json',record);print('START',j['id'],flush=True)
        cmd=[m['vina'],'--config',str(config)];started=time.monotonic()
        with log.open('w') as f:
            f.write('COMMAND\n'+subprocess.list2cmdline(cmd)+'\n');f.flush()
            run=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=1800,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        valid=out.exists() and 'REMARK VINA RESULT:' in out.read_text()
        j.update(status='COMPLETED' if run.returncode==0 and valid else 'FAILED',exit_code=run.returncode,
                 elapsed_seconds=round(time.monotonic()-started,3),ended_utc=now())
        if out.exists():j['output_sha256']=sha(out)
        dump(ROOT/'stage_b_manifest.json',record)
        print(j['status'],j['id'],j['elapsed_seconds'],flush=True)
        if j['status']=='FAILED':raise RuntimeError(f"Failed {j['id']}; no retry")
    record.update(status='COMPLETED',ended_utc=now());dump(ROOT/'stage_b_manifest.json',record)

if __name__=='__main__':main()
