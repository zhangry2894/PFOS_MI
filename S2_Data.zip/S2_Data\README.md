# S2 Data: public analysis reproducibility bundle

This GitHub-safe archive contains analysis code, processed probe/sample metadata,
fitted model objects, QA reports, software-session records and a complete source
manifest. It deliberately excludes raw third-party database exports.

The script `base_pipeline/code/08_make_simple_GO_KEGG_38genes.R` reproduces the
classical GO/KEGG over-representation results, S2 Figure and Table 5 from the
38-gene manifest retained in S1 Data. Run it as:

`Rscript 08_make_simple_GO_KEGG_38genes.R PFOS_MI_38_gene_manifest.csv output_directory`

The script uses `clusterProfiler::enrichGO` with `org.Hs.eg.db` for GO and the
MSigDB 2026.1.Hs C2 CP:KEGG_LEGACY collection for classical KEGG. The exact
KEGG term-to-gene and term-to-name snapshots, corresponding R session record,
and figure QA notes are retained so the reported analysis does not depend on a
future database update.

The standardized PFOS and MI gene-evidence tables and all analysis result tables
are in S1 Data. The normalized expression matrices are in S3 and S4 Data. Docking
inputs and outputs are in S5 Data.

Machine-specific paths in scripts and logs were replaced with relative or generic
paths. Use the documented environment variables or command-line arguments when
rerunning scripts. Exact ingestion from the third-party providers requires the
user to retrieve new exports under the providers' current terms.
