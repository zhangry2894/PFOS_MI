#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(AnnotationDbi)
  library(ggplot2)
  library(patchwork)
  library(ragg)
  library(svglite)
  library(msigdbr)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) {
  stop("Usage: Rscript 01_simple_go_kegg_38genes.R <enrichment_manifest.csv> <output_dir>")
}

manifest_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
output_dir <- normalizePath(args[[2]], winslash = "/", mustWork = FALSE)
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

manifest <- read.csv(manifest_path, check.names = FALSE, stringsAsFactors = FALSE)
target_row <- manifest[manifest$definition == "PFOS_consensus2_disease_original", , drop = FALSE]
if (nrow(target_row) != 1L) stop("Expected exactly one PFOS_consensus2_disease_original row")

symbols <- sort(unique(strsplit(target_row$gene_symbols[[1]], ";", fixed = TRUE)[[1]]))
if (length(symbols) != 38L) stop(sprintf("Expected 38 symbols, found %d", length(symbols)))

mapping <- suppressMessages(
  AnnotationDbi::select(
    org.Hs.eg.db,
    keys = symbols,
    keytype = "SYMBOL",
    columns = c("SYMBOL", "ENTREZID")
  )
)
mapping <- unique(mapping[!is.na(mapping$ENTREZID), c("SYMBOL", "ENTREZID")])
mapping <- mapping[order(mapping$SYMBOL, mapping$ENTREZID), ]
if (length(unique(mapping$SYMBOL)) != 38L) {
  missing_symbols <- setdiff(symbols, unique(mapping$SYMBOL))
  stop(sprintf("Not all symbols mapped to Entrez: %s", paste(missing_symbols, collapse = ", ")))
}
entrez <- sort(unique(as.character(mapping$ENTREZID)))

write.csv(
  data.frame(
    gene_symbol = symbols,
    in_38_gene_set = TRUE,
    stringsAsFactors = FALSE
  ),
  file.path(output_dir, "PFOS_MI_38_gene_symbols.csv"),
  row.names = FALSE,
  quote = TRUE
)
write.csv(mapping, file.path(output_dir, "PFOS_MI_38_gene_symbol_entrez_mapping.csv"), row.names = FALSE)

go_universe <- AnnotationDbi::keys(org.Hs.eg.db, keytype = "ENTREZID")

target_row$n_symbols <- length(symbols)
target_row$n_entrez <- length(entrez)
target_row$universe_entrez_n <- length(go_universe)
write.csv(
  target_row,
  file.path(output_dir, "PFOS_MI_38_gene_manifest.csv"),
  row.names = FALSE,
  quote = TRUE
)

run_go <- function(ontology) {
  result <- suppressMessages(
    enrichGO(
      gene = entrez,
      universe = go_universe,
      OrgDb = org.Hs.eg.db,
      keyType = "ENTREZID",
      ont = ontology,
      pAdjustMethod = "BH",
      pvalueCutoff = 1,
      qvalueCutoff = 1,
      minGSSize = 10,
      maxGSSize = 500,
      readable = TRUE
    )
  )
  out <- as.data.frame(result)
  if (nrow(out) == 0L) return(out)
  out$Ontology <- ontology
  out$BH_FDR <- out$p.adjust
  out$Significant_BH_FDR_0.05 <- out$p.adjust < 0.05
  out <- out[order(out$p.adjust, out$pvalue, -out$Count, out$ID), ]
  out
}

go_bp <- run_go("BP")
go_mf <- run_go("MF")
go_cc <- run_go("CC")
go_all <- rbind(go_bp, go_mf, go_cc)

kegg_msig <- msigdbr(
  species = "Homo sapiens",
  collection = "C2",
  subcollection = "CP:KEGG_LEGACY"
)
kegg_term2gene <- unique(data.frame(
  term = kegg_msig$gs_name,
  gene = as.character(kegg_msig$ncbi_gene),
  stringsAsFactors = FALSE
))
kegg_names <- gsub("_", " ", sub("^KEGG_", "", kegg_msig$gs_name))
kegg_names <- paste0(toupper(substr(kegg_names, 1, 1)), tolower(substr(kegg_names, 2, nchar(kegg_names))))
kegg_term2name <- unique(data.frame(
  term = kegg_msig$gs_name,
  name = kegg_names,
  stringsAsFactors = FALSE
))
kegg_universe <- sort(unique(kegg_term2gene$gene))

write.csv(kegg_term2gene, file.path(output_dir, "KEGG_LEGACY_term2gene_snapshot.csv"), row.names = FALSE)
write.csv(kegg_term2name, file.path(output_dir, "KEGG_LEGACY_term2name_snapshot.csv"), row.names = FALSE)

kegg_result <- suppressMessages(
  enricher(
    gene = entrez,
    universe = kegg_universe,
    TERM2GENE = kegg_term2gene,
    TERM2NAME = kegg_term2name,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    minGSSize = 10,
    maxGSSize = 500
  )
)
kegg_result <- suppressMessages(setReadable(kegg_result, OrgDb = org.Hs.eg.db, keyType = "ENTREZID"))
kegg <- as.data.frame(kegg_result)
if (nrow(kegg) > 0L) {
  kegg$Ontology <- "KEGG"
  kegg$BH_FDR <- kegg$p.adjust
  kegg$Significant_BH_FDR_0.05 <- kegg$p.adjust < 0.05
  kegg <- kegg[order(kegg$p.adjust, kegg$pvalue, -kegg$Count, kegg$ID), ]
}

write.csv(go_bp, file.path(output_dir, "GO_BP_all_results.csv"), row.names = FALSE)
write.csv(go_mf, file.path(output_dir, "GO_MF_all_results.csv"), row.names = FALSE)
write.csv(go_cc, file.path(output_dir, "GO_CC_all_results.csv"), row.names = FALSE)
write.csv(go_all, file.path(output_dir, "GO_all_results.csv"), row.names = FALSE)
write.csv(kegg, file.path(output_dir, "KEGG_all_results.csv"), row.names = FALSE)

parse_ratio <- function(x) {
  vapply(strsplit(as.character(x), "/", fixed = TRUE), function(z) as.numeric(z[[1]]) / as.numeric(z[[2]]), numeric(1))
}

select_for_plot <- function(df, n) {
  if (nrow(df) == 0L) return(df)
  sig <- df[df$p.adjust < 0.05, , drop = FALSE]
  if (nrow(sig) == 0L) return(sig)
  head(sig[order(sig$p.adjust, sig$pvalue, -sig$Count, sig$ID), ], n)
}

go_display <- rbind(
  select_for_plot(go_bp, 8L),
  select_for_plot(go_mf, 6L),
  select_for_plot(go_cc, 6L)
)
kegg_display <- select_for_plot(kegg, 10L)

prepare_plot_data <- function(df) {
  if (nrow(df) == 0L) return(df)
  df$GeneRatio_numeric <- parse_ratio(df$GeneRatio)
  df$Minus_log10_BH_FDR <- -log10(pmax(df$p.adjust, .Machine$double.xmin))
  df$Description_wrapped <- vapply(
    df$Description,
    function(x) paste(strwrap(x, width = 34), collapse = "\n"),
    character(1)
  )
  df
}

go_display <- prepare_plot_data(go_display)
kegg_display <- prepare_plot_data(kegg_display)

all_display <- rbind(
  go_display[, intersect(names(go_display), c("Count", "Minus_log10_BH_FDR")), drop = FALSE],
  kegg_display[, intersect(names(kegg_display), c("Count", "Minus_log10_BH_FDR")), drop = FALSE]
)
global_count_range <- range(all_display$Count, na.rm = TRUE)
global_fdr_range <- range(all_display$Minus_log10_BH_FDR, na.rm = TRUE)
global_count_breaks <- pretty(global_count_range, n = 4)
global_count_breaks <- global_count_breaks[global_count_breaks >= global_count_range[[1]] & global_count_breaks <= global_count_range[[2]]]
global_fdr_breaks <- pretty(global_fdr_range, n = 4)
global_fdr_breaks <- global_fdr_breaks[global_fdr_breaks >= global_fdr_range[[1]] & global_fdr_breaks <= global_fdr_range[[2]]]

write.csv(go_display, file.path(output_dir, "S2_Figure_source_GO.csv"), row.names = FALSE)
write.csv(kegg_display, file.path(output_dir, "S2_Figure_source_KEGG.csv"), row.names = FALSE)

table5_go <- data.frame(
  Database = "GO",
  Ontology = go_display$Ontology,
  Term_ID = go_display$ID,
  Description = go_display$Description,
  GeneRatio = go_display$GeneRatio,
  BgRatio = go_display$BgRatio,
  Count = go_display$Count,
  P_value = go_display$pvalue,
  BH_FDR = go_display$p.adjust,
  qvalue = go_display$qvalue,
  Contributing_genes = go_display$geneID,
  stringsAsFactors = FALSE
)
table5_kegg <- data.frame(
  Database = "KEGG_LEGACY",
  Ontology = "KEGG",
  Term_ID = kegg_display$ID,
  Description = kegg_display$Description,
  GeneRatio = kegg_display$GeneRatio,
  BgRatio = kegg_display$BgRatio,
  Count = kegg_display$Count,
  P_value = kegg_display$pvalue,
  BH_FDR = kegg_display$p.adjust,
  qvalue = kegg_display$qvalue,
  Contributing_genes = kegg_display$geneID,
  stringsAsFactors = FALSE
)
table5 <- rbind(table5_go, table5_kegg)
write.csv(table5, file.path(output_dir, "Table5_Enrichment.csv"), row.names = FALSE)

make_panel <- function(df, title, empty_label = "No pathway met BH-FDR < 0.05") {
  if (nrow(df) == 0L) {
    return(
      ggplot() +
        annotate("text", x = 0.5, y = 0.5, label = empty_label, size = 3.1, colour = "#555555") +
        xlim(0, 1) + ylim(0, 1) +
        labs(title = title) +
        theme_void(base_family = "Arial") +
        theme(plot.title = element_text(size = 10, face = "bold", hjust = 0))
    )
  }
  df <- df[order(df$p.adjust, decreasing = TRUE), ]
  df$Description_wrapped <- factor(df$Description_wrapped, levels = unique(df$Description_wrapped))
  ggplot(df, aes(x = GeneRatio_numeric, y = Description_wrapped)) +
    geom_segment(aes(x = 0, xend = GeneRatio_numeric, yend = Description_wrapped),
                 linewidth = 0.35, colour = "#D9D9D9") +
    geom_point(aes(size = Count, colour = Minus_log10_BH_FDR), alpha = 0.95) +
    scale_x_continuous(labels = scales::percent_format(accuracy = 1), expand = expansion(mult = c(0.02, 0.20))) +
    scale_colour_gradient(
      low = "#BFD7EA", high = "#2166AC",
      name = expression(-log[10]("BH-FDR")),
      limits = global_fdr_range,
      breaks = global_fdr_breaks
    ) +
    scale_size_continuous(
      range = c(2.3, 6.6), name = "Gene count",
      limits = global_count_range,
      breaks = global_count_breaks
    ) +
    labs(title = title, x = "Gene ratio", y = NULL) +
    theme_classic(base_size = 8.5, base_family = "Arial") +
    theme(
      plot.title = element_text(size = 10, face = "bold", hjust = 0),
      axis.title.x = element_text(size = 8.5),
      axis.text.x = element_text(size = 7.7, colour = "black"),
      axis.text.y = element_text(size = 7.7, colour = "black", lineheight = 0.92),
      axis.line = element_line(linewidth = 0.35),
      axis.ticks = element_line(linewidth = 0.35),
      legend.title = element_text(size = 7.2),
      legend.text = element_text(size = 6.8),
      legend.key.height = grid::unit(3.5, "mm"),
      plot.margin = margin(5, 8, 5, 5)
    )
}

p_bp <- make_panel(go_display[go_display$Ontology == "BP", , drop = FALSE], "GO biological process")
p_mf <- make_panel(go_display[go_display$Ontology == "MF", , drop = FALSE], "GO molecular function")
p_cc <- make_panel(go_display[go_display$Ontology == "CC", , drop = FALSE], "GO cellular component")
p_kegg <- make_panel(kegg_display, "KEGG pathway")

figure <- ((p_bp | p_mf) / (p_cc | p_kegg)) +
  plot_layout(guides = "collect") +
  plot_annotation(tag_levels = "A") &
  theme(
    plot.tag = element_text(size = 12, face = "bold", family = "Arial"),
    legend.position = "bottom",
    legend.box = "horizontal"
  )

stem <- file.path(output_dir, "S2_Fig_GO_KEGG_38genes")
width_in <- 7.2
height_in <- 6.7

ragg::agg_tiff(paste0(stem, ".tif"), width = width_in, height = height_in,
               units = "in", res = 600, compression = "lzw")
print(figure)
dev.off()

ragg::agg_png(paste0(stem, ".png"), width = width_in, height = height_in,
              units = "in", res = 300)
print(figure)
dev.off()

ragg::agg_jpeg(paste0(stem, ".jpg"), width = width_in, height = height_in,
               units = "in", res = 600, quality = 95)
print(figure)
dev.off()

svglite::svglite(paste0(stem, ".svg"), width = width_in, height = height_in)
print(figure)
dev.off()

grDevices::cairo_pdf(paste0(stem, ".pdf"), width = width_in, height = height_in,
                     family = "Arial")
print(figure)
dev.off()

msigdb_release <- unique(kegg_msig[, c("db_version", "gs_collection", "gs_subcollection", "gs_collection_name")])
write.csv(msigdb_release, file.path(output_dir, "MSigDB_KEGG_LEGACY_release_info.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(output_dir, "R_sessionInfo.txt"), useBytes = TRUE)

summary_table <- data.frame(
  analysis = c("Input PFOS-MI genes", "Mapped Entrez IDs", "GO BP significant", "GO MF significant", "GO CC significant", "KEGG significant"),
  count = c(
    length(symbols),
    length(entrez),
    sum(go_bp$p.adjust < 0.05, na.rm = TRUE),
    sum(go_mf$p.adjust < 0.05, na.rm = TRUE),
    sum(go_cc$p.adjust < 0.05, na.rm = TRUE),
    sum(kegg$p.adjust < 0.05, na.rm = TRUE)
  ),
  stringsAsFactors = FALSE
)
write.csv(summary_table, file.path(output_dir, "enrichment_summary_counts.csv"), row.names = FALSE)

qa <- c(
  "Analysis: classical over-representation analysis of the single 38-gene PFOS-MI consensus set",
  sprintf("Input symbols: %d", length(symbols)),
  sprintf("Unique Entrez IDs: %d", length(entrez)),
  sprintf("GO BP/MF/CC significant at BH-FDR < 0.05: %d/%d/%d",
          sum(go_bp$p.adjust < 0.05, na.rm = TRUE),
          sum(go_mf$p.adjust < 0.05, na.rm = TRUE),
          sum(go_cc$p.adjust < 0.05, na.rm = TRUE)),
  sprintf("KEGG pathways significant at BH-FDR < 0.05: %d", sum(kegg$p.adjust < 0.05, na.rm = TRUE)),
  "GO method: clusterProfiler::enrichGO, one-sided hypergeometric test, BH correction, org.Hs.eg.db universe",
  sprintf("KEGG source: MSigDB %s C2 CP:KEGG_LEGACY (%d pathways)", unique(kegg_msig$db_version), length(unique(kegg_msig$gs_name))),
  "KEGG method: clusterProfiler::enricher using the retained KEGG_LEGACY term-to-gene snapshot, one-sided hypergeometric test, BH correction",
  "Display: top significant terms ranked by BH-FDR; no semantic-similarity or Jaccard redundancy filter",
  "Interpretive boundary: enrichment is descriptive and does not establish direction, causality, or direct PFOS binding"
)
writeLines(qa, file.path(output_dir, "S2_Figure_QA_notes.txt"), useBytes = TRUE)

cat(paste(qa, collapse = "\n"), "\n")
