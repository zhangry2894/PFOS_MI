S2 Data: essential inputs, final prediction models, and reproducibility code
Edition 20, 29 October 2026

READ THIS FIRST
01_inputs contains exact processed analysis inputs and public-source metadata.
02_final_models contains only the current selected ALPL-PLAU model, the selected
strict-disease sensitivity model, and fixed alternative-method coefficients.
03_code contains scientific code, exact settings/seeds, original protocols and
recorded software environments. S1 Data contains final numerical results.

These are not raw CEL microarray files. S3 and S4 separately contain the deposited
processed GSE66360 and GSE48060 gene matrices. The processed GSE61144 and GSE59867
matrices are here. GEO accessions and original retrieval records identify public
upstream data; the original study was not reprocessed from CEL during this task.
The small RDS input objects retain the exact discovery/selection data or the
probe-level matrix and fixed outer partitions required by the recorded workflow.
They are inputs, not hundreds of fitted intermediate models.

QUICK VERIFIED FROZEN-MODEL REPLAY
Install the recorded R packages (R 4.3.2, glmnet, pROC, jsonlite). No automatic
download or package installation is performed. Extract S2 into S2_ROOT, place
S3_Data.csv.gz and S4_Data.csv.gz in DATA_DIR, and choose a new output directory:
  Rscript --vanilla S2_ROOT/03_code/replay_fixed_panel.R S2_ROOT DATA_DIR NEW_OUTPUT
This verifies the selected model against its explicit formula and recomputes
four fixed-score AUCs. Expected values are 0.8839285714 (internal GSE66360),
0.7327188940 (GSE48060), 0.9285714286 (GSE61144), and 0.6602036819 (GSE59867).
This is numerical replay, not retraining or new external confirmation.

OPTIONAL FRESH PRIMARY SELECTION
Use a nonexistent output directory and the recorded caret/glmnet/Boruta/
randomForest/xgboost package environment:
  Rscript --vanilla S2_ROOT/03_code/refit_primary37.R S2_ROOT NEW_OUTPUT
The wrapper uses the same original fitting code, fixed 36 measured candidates,
discovery-only selectors, fixed ridge folds, 492 internal-only subsets and
one-SE-style heuristic. It does not load external matrices. Exact reproduction
of stochastic results requires the recorded software versions. A new full
training run was not performed as part of this packaging change.

FULL-WORKFLOW AND SENSITIVITY CODE
restore_analysis_layout.py materializes retained original input/code paths in a
new directory; it does not resurrect discarded intermediates or completion flags:
  python S2_ROOT/03_code/restore_analysis_layout.py --s2 S2_ROOT --out NEW_LAYOUT
For primary/historical outer refits, use analysis_workspace/09_additional_
experiments_20261018/01_full_pipeline_validation/run_outer_worker.R with the
same base directory, variant overlap37 or overlap38, and fold R1F1 through R3F5.
Use the recorded resource-continuation script only for its declared resource
limit. Complete fits must finish before aggregate code is run. All fixed
partitions, inner ridge assignments, source functions, parameters and seeds
remain available. The selected current panel is not claimed stable in every fold.
Strict18, alternatives, enrichment, QC and figure code retain their original
scientific logic. Their original relative paths are documented by SOURCE_MAP;
S1 final source tables and S3/S4 must be supplied for the relevant workflow.
Legacy scripts expecting every saved intermediate model are not recommended
as no-refit replay commands in this edition. Cold-start full refits and all
figure rebuilds were not rerun during packaging; do not interpret integrity
checks as independent end-to-end reproduction.

LIMITED OFFLINE METADATA CHECK
  python S2_ROOT/03_code/verify_metadata_snapshots.py S2_ROOT NEW_OUTPUT.json
This inventories the three retained original GEO metadata snapshots without
network access. It is not the older 29-source audit: journal-article/supplement
copies and duplicate snapshot formats have been omitted. Final cohort eligibility,
sample crosswalks, unavailable-covariate findings and source references remain in
S1. covariate_source_audit.py is the original source/provenance script; it is not
a self-contained offline entry point and must not be presented as one.

WHAT WAS REMOVED
All 492/957 subset model collections, per-fold fitted models, duplicated results,
redundant preprocessing snapshots, old presentation branches, execution caches,
and verbose success/progress logs are omitted. Final subset metrics, held-out
predictions, stability, threshold sensitivities, negative findings and full FDR
tables remain in S1. Raw docking evidence is in S5. The author's complete
edition19 archive is preserved, not replaced. No unfavorable result was removed
because of its AUC, P value, selected genes or validation outcome.

SOURCE_MAP.csv identifies original members and transformations. Combined
parameters/protocols retain analysis identifiers; they do not hide model caches.
MANIFEST_SHA256.csv covers every current file except itself. Third-party sources
retain their original terms; no new licence, DOI, release or upload is claimed.
The historical notes inside code/protocols describe the dated execution, not the
current manuscript's primary definition or newly performed work.
