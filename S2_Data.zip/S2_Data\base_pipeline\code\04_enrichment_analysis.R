options(stringsAsFactors = FALSE, width = 180)

work <- Sys.getenv("PFOS_MI_WORK_ROOT", unset = "./rerun_output")
results_dir <- file.path(work, "04_results")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)

target <- read.csv(file.path(results_dir, "PFOS_target_evidence_and_tiers.csv"), check.names = FALSE)
disease <- read.csv(file.path(results_dir, "MI_gene_evidence_and_tiers.csv"), check.names = FALSE)

genes_38 <- sort(intersect(
  target$gene[target$tier_consensus_2plus],
  disease$gene[disease$tier_original_2841]
))
if (length(genes_38) != 38L) {
  stop(sprintf("Expected 38 two-source PFOS–MI genes, found %d", length(genes_38)))
}

manifest <- data.frame(
  definition = "PFOS_consensus2_disease_original",
  n_symbols = length(genes_38),
  n_entrez = NA_integer_,
  gene_symbols = paste(genes_38, collapse = ";"),
  universe_entrez_n = NA_integer_,
  stringsAsFactors = FALSE
)
manifest_path <- file.path(results_dir, "PFOS_MI_38_gene_manifest.csv")
write.csv(manifest, manifest_path, row.names = FALSE, quote = TRUE)

script_dir <- if (exists("code_dir", inherits = TRUE)) {
  get("code_dir", inherits = TRUE)
} else {
  normalizePath(getwd(), winslash = "/", mustWork = TRUE)
}
analysis_script <- file.path(script_dir, "08_make_simple_GO_KEGG_38genes.R")
if (!file.exists(analysis_script)) stop("Missing enrichment script: ", analysis_script)

rscript_bin <- file.path(R.home("bin"), "Rscript")
status <- system2(
  rscript_bin,
  args = c(shQuote(analysis_script), shQuote(manifest_path), shQuote(results_dir))
)
if (!identical(status, 0L)) stop("The 38-gene GO/KEGG analysis failed with status ", status)

cat("Completed classical GO/KEGG over-representation analysis for 38 PFOS–MI genes.\n")
