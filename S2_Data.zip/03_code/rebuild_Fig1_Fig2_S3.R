# R-only plotting from copied numerical outputs. No training or enrichment is run.
# PLOS ONE: Arial >=8pt, width190mm, TIFF600dpi; JPG preview, editablePDF/SVG.
options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages({library(ggplot2);library(patchwork)})
sf<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
args<-commandArgs(trailingOnly=TRUE)
out<-normalizePath(if(length(args))args[1] else dirname(sf),winslash='/')
src<-file.path(out,'source_data'); derived<-file.path(out,'display_source_data')
dir.create(derived,showWarnings=FALSE)
read<-function(n) read.csv(file.path(src,paste0(n,'.csv')),check.names=FALSE)
write<-function(d,n) write.csv(d,file.path(derived,paste0(n,'.csv')),row.names=FALSE)
pt<-72.27/25.4
pal<-c(blue='#246B91',teal='#2E7D72',orange='#B76828',gray='#858E98',light='#EAEFF2',dark='#252A30')
theme_pub<-function() theme_classic(base_size=9,base_family='Arial')+theme(
  axis.title=element_text(size=8.5),axis.text=element_text(size=8,color=pal['dark']),
  legend.title=element_text(size=8),legend.text=element_text(size=8),
  strip.text=element_text(size=8.5,face='bold'),strip.background=element_blank(),
  axis.line=element_line(linewidth=.3),axis.ticks=element_line(linewidth=.3),
  plot.title=element_text(size=10,face='bold',margin=margin(b=4)),
  plot.subtitle=element_text(size=8,margin=margin(b=6)),
  plot.caption=element_text(size=8,hjust=0),
  plot.margin=margin(5,5,5,5),legend.key.height=grid::unit(4,'mm'),
  legend.key.width=grid::unit(6,'mm'),legend.spacing.y=grid::unit(.5,'mm'),
  panel.grid=element_blank())
theme_set(theme_pub())
save_pub<-function(p,stem,h,width_mm=190){
  w<-width_mm/25.4; hh<-h/25.4
  svglite::svglite(file.path(out,paste0(stem,'.svg')),width=w,height=hh,bg='white');print(p);dev.off()
  grDevices::cairo_pdf(file.path(out,paste0(stem,'.pdf')),width=w,height=hh,family='Arial',bg='white');print(p);dev.off()
  ragg::agg_tiff(file.path(out,paste0(stem,'.tif')),width=w,height=hh,units='in',res=600,compression='lzw',background='white');print(p);dev.off()
  ragg::agg_jpeg(file.path(out,paste0(stem,'.jpg')),width=w,height=hh,units='in',res=600,quality=95,background='white');print(p);dev.off()
  ragg::agg_png(file.path(out,paste0(stem,'_preview.png')),width=w,height=hh,units='in',res=300,background='white');print(p);dev.off()
  bmp<-pdftools::pdf_render_page(file.path(out,paste0(stem,'.pdf')),page=1,dpi=300)
  png::writePNG(bmp,file.path(out,paste0(stem,'_PDF_preview.png')))
}
wrap<-function(x,width) vapply(x,function(y)paste(strwrap(y,width=width),collapse='\n'),character(1))
fmtp<-function(x) ifelse(x<.001,formatC(x,format='e',digits=1),formatC(x,format='f',digits=3))
mem<-read('membership'); metrics<-read('subset_metrics'); lock<-read('selection_lock')
ext<-read('external_performance'); expr<-read('external_expression')
stopifnot(nrow(mem)==36,identical(as.integer(colSums(mem[,2:5])),c(4L,10L,7L,22L)),sum(mem$n_algorithms>=2)==9,nrow(metrics)==492)
stopifnot(all(lock$genes=='ALPL;PLAU'),abs(lock$internal_AUC[1]-.883928571428571)<1e-12,nrow(ext)==9,all(ext$status=='scored'))
qa<-data.frame(check=c('36 measured candidates','Selector memberships4/10/7/22','9 vote-pool genes','492 internal subsets','ALPL-PLAU lock','9 external model-cohort rows'),pass=TRUE)

# Fig1: a single, explicitly non-area-scaled Venn. Counts are not measurements of area.
venn_counts<-data.frame(region=c('PFOS only','Shared PFOS-MI','MI only'),count=c(36L,37L,2804L))
stopifnot(sum(venn_counts$count[1:2])==73L,sum(venn_counts$count[2:3])==2841L)
angles<-seq(0,2*pi,length.out=721)
circles<-rbind(data.frame(x=-.83+1.45*cos(angles),y=1.45*sin(angles),set='PFOS'),
               data.frame(x=.83+1.45*cos(angles),y=1.45*sin(angles),set='MI'))
fig1<-ggplot(circles,aes(x,y,group=set))+
 geom_polygon(aes(fill=set),alpha=.22,color=NA)+
 geom_path(aes(color=set),linewidth=.65)+
 annotate('text',x=c(-1.18,1.18),y=1.82,label=c('PFOS targets (73)','MI-associated genes (2,841)'),family='Arial',fontface='bold',size=10/pt)+
 annotate('text',x=-1.18,y=1.58,label='At least two positive sources',family='Arial',size=8.5/pt)+
 annotate('text',x=1.18,y=1.58,label='GeneCards and OMIM',family='Arial',size=8.5/pt)+
 annotate('text',x=c(-1.35,0,1.35),y=.14,label=c('36','37','2,804'),family='Arial',fontface='bold',size=12/pt,color=pal['dark'])+
 annotate('text',x=c(-1.35,0,1.35),y=-.27,label=c('PFOS only','Shared','MI only'),family='Arial',size=9/pt,color=pal['dark'])+
 annotate('text',x=0,y=-1.78,label='37 shared genes: 36 measurable; CES1 unavailable',family='Arial',size=9/pt,color=pal['dark'])+
 annotate('text',x=0,y=-2.08,label='Set areas are not proportional to gene counts.',family='Arial',size=8/pt,color='#59636C')+
 scale_fill_manual(values=c(PFOS=unname(pal['teal']),MI=unname(pal['blue'])),guide='none')+
 scale_color_manual(values=c(PFOS=unname(pal['teal']),MI=unname(pal['blue'])),guide='none')+
 coord_fixed(xlim=c(-2.65,2.65),ylim=c(-2.19,2.01),expand=FALSE)+theme_void(base_family='Arial')+
 theme(plot.margin=margin(7,7,7,7))
save_pub(fig1,'Fig1',115,width_mm=160);write(venn_counts,'Fig1_Venn_region_counts')

# Fig2: all candidates and all subsets are represented; only graphical offsets are used.
algs<-c('LASSO','SVM-RFE','Boruta','XGBoost')
mlong<-do.call(rbind,lapply(algs,function(a)data.frame(gene=mem$gene,algorithm=a,selected=mem[[a]],votes=mem$n_algorithms)))
mlong$gene<-factor(mlong$gene,levels=rev(mem$gene));mlong$algorithm<-factor(mlong$algorithm,levels=algs)
gene_labels<-setNames(paste0(mem$gene,ifelse(mem$n_algorithms>=2,' *','')),mem$gene)
p2a<-ggplot(mlong,aes(algorithm,gene,fill=factor(selected)))+geom_tile(color='white',linewidth=.45)+
 geom_text(aes(label=ifelse(selected==1,'+','')),size=8.5/pt,color='white',family='Arial')+
 scale_fill_manual(values=c('0'=unname(pal['light']),'1'=unname(pal['teal'])),guide='none')+
 scale_y_discrete(labels=gene_labels,expand=expansion(add=.25))+
 scale_x_discrete(labels=c('LASSO\n4','ROC-ranked\nSVM\n10','Boruta\n7','XGBoost\n22'),position='top')+
 labs(x=NULL,y=NULL,title='A  Discovery selection',subtitle='36 measured candidates\n* At least two votes: 9 genes')+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(size=8),plot.margin=margin(5,8,5,5))
metrics$display_x<-metrics$n_genes+ave(seq_len(nrow(metrics)),metrics$n_genes,FUN=function(z)seq(-.22,.22,length.out=length(z)))
chosen<-metrics[metrics$genes=='ALPL;PLAU',];stopifnot(nrow(chosen)==1)
p2b<-ggplot(metrics,aes(x=n_genes,y=ROC_AUC_internal,group=factor(n_genes)))+
 geom_hline(yintercept=.5,linetype=2,color='#A5ADB4',linewidth=.3)+
 geom_boxplot(width=.56,fill='#EEF2F5',color='#657684',outlier.shape=NA,linewidth=.3)+
 geom_point(aes(x=display_x),size=.65,color='#657C8B',alpha=.65)+
 geom_point(data=chosen,aes(x=n_genes),shape=23,size=2.8,fill=pal['orange'],color=pal['orange'])+
 annotate('text',x=3.8,y=.965,label='ALPL-PLAU: AUC 0.884',size=8/pt,hjust=.5,family='Arial',color=pal['orange'])+
 scale_x_continuous(breaks=2:7)+scale_y_continuous(limits=c(.2,1.01),breaks=seq(.2,1,.2))+
 labs(x='Subset size (genes)',y='Internal AUC',title='B  Internal subset comparison',subtitle='All 492 subsets; n = 56; selection-optimistic')
mainext<-ext[ext$model=='Baseline_ALPL_PLAU',]
coh<-c('GSE48060','GSE61144','GSE59867')
cohort_labs<-c(GSE48060='GSE48060\n31 MI / 21 control',GSE61144='GSE61144\n7 STEMI / 10 normal',GSE59867='GSE59867\n111 MI / 46 stable CAD')
mainext$cohort<-factor(mainext$cohort,levels=rev(coh)); mainext$label<-sprintf('%.3f [%.3f, %.3f]',mainext$AUC,mainext$CI95_lower_DeLong,mainext$CI95_upper_DeLong)
p2c<-ggplot(mainext,aes(AUC,cohort))+geom_vline(xintercept=.5,linetype=2,color='#A5ADB4',linewidth=.3)+
 geom_errorbar(aes(xmin=CI95_lower_DeLong,xmax=CI95_upper_DeLong),orientation='y',width=.14,linewidth=.5,color=pal['blue'])+
 geom_point(size=2.2,color=pal['blue'])+geom_text(aes(x=1.015,label=label),hjust=0,family='Arial',size=8/pt)+
 scale_y_discrete(labels=cohort_labs)+scale_x_continuous(limits=c(.45,1.49),breaks=c(.5,.75,1))+
 labs(x='AUC (conditional 95% DeLong CI)',y=NULL,title='C  External ALPL-PLAU assessment',subtitle='Fixed coefficients and direction; no external fitting')
ep<-expr[expr$model=='Baseline_ALPL_PLAU',];stopifnot(nrow(ep)==6)
ep$cohort<-factor(ep$cohort,levels=coh);ep$gene<-factor(ep$gene,levels=c('PLAU','ALPL'))
ep$cell_label<-sprintf('logFC +%.3f\nq = %s',ep$logFC_MI_minus_control,fmtp(ep$BH_q_whole_transcriptome))
p2d<-ggplot(ep,aes(cohort,gene,fill=logFC_MI_minus_control))+geom_tile(color='white',linewidth=1)+
 geom_text(aes(label=cell_label),family='Arial',size=8.25/pt,lineheight=1.2)+
 scale_fill_gradient(low='#F4F7F9',high='#9EC7DD',guide='none',limits=c(0,max(ep$logFC_MI_minus_control)))+
 labs(x=NULL,y=NULL,title='D  External expression',subtitle='MI minus comparator; transcriptome-wide BH q')+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.x=element_text(size=8.5))
fig2<-p2a+p2b+p2c+p2d+plot_layout(design='AB\nAC\nAD',widths=c(.82,1.55),heights=c(1.12,1,.82))
save_pub(fig2,'Fig2',215)
write(mlong,'Fig2A_all36_selector_memberships');write(metrics,'Fig2B_all492_internal_results');write(mainext,'Fig2C_locked_external_AUC');write(ep,'Fig2D_external_expression')

# S2: classical over-representation, negative primary KEGG result preserved.
go_all<-list()
for(i in seq_along(c('BP','MF','CC'))){
 ont<-c('BP','MF','CC')[i];d<-read(paste0('positive_source_support_37_',ont));d<-d[order(d$p.adjust,d$pvalue,d$ID),];z<-head(d,5)
 stopifnot(all(z$p.adjust>0),all(z$p.adjust<.05));z$ontology<-ont
 z$ratio<-vapply(strsplit(z$GeneRatio,'/'),function(v)as.numeric(v[1])/as.numeric(v[2]),numeric(1));z$neglogq<--log10(z$p.adjust)
 z$label<-wrap(z$Description,31);go_all[[ont]]<-z
}
godat<-do.call(rbind,go_all)
godat$ontology<-factor(godat$ontology,levels=c('BP','MF','CC'),labels=c('Biological process','Molecular function','Cellular component'))
godat$label<-factor(godat$label,levels=rev(godat$label))
pGO<-ggplot(godat,aes(ratio,label,size=Count,color=neglogq))+geom_point()+
 facet_wrap(~ontology,ncol=1,scales='free_y')+
 scale_color_gradient(low='#A7D0DC',high='#15546E',limits=c(0,16),name='-log10(BH q)')+
 scale_size_area(max_size=4.2,breaks=c(3,7,13),limits=c(0,13),name='Gene count')+
 scale_x_continuous(limits=c(0,.4),breaks=c(0,.2,.4))+
 labs(x='GeneRatio',y=NULL,title='A  GO enrichment',subtitle='37 shared genes; five terms per ontology')+
 theme(legend.position='bottom',legend.box='vertical',axis.text.y=element_text(size=8),
       strip.background=element_rect(fill='#F0F4F6',color=NA),strip.text=element_text(hjust=0,size=8.5),
       panel.spacing.y=grid::unit(4,'mm'),plot.margin=margin(5,12,5,5))+
 guides(size=guide_legend(order=2,nrow=1),color=guide_colorbar(order=1,barwidth=grid::unit(30,'mm'),barheight=grid::unit(3,'mm')))
k37<-read('positive_source_support_37_KEGG');k38<-read('archived_source_occurrence_38_KEGG')
stopifnot(nrow(k37)==67,sum(k37$p.adjust<.05)==0,sum(k38$p.adjust<.05)==1)
ids<-head(k37$ID[order(k37$p.adjust,k37$pvalue,k37$ID)],5)
kt<-rbind(transform(k37[match(ids,k37$ID),],Definition='Primary37'),transform(k38[match(ids,k38$ID),],Definition='Archived38'))
kt$Description[kt$Description=='Ppar signaling pathway']<-'PPAR signaling pathway'
labs_k<-wrap(kt$Description[1:5],24);kt$termlabel<-factor(rep(labs_k,2),levels=rev(labs_k));kt$Definition<-factor(kt$Definition,levels=c('Primary37','Archived38'))
kt$display<-paste0('P ',fmtp(kt$pvalue),'\nq ',fmtp(kt$p.adjust))
pS2d<-ggplot(kt,aes(Definition,termlabel,fill=p.adjust<.05))+geom_tile(color='white',linewidth=1)+
 geom_text(aes(label=display),family='Arial',size=8/pt,lineheight=1.2)+
 scale_fill_manual(values=c('FALSE'='#EEF2F4','TRUE'='#E2C39F'),guide='none')+
 scale_x_discrete(labels=c(Primary37='Primary\n37 genes',Archived38='Sensitivity\n38 genes'))+
 labs(x=NULL,y=NULL,title='B  Classical KEGG',subtitle='No primary term passes BH q < 0.05\nTop five primary terms; raw P and BH q')+
 theme(axis.line=element_blank(),axis.ticks=element_blank(),axis.text.y=element_text(size=8),legend.position='none')
figS2<-pGO+pS2d+guide_area()+plot_layout(design='AB\nAC',widths=c(1.08,1),heights=c(2.2,1),guides='collect')
save_pub(figS2,'S2_Fig',205);write(godat,'S2_37gene_GO_top5_each');write(kt,'S2_KEGG_primary37_vs_archived38_top5')

# S3: stored 36-input tuning summaries, not a new fitting operation.
lc<-read('LASSO_cv');lp<-read('LASSO_parameters');sc<-read('SVM_cv');sp<-read('SVM_parameters')
stopifnot(nrow(lc)==20,all(lc$lambda>0),all(sc$Variables==c(5,10,20,36)),sp$n_features==10,sp$cost==1)
pS3a<-ggplot(lc,aes(lambda,ROC))+geom_errorbar(aes(ymin=ROC-ROCSD,ymax=ROC+ROCSD),width=0,linewidth=.4,color=pal['gray'])+
 geom_line(linewidth=.5,color=pal['blue'])+geom_point(size=1.5,color=pal['blue'])+geom_vline(xintercept=lp$lambda,linetype=2,linewidth=.4,color=pal['orange'])+
 scale_x_log10(breaks=c(.0001,.001,.01,.1,1),labels=c('0.0001','0.001','0.01','0.1','1'))+
 labs(x='Lambda (log scale)',y='CV ROC AUC: mean +/- SD',title='A  LASSO: 36 candidate inputs',subtitle='5 folds x 3 repeats; selected lambda = 0.143845')
pS3b<-ggplot(sc,aes(Variables,ROC))+geom_errorbar(aes(ymin=ROC-ROCSD,ymax=ROC+ROCSD),width=.7,linewidth=.4,color=pal['gray'])+
 geom_line(linewidth=.5,color=pal['blue'])+geom_point(size=1.8,color=pal['blue'])+geom_vline(xintercept=sp$n_features,linetype=2,linewidth=.4,color=pal['orange'])+
 scale_x_continuous(breaks=c(5,10,20,36))+
 labs(x='Candidate subset size',y='CV ROC AUC: mean +/- SD',title='B  ROC-ranked SVM filtering',subtitle='5-fold size curve; selected 10 genes, C = 1')
ylim<-range(c(lc$ROC-lc$ROCSD,lc$ROC+lc$ROCSD,sc$ROC-sc$ROCSD,sc$ROC+sc$ROCSD))
figS3<-(pS3a+coord_cartesian(ylim=ylim))|(pS3b+coord_cartesian(ylim=ylim));save_pub(figS3,'S3_Fig',100)
write(lc,'S3_LASSO_CV_mean_SD');write(sc,'S3_ROCranked_SVM_CV_mean_SD')

# S5: no inferential intervals for dependent repeat/frequency summaries.
rep<-read('repeat_OOF');rs<-read('repeat_summary');gf<-read('gene_frequency');pf<-read('panel_frequency')
r<-rep[rep$rule=='one_SE_style',];s<-rs[rs$rule=='one_SE_style',]
stopifnot(nrow(r)==12,nrow(s)==4,abs(s$AUC_mean[s$variant=='overlap37'&s$cohort=='Validation']-.738945578231292)<1e-12)
r$variant<-factor(r$variant,levels=c('overlap37','overlap38'),labels=c('37 genes','38 genes'));r$cohort<-factor(r$cohort,levels=c('Discovery','Validation'),labels=c('Discovery role (n = 43)','Selection role (n = 56)'))
s$variant<-factor(s$variant,levels=c('overlap37','overlap38'),labels=c('37 genes','38 genes'));s$cohort<-factor(s$cohort,levels=c('Discovery','Validation'),labels=c('Discovery role (n = 43)','Selection role (n = 56)'))
s$display<-sprintf('Mean\n%.3f\nRange\n%.3f to\n%.3f',s$AUC_mean,s$AUC_min,s$AUC_max)
pS5a<-ggplot(r,aes(variant,AUC,group=factor(repeat_id),color=factor(repeat_id)))+
 geom_line(linewidth=.5)+geom_point(size=1.8)+facet_wrap(~cohort,nrow=1)+
 geom_text(data=s,aes(x=variant,y=.55,label=display),inherit.aes=FALSE,size=8/pt,family='Arial',lineheight=1.1)+
 scale_color_manual(values=c('#246B91','#B76828','#777F87'),name='Repeat')+
 scale_y_continuous(limits=c(.48,1.01),breaks=c(.5,.6,.7,.8,.9,1))+
 labs(x='PFOS-MI overlap definition',y='Whole-repeat OOF AUC',title='A  Complete-workflow evaluation',subtitle='5 folds x 3 repeats; one-SE-style selection')+
 theme(legend.position='bottom')
g<-gf[gf$variant=='overlap37'&gf$rule=='one_SE_style',];g<-g[order(-g$selected_fits,g$gene),];gn<-g[g$selected_fits>0,]
gn$gene<-factor(gn$gene,levels=rev(gn$gene))
pS5b<-ggplot(gn,aes(selected_fits,gene))+geom_col(fill=pal['blue'],width=.62)+
 geom_text(aes(label=paste0(selected_fits,'/15')),hjust=-.15,size=8/pt,family='Arial')+
 scale_x_continuous(limits=c(0,17),breaks=c(0,5,10,15))+
 labs(x='Dependent outer fits selecting gene',y=NULL,title='B  Gene-selection variability',subtitle='Primary definition; all nonzero counts shown')
p<-pf[pf$variant=='overlap37'&pf$rule=='one_SE_style',];p<-p[order(-p$selected_fits,p$panel),]
stopifnot(sum(p$selected_fits)==15);p$panel<-factor(gsub(';',' + ',p$panel),levels=rev(gsub(';',' + ',p$panel)))
pS5c<-ggplot(p,aes(selected_fits,panel))+geom_col(fill=pal['teal'],width=.62)+
 geom_text(aes(label=paste0(selected_fits,'/15')),hjust=-.15,size=8/pt,family='Arial')+
 scale_x_continuous(limits=c(0,6.4),breaks=0:5)+
 labs(x='Dependent outer fits selecting panel',y=NULL,title='C  Panel-selection variability',subtitle='All selected panels; no binomial inference')
ee<-ext;ee$cohort<-factor(ee$cohort,levels=coh);ee$model<-factor(ee$model,levels=c('Baseline_ALPL_PLAU','ElasticNet','Classical_SVM_RFE_ridge'),labels=c('ALPL-PLAU (main)','ElasticNet (7 genes)','Classical SVM-RFE / ridge (MMP9)'))
pd<-position_dodge(width=.5)
pS5d<-ggplot(ee,aes(cohort,AUC,color=model,shape=model,group=model))+
 geom_hline(yintercept=.5,linetype=2,color='#A5ADB4',linewidth=.3)+
 geom_errorbar(aes(ymin=CI95_lower_DeLong,ymax=CI95_upper_DeLong),position=pd,width=.12,linewidth=.4)+
 geom_point(position=pd,size=2)+scale_color_manual(values=unname(c(pal['blue'],pal['gray'],pal['orange'])))+
 scale_shape_manual(values=c(16,17,15))+scale_y_continuous(limits=c(.39,1.035),breaks=c(.4,.6,.8,1))+
 scale_x_discrete(labels=c(GSE48060='GSE48060\nn = 52',GSE61144='GSE61144\nn = 17',GSE59867='GSE59867\nn = 157'))+
 labs(x=NULL,y='AUC (95% DeLong CI)',color=NULL,shape=NULL,title='D  External model sensitivity',subtitle='n = 17: AUC = 1 gives a degenerate CI, not certainty')+
 theme(legend.position='bottom',legend.box='vertical')+guides(color=guide_legend(ncol=1),shape=guide_legend(ncol=1))
figS5<-(pS5a|pS5b)/(pS5c|pS5d)+plot_layout(heights=c(1,1.05));save_pub(figS5,'S5_Fig',210)
write(r,'S5A_all_repeat_OOF');write(s,'S5A_descriptive_means_ranges');write(g,'S5B_all_gene_frequencies_including_zero');write(p,'S5C_all_panel_frequencies');write(ee,'S5D_all_external_model_comparisons')
write.csv(qa,file.path(out,'numeric_QA_checks.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo_render.txt'))
cat('Completed five R figures without refitting or changing source values.\n')
