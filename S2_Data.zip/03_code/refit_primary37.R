# Edition20 path/scope adapter: same original scientific fitting body; only current primary branch.
# Post-review sensitivity: archived methods, discovery/internal outcomes only.
options(stringsAsFactors=FALSE,width=200)
suppressPackageStartupMessages({library(caret);library(glmnet);library(pROC);library(randomForest);library(xgboost);library(Boruta);library(jsonlite);library(digest)})
args <- commandArgs(trailingOnly=TRUE)
script_arg <- sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
if(length(args)!=2L)stop('Usage: Rscript refit_primary37.R EXTRACTED_S2 NEW_OUTPUT')
root <- normalizePath(args[1],winslash='/',mustWork=TRUE)
out<-args[2];if(file.exists(out))stop('Use a nonexistent output directory');dir.create(out,recursive=TRUE)
sink(file.path(out,'03_threshold_sensitivity_selectors.log'),split=TRUE)
warnings_log<-character()
options(warn=1)
run <- function() {
 inp<-readRDS(file.path(root,'01_inputs/discovery_selection_inputs.rds'));summary<-data.frame(variant='positive_sources_original_disease',reuse_representative='positive_sources_original_disease')
 md<-inp$metadata;expr<-inp$expr; idx_dev<-md$cohort=='Discovery';idx_val<-md$cohort=='Validation'
 stopifnot(sum(idx_dev)==43,sum(idx_val)==56)
 y_dev<-factor(md$group[idx_dev],levels=c('MI','Control'));y_val<-factor(md$group[idx_val],levels=c('Control','MI'))
 archive_script<-file.path(root,'03_code/source_functions.R')
 parsed<-parse(archive_script)
 required<-c('make_inner_control','lasso_grid','xgb_grid','svm_grid','fit_xgb_native','predict_xgb_native','fit_one','full_ctrl')
 for(ex in parsed) if(is.call(ex)&&identical(as.character(ex[[1]]),'<-')&&is.symbol(ex[[2]])&&as.character(ex[[2]])%in%required)eval(ex,envir=.GlobalEnv)
 writeLines(c(paste0('Archived function source SHA256: ',digest(file=archive_script,algo='sha256')),
 'This command fits the final discovery selectors and internal subset screen only; full-workflow outer evaluation has a separate worker.',
 'LASSO seed20271001 repeated5x3; SVM seed20273003 RFE5fold plus inner5fold; XGBseed20274004 native5fold; Boruta primaryseed20260915 maxRuns500, Confirmedonly.',
 'Current primary has 36 measured candidates; the archived pmin rule gives RFE sizes 5,10,20,36. Boruta Confirmed, not RF top-k, supplies the voting selector.',
 'Boruta primary run matches the membership rule; the archived additional29 seeds are descriptive stability, not used to define membership, and are not repeated for threshold variants.',
 'Ridge fold assignments read from archived discovery_fold_assignment.csv. Enumerate all2:min(7,votepool) subsets. Internal maxAUC and one-SE-style selection match archived script. No external matrix or labels loaded.',
 'This entry point fits only the current positive-source primary: 37 biological overlaps, 36 measured candidates. No historical or strict-disease branch is executed.'),file.path(out,'sensitivity_implementation_scope.txt'))
 final_rows<-list();pool_rows<-list()
 reps<-'positive_sources_original_disease'
 for(v in reps) {
  od<-file.path(out,paste0('variant_',v));dir.create(od,recursive=TRUE,showWarnings=FALSE)
  genes<-inp$candidate_sets[[v]];stopifnot(length(genes)==36L,!('F2'%in%genes),!('CES1'%in%genes))
  x_dev<<-as.data.frame(t(expr[genes,md$sample_id[idx_dev],drop=FALSE]),check.names=FALSE)
  x_val<-as.matrix(t(expr[genes,md$sample_id[idx_val],drop=FALSE]))
  rfe_sizes<<-unique(pmin(ncol(x_dev),c(5,10,20,40,80,120)))
  rf_grid<<-data.frame(mtry=unique(pmax(1,pmin(ncol(x_dev),c(5,10,14,20,40)))))
  cat(format(Sys.time()),'VARIANT',v,'candidates',length(genes),'RFE sizes',rfe_sizes,'\n')
  write.csv(data.frame(gene=genes),file.path(od,'candidate_genes.csv'),row.names=FALSE)
  fits<-list();sets<-list();params<-list()
  for(a in c('LASSO','SVM-RFE','XGBoost')) {
   seed<-c(LASSO=20271001L,`SVM-RFE`=20273003L,XGBoost=20274004L)[[a]]
   cat(format(Sys.time()),'FITTING',a,'seed',seed,'\n');flush.console()
   fit<-fit_one(a,x_dev,y_dev,seed,final_control=full_ctrl)
   fits[[a]]<-fit
   if(a=='LASSO') {cf<-as.matrix(coef(fit$finalModel,s=fit$bestTune$lambda));sets[[a]]<-sort(setdiff(rownames(cf)[cf[,1]!=0],'(Intercept)'));cv<-fit$results;tune<-fit$bestTune}
   if(a=='SVM-RFE') {sets[[a]]<-sort(predictors(fit));cv<-fit$results;tune<-cbind(n_features=length(sets[[a]]),fit$fit$bestTune)}
   if(a=='XGBoost') {vi<-xgb.importance(model=fit$model);feature_col<-if('Features'%in%names(vi))'Features' else 'Feature';sets[[a]]<-sort(vi[[feature_col]][vi$Gain>0]);cv<-fit$cv_results;tune<-fit$bestTune;write.csv(vi,file.path(od,'XGBoost_importance.csv'),row.names=FALSE)}
   write.csv(cv,file.path(od,paste0(gsub('-','_',a),'_cv_results.csv')),row.names=FALSE)
   write.csv(tune,file.path(od,paste0(gsub('-','_',a),'_selected_parameters.csv')),row.names=FALSE)
   params[[a]]<-list(seed=seed,bestTune=tune,n_selected=length(sets[[a]]),genes=sets[[a]])
   saveRDS(fit,file.path(od,paste0(gsub('-','_',a),'_fit.rds')),compress='xz')
   cat(format(Sys.time()),a,'SELECTED',paste(sets[[a]],collapse=';'),'\n');flush.console()
  }
  cat(format(Sys.time()),'FITTING Boruta primary seed20260915\n');flush.console()
  set.seed(20260915L)
  b<-Boruta(x=x_dev,y=factor(md$group[idx_dev],levels=c('Control','MI')),maxRuns=500,doTrace=0,holdHistory=TRUE,getImp=getImpRfZ)
  sets[['Boruta']]<-sort(getSelectedAttributes(b,withTentative=FALSE));bs<-attStats(b);bs$gene<-rownames(bs)
  write.csv(bs,file.path(od,'Boruta_attribute_statistics.csv'),row.names=FALSE);saveRDS(b,file.path(od,'Boruta_fit.rds'),compress='xz')
  params[['Boruta']]<-list(seed=20260915,maxRuns=500,rule='Confirmed only',genes=sets[['Boruta']])
  membership<-data.frame(gene=genes)
  for(a in c('LASSO','SVM-RFE','Boruta','XGBoost'))membership[[a]]<-as.integer(genes%in%sets[[a]])
  membership$n_algorithms<-rowSums(membership[,-1]);pool<-sort(membership$gene[membership$n_algorithms>=2])
  write.csv(membership,file.path(od,'four_algorithm_membership.csv'),row.names=FALSE)
  write_json(params,file.path(od,'all_selector_parameters.json'),pretty=TRUE,auto_unbox=TRUE)
  cat(format(Sys.time()),'VOTE POOL',length(pool),paste(pool,collapse=';'),'\n');flush.console()
  if(length(pool)<2)stop('Vote pool has fewer than2 genes; no multi-gene subset can be fitted.')
  folds<-read.csv(file.path(root,'01_inputs/discovery_ridge_fold_assignment.csv'))
  foldid<-folds$fold[match(md$sample_id[idx_dev],folds$sample_id)];stopifnot(!anyNA(foldid))
  combinations<-unlist(lapply(2:min(7,length(pool)),function(k)combn(pool,k,simplify=FALSE)),recursive=FALSE)
  names(combinations)<-sprintf('S%03d',seq_along(combinations))
  models<-list();metrics<-list();predictions<-list()
  for(sid in names(combinations)) {
   g<-combinations[[sid]]
   f<-cv.glmnet(x=as.matrix(x_dev[,g,drop=FALSE]),y=as.integer(y_dev=='MI'),family='binomial',alpha=0,foldid=foldid,type.measure='deviance',standardize=TRUE,intercept=TRUE)
   prob<-as.numeric(predict(f,newx=x_val[,g,drop=FALSE],s='lambda.1se',type='response'));pr<-pmin(pmax(prob,1e-8),1-1e-8)
   r<-roc(y_val,pr,levels=c('Control','MI'),direction='<',quiet=TRUE);ci<-as.numeric(ci.auc(r,method='delong'));y01<-as.integer(y_val=='MI')
   models[[sid]]<-list(genes=g,lambda_1se=f$lambda.1se,cvfit=f)
   metrics[[sid]]<-data.frame(subset_id=sid,genes=paste(g,collapse=';'),n_genes=length(g),n=56,ROC_AUC_internal=as.numeric(auc(r)),AUC_SE_internal=sqrt(as.numeric(pROC::var(r))),AUC_CI_low_internal=ci[1],AUC_CI_high_internal=ci[3],log_loss_internal=-mean(y01*log(pr)+(1-y01)*log(1-pr)),Brier_internal=mean((pr-y01)^2))
   predictions[[sid]]<-data.frame(subset_id=sid,genes=paste(g,collapse=';'),sample_id=md$sample_id[idx_val],truth=as.character(y_val),probability_MI=prob)
  }
  metrics<-do.call(rbind,metrics);best<-metrics[order(-metrics$ROC_AUC_internal,metrics$n_genes,metrics$log_loss_internal),][1,]
  floor<-best$ROC_AUC_internal-best$AUC_SE_internal;eligible<-metrics[metrics$ROC_AUC_internal>=floor,];eligible<-eligible[eligible$n_genes==min(eligible$n_genes),];selected<-eligible[order(eligible$log_loss_internal,-eligible$ROC_AUC_internal),][1,]
  lock<-data.frame(selection_rule=c('Maximum internal validation AUC among2-7gene subsets','AUC one-SE-style parsimony rule; internal validation only'),subset_id=c(best$subset_id,selected$subset_id),genes=c(best$genes,selected$genes),n_genes=c(best$n_genes,selected$n_genes),internal_AUC=c(best$ROC_AUC_internal,selected$ROC_AUC_internal),internal_AUC_SE=c(best$AUC_SE_internal,selected$AUC_SE_internal),one_SE_floor_from_best=floor)
  write.csv(metrics,file.path(od,'all_subset_metrics_internal_only.csv'),row.names=FALSE);write.csv(do.call(rbind,predictions),file.path(od,'all_subset_predictions_internal_only.csv'),row.names=FALSE);saveRDS(models,file.path(od,'all_subset_ridge_models.rds'),compress='xz')
  write.csv(lock,file.path(od,'SELECTION_LOCK_INTERNAL_ONLY.csv'),row.names=FALSE)
  for(alias in summary$variant[summary$reuse_representative==v]) {z<-lock;z$variant<-alias;z$execution_status<-if(alias==v)'New same-method discovery/internal rerun' else paste('Reused exact same candidate SHA256 as',v);final_rows[[alias]]<-z;pool_rows[[alias]]<-data.frame(variant=alias,gene=pool,source='new >=2vote pool')}
  cat(format(Sys.time()),'COMPLETED',v,'subsets',nrow(metrics),'\n');print(lock);flush.console()
 }
 all_selected<-do.call(rbind,final_rows);write.csv(all_selected,file.path(out,'disease_threshold_selected_panels.csv'),row.names=FALSE);write.csv(do.call(rbind,pool_rows),file.path(out,'disease_threshold_vote_pools.csv'),row.names=FALSE)
 final<-summary
 selected<-all_selected[grepl('one-SE',all_selected$selection_rule),]
 final$selected_genes<-selected$genes[match(final$variant,selected$variant)];final$internal_selection_AUC<-selected$internal_AUC[match(final$variant,selected$variant)];final$execution_status<-selected$execution_status[match(final$variant,selected$variant)]
 write.csv(final,file.path(out,'disease_threshold_final_summary.csv'),row.names=FALSE)
 saveRDS(list(summary=final,selected=all_selected),file.path(out,'sensitivity_final_results.rds'))
 writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo_sensitivity.txt'))
 cat('ALL SENSITIVITY ANALYSES COMPLETE\n');print(final)
}
status<-tryCatch(withCallingHandlers({run();'completed'},warning=function(w){warnings_log<<-c(warnings_log,paste(format(Sys.time()),conditionMessage(w)))}),error=function(e){writeLines(conditionMessage(e),file.path(out,'sensitivity_ERROR.txt'));cat('ERROR:',conditionMessage(e),'\n');'failed'})
writeLines(warnings_log,file.path(out,'sensitivity_warnings.txt'))
write_json(list(status=status,finished=as.character(Sys.time()),external_outcomes_loaded=FALSE),file.path(out,'sensitivity_execution_status.json'),pretty=TRUE,auto_unbox=TRUE)
sink()
if(status=='failed')quit(status=1)
