"""Restore retained input/code paths; never synthesize omitted model caches.

Direct fixed-score replay and primary refitting are separate self-contained
entry points. This utility supports inspection and original relative-path code.
"""
from pathlib import Path, PurePosixPath
import argparse, csv, gzip, hashlib, io, json, shutil, zipfile


def safe(root, name):
    p = PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or ':' in name or '\\' in name:
        raise ValueError(name)
    return root / Path(*p.parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--s2', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--s1', help='Optional edition20 S1_Data.zip')
    ap.add_argument('--data-dir', help='Optional directory containing S3/S4')
    args = ap.parse_args()
    src = Path(args.s2).resolve()
    out = Path(args.out).resolve()
    if out.exists():
        raise FileExistsError('Choose a nonexistent output directory')
    rows = list(csv.DictReader((src / 'SOURCE_MAP.csv').open(encoding='utf-8-sig', newline='')))
    out.mkdir(parents=True)
    restored, not_restored = [], []
    for r in rows:
        t = r['transformation']
        p = safe(out, r['original_member'])
        if t == 'byte-identical':
            b = safe(src, r['file']).read_bytes()
        elif t == 'gzip lossless':
            b = gzip.decompress(safe(src, r['file']).read_bytes())
        elif t == 'CSV stack; preserve source member/row':
            rr = list(csv.DictReader(safe(src, r['file']).open(encoding='utf-8-sig', newline='')))
            rr = [{k: v for k, v in x.items() if k not in ['source_member', 'source_row']}
                  for x in rr if x['source_member'] == r['original_member']]
            s = io.StringIO(newline='')
            w = csv.DictWriter(s, fieldnames=list(rr[0]))
            w.writeheader()
            w.writerows(rr)
            b = s.getvalue().encode()
        elif t in ['verbatim labeled text sections', 'verbatim labeled sessionInfo sections']:
            text = safe(src, r['file']).read_bytes().decode('utf-8')
            marker = '===== ' + r['original_member'] + ' =====\n'
            start = text.index(marker) + len(marker)
            end = text.find('\n\n===== ', start)
            b = text[start:end if end >= 0 else len(text)].encode('utf-8')
        else:
            not_restored.append(r['original_member'])
            continue
        if t in ['byte-identical', 'gzip lossless']:
            assert hashlib.sha256(b).hexdigest() == r['original_sha256']
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(b)
        restored.append(r['original_member'])
    work = out / 'analysis_workspace'
    shutil.copytree(out / 'current_20261019/workspace_template', work)
    fn = work / '01_inputs/extracted/S2_Data/consensus_ml/code/02_nested_ml_consensus.R'
    fn.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src / '03_code/source_functions.R', fn)
    af = work / '01_inputs/extracted/S1_Data/compact_panel/results/discovery_fold_assignment.csv'
    af.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src / '01_inputs/discovery_ridge_fold_assignment.csv', af)
    ar = work / '01_inputs/extracted/S2_Data/base_pipeline/processed'
    ar.mkdir(parents=True, exist_ok=True)
    for name in ['GSE66360_sample_metadata.csv', 'GSE48060_sample_metadata.csv',
                 'GPL570_probe_to_gene_selected_by_discovery_IQR.csv']:
        shutil.copy2(src / '01_inputs' / name, ar / name)
    s1_count = 0
    if args.s1:
        with zipfile.ZipFile(args.s1) as z:
            mapping = list(csv.DictReader(io.StringIO(z.read('SOURCE_MAP.csv').decode('utf-8-sig'))))
            for r in mapping:
                if not r.get('original_member') or not r.get('new_member'):
                    continue
                old = r['original_member']
                raw = z.read(r['new_member'])
                if r['mode'] == 'csv_group':
                    cols = json.loads(r['source_columns_json'])
                    txt = gzip.decompress(raw) if r['new_member'].endswith('.gz') else raw
                    table = list(csv.DictReader(io.StringIO(txt.decode('utf-8-sig'))))
                    source_table_member = r.get('source_table_member') or old
                    table = sorted((x for x in table if x['source_member'] == source_table_member),
                                   key=lambda x: int(x['source_row']))
                    assert len(table) == int(r['source_rows'])
                    values = [{k: x.get(k, '') for k in cols} for x in table]
                    s = io.StringIO(newline='')
                    writer = csv.DictWriter(s, fieldnames=cols)
                    writer.writeheader()
                    writer.writerows(values)
                    raw = s.getvalue().encode()
                    if old.endswith('.gz'):
                        raw = gzip.compress(raw, mtime=0)
                elif r['mode'] == 'copy':
                    assert hashlib.sha256(raw).hexdigest() == r['sha256_original']
                else:
                    raise ValueError('Unknown S1 transformation: '+r['mode'])
                target = safe(out / 'public_S1_original_paths', old)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(raw)
                s1_count += 1
        public = out / 'public_S1_original_paths'
        original = public / 'archived_original_S1'
        if original.exists():
            shutil.copytree(original, work / '01_inputs/extracted/S1_Data', dirs_exist_ok=True)
        shutil.copytree(public, work / 'public_S1')
        for name in ['locked_ALPL_PLAU_coefficients.csv', 'PFOS_source_count_audit_all_genes.csv']:
            choices = list(public.rglob(name))
            if choices:
                dest = work / '03_ml' / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(choices[0], dest)
        ext = work / '09_additional_experiments_20261018/02_metadata_external/results_locked_external'
        ext.mkdir(parents=True, exist_ok=True)
        for acc in ['GSE61144', 'GSE59867']:
            name = acc + '_limma_all_mapped_genes.csv.gz'
            choices = list(public.rglob(name))
            if choices:
                shutil.copy2(choices[0], ext / name)
    if args.data_dir:
        for name in ['S3_Data.csv.gz', 'S4_Data.csv.gz']:
            shutil.copy2(Path(args.data_dir) / name, work / '01_inputs' / name)
    report = dict(restored=restored, not_restored_to_legacy_layout=not_restored,
                  restored_S1_tables=s1_count, workspace=str(work),
                  scope='INPUT_CODE_LAYOUT_ONLY_NO_FITTING_NO_MISSING_CACHE_SYNTHESIS',
                  limitations='Legacy strict18 preparation and figure paths may require recorded aliases; the direct primary refit and fixed-score replay do not use this tree.')
    (out / 'RESTORATION_REPORT.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(dict(restored_files=len(restored), restored_S1_tables=s1_count,
                         workspace=str(work), scope=report['scope']), indent=2))


if __name__ == '__main__':
    main()
