# Frozen prediction replay only. Does not select features or refit a model.
options(stringsAsFactors=FALSE,digits=17)
suppressPackageStartupMessages({library(glmnet);library(pROC);library(jsonlite)})
args<-commandArgs(trailingOnly=TRUE)
if(length(args)!=3L)stop('Usage: Rscript replay_fixed_panel.R EXTRACTED_S2 DATA_DIR NEW_OUTPUT_DIR')
root<-normalizePath(args[1],winslash='/',mustWork=TRUE)
data<-normalizePath(args[2],winslash='/',mustWork=TRUE);out<-args[3]
if(file.exists(out))stop('Use a nonexistent output directory')
dir.create(out,recursive=TRUE)
readcsv<-function(p)read.csv(p,check.names=FALSE)
readexpr<-function(p){d<-readcsv(gzfile(p));x<-as.matrix(d[,-1]);rownames(x)<-d[[1]];storage.mode(x)<-'double';x}
m<-readRDS(file.path(root,'02_final_models/ALPL_PLAU_primary37_S015.rds'))
stopifnot(identical(m$genes,c('ALPL','PLAU')))
cf<-as.matrix(coef(m$cvfit,s=m$lambda_1se))[,1]
expected<-c(GSE66360=0.883928571428571,GSE48060=0.732718894009217,GSE61144=0.928571428571429,GSE59867=0.660203681942812)
results<-list()
for(acc in names(expected)){
 if(acc%in%c('GSE66360','GSE48060')){
  x<-readexpr(file.path(data,if(acc=='GSE66360')'S3_Data.csv.gz'else'S4_Data.csv.gz'))
  md<-readcsv(file.path(root,'01_inputs',paste0(acc,'_sample_metadata.csv')))
  if(acc=='GSE66360')md<-md[md$cohort=='Validation',,drop=FALSE]
 }else{
  x<-readexpr(file.path(root,'01_inputs',paste0(acc,'_gene_expression_log2.csv.gz')))
  md<-readcsv(file.path(root,'01_inputs',paste0(acc,'_eligible_samples.csv')))
 }
 stopifnot(!anyDuplicated(md$sample_id),all(md$sample_id%in%colnames(x)))
 z<-t(x[m$genes,md$sample_id,drop=FALSE]);score<-drop(cf['(Intercept)']+z%*%cf[m$genes]);prob<-plogis(score)
 native<-drop(predict(m$cvfit,newx=z,s=m$lambda_1se,type='response'))
 stopifnot(max(abs(native-prob))<1e-12)
 r<-roc(md$group,score,levels=c('Control','MI'),direction='<',quiet=TRUE);ci<-as.numeric(ci.auc(r,method='delong'))
 stopifnot(abs(as.numeric(auc(r))-expected[[acc]])<1e-12)
 results[[acc]]<-data.frame(cohort=acc,n=nrow(md),AUC=as.numeric(auc(r)),CI_low=ci[1],CI_high=ci[3],formula_model_max_difference=max(abs(native-prob)))
 write.csv(data.frame(sample_id=md$sample_id,truth=md$group,linear_score=score,probability_MI=prob),file.path(out,paste0(acc,'_predictions.csv')),row.names=FALSE)
}
write.csv(do.call(rbind,results),file.path(out,'fixed_panel_AUC.csv'),row.names=FALSE)
write.csv(data.frame(term=names(cf),coefficient=unname(cf)),file.path(out,'coefficients.csv'),row.names=FALSE)
write_json(list(scope='FROZEN_MODEL_ARITHMETIC_REPLAY_NO_REFITTING',results=do.call(rbind,results),external_status='Retrospective independently sourced cohorts, not untouched confirmatory tests'),file.path(out,'verification.json'),pretty=TRUE,auto_unbox=TRUE,digits=17)
writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
print(do.call(rbind,results))
