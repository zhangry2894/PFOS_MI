options(stringsAsFactors=FALSE,width=180,warn=1)
suppressPackageStartupMessages({library(glmnet);library(pROC);library(jsonlite);library(digest)})
script_file <- normalizePath(sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),winslash='/')
package_root <- dirname(dirname(script_file))
args <- commandArgs(trailingOnly=TRUE)
input_root <- file.path(package_root,'inputs')
base <- if(length(args))args[1]else file.path(package_root,'replay_run')
if(file.exists(file.path(base,'external/external_result.json')))stop('Completed external output exists; choose a fresh output directory')
od <- file.path(base,'external');dir.create(od,showWarnings=FALSE)
outer <- file.path(base,'outer');dir.create(outer,showWarnings=FALSE)
lock_path <- file.path(base,'fit/SELECTION_LOCK_INTERNAL_ONLY.csv')
stopifnot(file.exists(lock_path),file.exists(file.path(base,'fit_result.json')))
lock <- read.csv(lock_path); models <- readRDS(file.path(base,'fit/all_subset_ridge_models.rds'))
input_sources <- c(lock=lock_path,models=file.path(base,'fit/all_subset_ridge_models.rds'))
extbase <- input_root
results<-list();mapping<-list();checks<-list()
for(acc in c('GSE48060','GSE61144','GSE59867')){
 xp<-file.path(input_root,paste0(acc,'_strict18_gene_expression.csv.gz'))
 mp<-file.path(input_root,paste0(acc,'_sample_metadata.csv'))
 input_sources<-c(input_sources,setNames(c(xp,mp),paste0(acc,c('_expression','_metadata'))))
 x<-as.matrix(read.csv(gzfile(xp),row.names=1,check.names=FALSE));storage.mode(x)<-'double';md<-read.csv(mp,check.names=FALSE)
 stopifnot(all(md$sample_id%in%colnames(x)),!anyDuplicated(md$sample_id));x<-x[,md$sample_id,drop=FALSE]
 y<-factor(md$group,levels=c('Control','MI'));expected<-switch(acc,GSE48060=c(21,31),GSE61144=c(10,7),GSE59867=c(46,111));stopifnot(identical(as.integer(table(y)),as.integer(expected)))
 if(acc!='GSE48060')stopifnot(!anyDuplicated(md$subject_id_verified))
 for(i in seq_len(nrow(lock))){
  m<-models[[lock$subset_id[i]]]; g<-m$genes
  mapping[[paste(acc,i)]]<-data.frame(accession=acc,rule=lock$selection_rule[i],gene=g,present=g%in%rownames(x))
  if(!all(g%in%rownames(x)))stop('Missing target mapping. No surrogate feature permitted.')
  nx<-t(x[g,,drop=FALSE]);stopifnot(all(is.finite(nx)))
  cf<-as.matrix(coef(m$cvfit,s='lambda.1se'))[,1]
  score<-as.numeric(cf['(Intercept)']+nx%*%cf[g]);native<-as.numeric(predict(m$cvfit,newx=nx,s='lambda.1se',type='link'));stopifnot(max(abs(score-native))<1e-10)
  prob<-plogis(score);r<-roc(y,score,levels=c('Control','MI'),direction='<',quiet=TRUE);ci<-as.numeric(ci.auc(r,method='delong'))
  tag<-if(i==1)'maximum_AUC'else'one_SE_style'
  pred<-data.frame(sample_id=md$sample_id,group=as.character(y),nx,linear_score=score,probability_MI=prob,check.names=FALSE)
  write.csv(pred,file.path(od,paste0(acc,'_',tag,'_fixed_predictions.csv')),row.names=FALSE)
  saveRDS(list(roc=r,model=m,metadata=md,score=score),file.path(od,paste0(acc,'_',tag,'_evaluation.rds')),compress='xz')
  results[[paste(acc,i)]]<-data.frame(accession=acc,rule=tag,genes=lock$genes[i],n=length(y),n_MI=sum(y=='MI'),n_control=sum(y=='Control'),AUC=as.numeric(auc(r)),CI_low=ci[1],CI_high=ci[3],Brier_descriptive=mean((prob-as.integer(y=='MI'))^2),log_loss_descriptive=-mean(as.integer(y=='MI')*log(pmax(prob,1e-8))+(1-as.integer(y=='MI'))*log(pmax(1-prob,1e-8))),refit=FALSE,direction='<',new_normalization=FALSE,comparator=if(acc=='GSE59867')'stable CAD'else'normal/normal-cardiac-function',predict_arithmetic_max_difference=max(abs(score-native)))
 }
}
res<-do.call(rbind,results);write.csv(res,file.path(od,'external_fixed_score_performance.csv'),row.names=FALSE);write.csv(do.call(rbind,mapping),file.path(od,'selected_gene_mapping_availability.csv'),row.names=FALSE)
write.csv(data.frame(role=names(input_sources),path=input_sources,sha256=vapply(input_sources,function(f)digest(file=f,algo='sha256'),character(1))),file.path(od,'INPUT_MANIFEST_SHA256.csv'),row.names=FALSE)
write_json(list(status='completed',completed=as.character(Sys.time()),lock_sha256=digest(file=lock_path,algo='sha256'),external_rules='Both internally frozen panel rules evaluated; neither panel nor algorithm selected by external AUC. MI positive, direction fixed, no refitting, no standardization.',results=res,caveats=c('Exploratory post-review sensitivity, not untouched confirmation.','Cross-platform probabilities are uncalibrated; Brier/log loss descriptive only.','Conditional DeLong intervals do not include model selection uncertainty.','No new exposure, causal, clinical or target-validation claim.')),file.path(od,'external_result.json'),auto_unbox=TRUE,pretty=TRUE,digits=17)
print(res)
# Reuse the archived probe-level values and all 15 immutable paired outer splits.
op<-file.path(input_root,'outer_source_inputs.rds')
inp<-readRDS(op); g<-read.csv(file.path(base,'fit/candidate_genes.csv'))$gene
stopifnot(length(g)==18,all(g%in%inp$probe_map$SYMBOL),length(inp$partitions)==15L)
inp$candidate_sets<-list(strict18=g);inp$probe_map<-inp$probe_map[inp$probe_map$SYMBOL%in%g,];inp$probe_expression<-inp$probe_expression[unique(inp$probe_map$PROBEID),,drop=FALSE]
saveRDS(inp,file.path(outer,'inputs.rds'),compress='xz')
write.csv(inp$probe_map,file.path(outer,'all_eligible_probe_gene_mappings.csv'),row.names=FALSE)
write.csv(inp$metadata,file.path(outer,'sample_metadata.csv'),row.names=FALSE)
write_json(list(created=as.character(Sys.time()),source=op,source_sha256=digest(file=op,algo='sha256'),candidate_count=length(g),genes=g,n_outer_splits=length(inp$partitions),probe_selection='Repeated by IQR using outer discovery training only',selection='All selectors, tuning, voting, ridge subsets and choice repeated within training roles',test='Held-out discovery/selection predictions generated only after each selection lock',same_partitions_as_primary37=TRUE,seed_scheme='Same archived run_outer_worker.R scheme; no outcome-dependent seed changes',external_data_in_outer_inputs=FALSE,known_before_run='Full-data strict18 fit and external evaluations were conducted before this resampling; post-review, not preregistered'),file.path(outer,'PROTOCOL_AND_INPUT_LOCK.json'),auto_unbox=TRUE,pretty=TRUE)
writeLines(capture.output(sessionInfo()),file.path(od,'R_sessionInfo.txt'))
