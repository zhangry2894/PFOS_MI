# Locked retrospective external evaluation. This script never fits a prediction model.
options(stringsAsFactors=FALSE,width=200,warn=1,digits=17)
args<-commandArgs(trailingOnly=TRUE)
script<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
root<-normalizePath(if(length(args))args[1] else file.path(dirname(script),'..'),winslash='/',mustWork=TRUE)
complete<-normalizePath(file.path(root,'..'),winslash='/',mustWork=TRUE)
oldext<-file.path(complete,'09_additional_experiments_20261018/02_metadata_external')
marker<-file.path(root,'FINAL_MODELS_LOCKED.json')
if(!file.exists(marker))stop('FINAL_MODELS_LOCKED.json absent: external data/outcomes will not be opened')
modelpath<-file.path(root,'final/frozen_models.rds');mappath<-file.path(root,'final/selected_probe_map.csv')
stopifnot(file.exists(modelpath),file.exists(mappath))
suppressPackageStartupMessages({library(jsonlite);library(digest);library(pROC);library(limma)})
lock<-read_json(marker,simplifyVector=TRUE)
if(!is.null(lock$models_sha256))stopifnot(identical(lock$models_sha256,digest(file=modelpath,algo='sha256')))
if(!is.null(lock$probe_map_sha256))stopifnot(identical(lock$probe_map_sha256,digest(file=mappath,algo='sha256')))
stopifnot(file.info(modelpath)$mtime<=file.info(marker)$mtime,file.info(mappath)$mtime<=file.info(marker)$mtime)
out<-file.path(root,'external');dir.create(out,recursive=TRUE,showWarnings=FALSE)
if(file.exists(file.path(out,'external_evaluation_summary.json')))stop('Completed external evaluation exists; refusing overwrite')
warnings_log<-character();inputs_used<-c(marker,modelpath,mappath)
readcsv<-function(p,...)read.csv(p,check.names=FALSE,stringsAsFactors=FALSE,...)
readexpr<-function(p){d<-readcsv(gzfile(p),row.names=1);x<-as.matrix(d);storage.mode(x)<-'double';stopifnot(!anyDuplicated(rownames(x)),!anyDuplicated(colnames(x)),all(is.finite(x)));x}
addinput<-function(p){inputs_used<<-unique(c(inputs_used,p));invisible(p)}
audit<-list();ai<-0L
check<-function(name,pass,detail=''){ai<<-ai+1L;audit[[ai]]<<-data.frame(check=name,pass=isTRUE(pass),detail=detail);if(!isTRUE(pass))stop(paste('QA failure:',name,detail))}
canonical_de<-function(d,genes){
 if('gene_symbol'%in%names(d))d$gene<-d$gene_symbol
 stopifnot(all(c('gene','logFC','P.Value','adj.P.Val')%in%names(d)),!anyDuplicated(d$gene),setequal(d$gene,genes))
 d<-d[match(genes,d$gene),];stopifnot(all(is.finite(d$logFC)),all(is.finite(d$P.Value)),all(is.finite(d$adj.P.Val)),max(abs(p.adjust(d$P.Value,'BH')-d$adj.P.Val))<1e-10)
 d
}
calculate_de<-function(x,meta){
 group<-factor(meta$group,levels=c('Control','MI'));fit<-limma::eBayes(limma::lmFit(x,model.matrix(~group)))
 d<-limma::topTable(fit,coef='groupMI',number=Inf,adjust.method='BH',sort.by='none');d$gene<-rownames(d);canonical_de(d,rownames(x))
}
run<-function(){
 models<-readRDS(modelpath);stopifnot(all(c('ElasticNet','Classical_SVM_RFE_ridge')%in%names(models)))
 models<-models[c('ElasticNet','Classical_SVM_RFE_ridge')]
 for(nm in names(models)){
  m<-models[[nm]];g<-as.character(m$genes);cf<-m$coefficients
  check(paste0(nm,'_coefficient_interface'),is.numeric(cf)&&!is.null(names(cf))&&!anyDuplicated(names(cf))&&all(is.finite(cf))&&!anyDuplicated(g)&&length(g)<=7&&all(c('(Intercept)',g)%in%names(cf)))
  extra<-setdiff(names(cf),c('(Intercept)',g));check(paste0(nm,'_no_omitted_nonzero_terms'),!length(extra)||all(cf[extra]==0))
  models[[nm]]<-list(genes=g,coefficients=cf[c('(Intercept)',g)],zero_coefficient_terms_ignored=extra)
 }
 baselinepath<-addinput(file.path(complete,'03_ml/locked_ALPL_PLAU_coefficients.csv'))
 baseline<-readcsv(baselinepath);bc<-setNames(baseline$coefficient,baseline$term)
 check('baseline_coefficients_match_archived_lock',setequal(names(bc),c('(Intercept)','ALPL','PLAU'))&&max(abs(bc[c('(Intercept)','ALPL','PLAU')]-c(-2.75365860826474673,.29409821773437633,.19254761259727726)))<1e-12)
 models$Baseline_ALPL_PLAU<-list(genes=c('ALPL','PLAU'),coefficients=bc[c('(Intercept)','ALPL','PLAU')])
 coefrows<-do.call(rbind,lapply(names(models),function(nm)data.frame(model=nm,term=names(models[[nm]]$coefficients),coefficient=unname(models[[nm]]$coefficients))))
 write.csv(coefrows,file.path(out,'applied_frozen_coefficients.csv'),row.names=FALSE)
 # Every data read below occurs after the final model lock and interface checks.
 s4path<-addinput(file.path(complete,'01_inputs/S4_Data.csv.gz'));xold<-readexpr(s4path)
 metapath<-addinput(file.path(complete,'01_inputs/extracted/S2_Data/base_pipeline/processed/GSE48060_sample_metadata.csv'));meta48060<-readcsv(metapath)
 check('GSE48060_original_52_subjects',nrow(meta48060)==52&&!anyDuplicated(meta48060$sample_id)&&sum(meta48060$group=='MI')==31&&sum(meta48060$group=='Control')==21&&setequal(colnames(xold),meta48060$sample_id))
 xold<-xold[,meta48060$sample_id,drop=FALSE];xnew<-xold
 oldmappath<-addinput(file.path(complete,'01_inputs/extracted/S2_Data/base_pipeline/processed/GPL570_probe_to_gene_selected_by_discovery_IQR.csv'))
 oldmap<-readcsv(oldmappath);newmap<-readcsv(mappath)
 check('frozen_discovery_probe_map_interface',all(c('PROBEID','SYMBOL')%in%names(newmap))&&!anyDuplicated(newmap$SYMBOL)&&!anyDuplicated(newmap$PROBEID))
 check('new_model_genes_in_frozen_probe_map',all(unique(unlist(lapply(models[1:2],function(m)m$genes)))%in%newmap$SYMBOL))
 oldprobe<-oldmap$PROBEID[match(newmap$SYMBOL,oldmap$SYMBOL)]
 probeaudit<-data.frame(gene=newmap$SYMBOL,discovery_locked_probe=newmap$PROBEID,archived_probe=oldprobe,same_probe=!is.na(oldprobe)&newmap$PROBEID==oldprobe,max_abs_raw_vs_S4=NA_real_)
 raw<-if(length(args)>=2)args[2] else Sys.getenv('PFOS_GSE48060_SERIES',unset='H:/NT/xinnei/MI/PFOS/tougao/revise/tmp/02_data_raw/GSE48060_series_matrix.txt.gz')
 if(file.exists(raw)){
  addinput(normalizePath(raw,winslash='/'));suppressPackageStartupMessages(library(GEOquery))
  geo<-getGEO(filename=raw,getGPL=FALSE);xp<-Biobase::exprs(geo)
  check('raw_GSE48060_frozen_probe_and_sample_coverage',all(newmap$PROBEID%in%rownames(xp))&&all(meta48060$sample_id%in%colnames(xp))&&all(newmap$SYMBOL%in%rownames(xold)))
  chosen<-xp[newmap$PROBEID,meta48060$sample_id,drop=FALSE];rownames(chosen)<-newmap$SYMBOL
  check('raw_GSE48060_values_finite',all(is.finite(chosen)))
  probeaudit$max_abs_raw_vs_S4<-apply(abs(chosen-xold[newmap$SYMBOL,,drop=FALSE]),1,max)
  xnew[newmap$SYMBOL,]<-chosen
  probe_source<-'Official deposited processed probe matrix, evaluated at frozen Discovery-selected probes; no external probe selection or extra normalization'
 }else{
  check('archived_S4_only_allowed_when_frozen_probe_ids_match',all(probeaudit$same_probe))
  probe_source<-'Archived S4 gene matrix; all frozen Discovery probe IDs verified identical to archived map; raw series unavailable'
 }
 write.csv(probeaudit,file.path(out,'GSE48060_probe_and_expression_equivalence_audit.csv'),row.names=FALSE)
 existingdepath<-addinput(file.path(complete,'01_inputs/extracted/S1_Data/current_ml_results/limma_all_genes_all_cohorts.csv'))
 alloldde<-readcsv(existingdepath);oldde<-canonical_de(alloldde[alloldde$cohort=='GSE48060_external',],rownames(xold))
 changed<-max(abs(xnew-xold))>1e-8
 newde<-if(changed)calculate_de(xnew,meta48060) else oldde
 newdesource<-if(changed)'Recomputed limma after frozen-probe substitution; BH across complete mapped transcriptome' else 'Reused archived limma: raw frozen-probe values and S4 are equivalent within 1e-8'
 if(changed){con<-gzfile(file.path(out,'GSE48060_frozen_probe_all_gene_limma.csv.gz'),'wt');write.csv(newde,con,row.names=FALSE);close(con)}
 cohorts<-list(GSE48060=list(x=xnew,baseline_x=xold,meta=meta48060,de=newde,baseline_de=oldde,de_source=newdesource,baseline_de_source='Archived S4 all-gene limma',platform='GPL570',comparator='Control',n_MI=31,n_control=21,mapping=probe_source))
 for(acc in c('GSE61144','GSE59867')){
  xp<-addinput(file.path(oldext,'locked_external_inputs',paste0(acc,'_gene_expression_log2.csv.gz')));mp<-addinput(file.path(oldext,'locked_external_inputs',paste0(acc,'_eligible_samples.csv')));dp<-addinput(file.path(oldext,'results_locked_external',paste0(acc,'_limma_all_mapped_genes.csv.gz')))
  addinput(file.path(oldext,'locked_external_inputs',paste0(acc,'_probe_mapping_audit.csv.gz')))
  x<-readexpr(xp);meta<-readcsv(mp);expected<-if(acc=='GSE61144')c(MI=7,Control=10) else c(MI=111,Control=46)
  check(paste0(acc,'_frozen_participant_inclusion'),identical(colnames(x),meta$sample_id)&&!anyDuplicated(meta$subject_id_verified)&&sum(meta$group=='MI')==expected['MI']&&sum(meta$group=='Control')==expected['Control'])
  de<-canonical_de(readcsv(gzfile(dp)),rownames(x))
  cohorts[[acc]]<-list(x=x,baseline_x=x,meta=meta,de=de,baseline_de=de,de_source='Reused frozen all-gene limma table; BH independently rechecked across complete transcriptome',baseline_de_source='Same frozen all-gene limma',platform=if(acc=='GSE61144')'GPL6106' else 'GPL6244',comparator=if(acc=='GSE61144')'Normal controls; pre-PCI STEMI cases only' else 'Stable coronary artery disease; day-1 admission MI cases only',n_MI=unname(expected['MI']),n_control=unname(expected['Control']),mapping='Official GPL single-gene mapping; duplicate/ambiguous/nonfinite features excluded; sample-wise median of eligible probes; submitter log2 values retained')
 }
 perf<-preds<-deout<-coverage<-list();pi<-di<-ci<-0L
 for(acc in names(cohorts))for(nm in names(models)){
  co<-cohorts[[acc]];m<-models[[nm]];x<-if(nm=='Baseline_ALPL_PLAU')co$baseline_x else co$x;de<-if(nm=='Baseline_ALPL_PLAU')co$baseline_de else co$de;desource<-if(nm=='Baseline_ALPL_PLAU')co$baseline_de_source else co$de_source
  miss<-setdiff(m$genes,rownames(x));ci<-ci+1L;coverage[[ci]]<-data.frame(cohort=acc,model=nm,n_model_genes=length(m$genes),missing_genes=paste(miss,collapse=';'),scorable=!length(miss),n_genes_BH=nrow(de))
  if(length(m$genes))for(g in m$genes){di<-di+1L;ix<-match(g,de$gene);deout[[di]]<-data.frame(cohort=acc,model=nm,gene=g,present=!is.na(ix),logFC_MI_minus_control=if(is.na(ix))NA_real_ else de$logFC[ix],nominal_P=if(is.na(ix))NA_real_ else de$P.Value[ix],BH_q_whole_transcriptome=if(is.na(ix))NA_real_ else de$adj.P.Val[ix],n_genes_BH=nrow(de),DE_source=desource)}
  row<-data.frame(cohort=acc,model=nm,genes=paste(m$genes,collapse=';'),n_genes=length(m$genes),n=nrow(co$meta),n_MI=co$n_MI,n_control=co$n_control,platform=co$platform,comparator=co$comparator,status=if(length(miss))'unscorable_missing_feature' else 'scored',missing_genes=paste(miss,collapse=';'),AUC=NA_real_,CI95_lower_DeLong=NA_real_,CI95_upper_DeLong=NA_real_,positive_class='MI',direction='<',score='frozen original-expression linear score',model_refit=FALSE)
  if(!length(miss)){
   score<-rep(unname(m$coefficients['(Intercept)']),ncol(x));if(length(m$genes))score<-score+drop(t(x[m$genes,,drop=FALSE])%*%m$coefficients[m$genes])
   check(paste(acc,nm,'finite_locked_score',sep='_'),all(is.finite(score)))
   rr<-pROC::roc(factor(co$meta$group,levels=c('Control','MI')),score,levels=c('Control','MI'),direction='<',quiet=TRUE);interval<-as.numeric(pROC::ci.auc(rr,method='delong',conf.level=.95))
   row$AUC<-as.numeric(pROC::auc(rr));row$CI95_lower_DeLong<-interval[1];row$CI95_upper_DeLong<-interval[3]
   y<-as.integer(co$meta$group=='MI');rankauc<-(sum(rank(score,ties.method='average')[y==1])-sum(y)*(sum(y)+1)/2)/(sum(y)*sum(y==0));check(paste(acc,nm,'rank_AUC_agreement',sep='_'),abs(rankauc-row$AUC)<1e-12)
   pi<-pi+1L;preds[[pi]]<-data.frame(cohort=acc,model=nm,sample_id=co$meta$sample_id,subject_id=if('subject_id_verified'%in%names(co$meta))co$meta$subject_id_verified else co$meta$sample_id,truth=co$meta$group,linear_score=score)
  }
  perf[[paste(acc,nm)]]<-row
 }
 perf<-do.call(rbind,perf);prediction<-do.call(rbind,preds);genesde<-do.call(rbind,deout)
 write.csv(perf,file.path(out,'external_performance.csv'),row.names=FALSE)
 write.csv(prediction,file.path(out,'external_prediction_rows.csv'),row.names=FALSE)
 write.csv(genesde,file.path(out,'selected_gene_external_expression_BH.csv'),row.names=FALSE)
 write.csv(do.call(rbind,coverage),file.path(out,'external_gene_coverage.csv'),row.names=FALSE)
 sources<-do.call(rbind,lapply(names(cohorts),function(acc){x<-cohorts[[acc]];data.frame(cohort=acc,platform=x$platform,n=nrow(x$meta),n_MI=x$n_MI,n_control=x$n_control,n_mapped_genes=nrow(x$x),comparator=x$comparator,mapping=x$mapping,DE_source=x$de_source)}))
 write.csv(sources,file.path(out,'cohort_input_and_annotation_audit.csv'),row.names=FALSE)
 manifest<-data.frame(path=inputs_used,sha256=vapply(inputs_used,function(p)digest(file=p,algo='sha256'),character(1)))
 write.csv(manifest,file.path(out,'external_input_manifest_SHA256.csv'),row.names=FALSE)
 write.csv(do.call(rbind,audit),file.path(out,'external_QA_checks.csv'),row.names=FALSE)
 writeLines(capture.output(sessionInfo()),file.path(out,'sessionInfo.txt'))
 write_json(list(status='completed_locked_retrospective_evaluation',model_lock_sha256=digest(file=marker,algo='sha256'),frozen_models_sha256=digest(file=modelpath,algo='sha256'),script_sha256=digest(file=script,algo='sha256'),models=names(models),n_model_cohort_comparisons=nrow(perf),n_scorable=sum(perf$status=='scored'),n_unscorable=sum(perf$status!='scored'),n_prediction_rows=nrow(prediction),no_predictive_model_refit=TRUE,no_direction_flip=TRUE,external_performance_used_for_selection=FALSE,raw_GSE48060_available=file.exists(raw),GSE48060_new_probe_values_differ_from_archived_S4=changed,selected_gene_BH_family='All eligible mapped genes within each external cohort, not selected panel only',interpretation=c('Retrospective external evaluations; these data have been examined previously.','The fixed linear score is not a calibrated clinical probability.','DeLong intervals are conditional on the frozen score and do not cover development/selection uncertainty.','Cross-platform and cell-source differences and clinical confounding remain; PFOS exposure is unavailable.','Missing features remain unscorable; no external imputation, feature substitution or outcome-based probe choice.')),file.path(out,'external_evaluation_summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=17)
 cat('EXTERNAL_EVALUATION_COMPLETE\n');print(perf)
}
status<-tryCatch(withCallingHandlers({run();'completed'},warning=function(w){warnings_log<<-c(warnings_log,conditionMessage(w))}),error=function(e){write_json(list(status='failed',error=conditionMessage(e),time=as.character(Sys.time())),file.path(out,'FAILED.json'),pretty=TRUE,auto_unbox=TRUE);cat('FAILED:',conditionMessage(e),'\n');'failed'})
writeLines(warnings_log,file.path(out,'warnings.txt'))
if(status=='failed')quit(status=1)
