# Genuine linear SVM-RFE using squared primal weights (Guyon et al., 2002).
# This file defines functions only. It does not load project data or run training.
# Locked secondary-selector protocol: sizes 1:7, C .01/.1/1/10; inner 5-fold
# mean ROC AUC; ties prefer fewer features, then smaller C. No one-SE heuristic.

.svm_rfe_matrix <- function(x, label) {
  x <- as.matrix(x)
  storage.mode(x) <- 'double'
  if (!length(dim(x)) || nrow(x) < 2L || ncol(x) < 1L)
    stop(label, ': need at least two rows and one predictor')
  if (is.null(rownames(x)) || anyNA(rownames(x)) || any(!nzchar(rownames(x))) || anyDuplicated(rownames(x)))
    stop(label, ': unique nonempty sample row names required')
  if (is.null(colnames(x)) || anyNA(colnames(x)) || any(!nzchar(colnames(x))) || anyDuplicated(colnames(x)))
    stop(label, ': unique nonempty gene column names required')
  if (any(!is.finite(x))) stop(label, ': nonfinite values are not imputed')
  x
}

.svm_rfe_labels <- function(y, ids) {
  if (!is.null(names(y))) {
    if (anyDuplicated(names(y)) || !setequal(names(y), ids)) stop('Named y must match sample IDs exactly')
    y <- y[ids]
  }
  if (length(y) != length(ids) || anyNA(y) || any(!as.character(y) %in% c('Control', 'MI')))
    stop('y must contain Control/MI for every sample')
  y <- factor(as.character(y), levels=c('Control', 'MI'))
  if (any(table(y) == 0L)) stop('Both classes are required in each training/test subset')
  names(y) <- ids
  y
}

.svm_rfe_preprocess <- function(x) {
  center <- colMeans(x)
  sds <- apply(x, 2L, stats::sd)
  constant <- !is.finite(sds) | sds == 0
  if (all(constant)) stop('All predictors are constant in this training split')
  # Keep constant variables as zero columns so the full p -> 1 elimination
  # history remains explicit. They receive zero weights and are removed first.
  scale <- sds
  scale[constant] <- 1
  list(center=center, scale=scale, training_SD=sds,
       constant_features=names(sds)[constant], training_ids=rownames(x))
}

.svm_rfe_transform <- function(x, preprocessing) {
  if (!setequal(colnames(x), names(preprocessing$center))) stop('Prediction gene names differ from training genes')
  x <- x[, names(preprocessing$center), drop=FALSE]
  sweep(sweep(x, 2L, preprocessing$center, '-'), 2L, preprocessing$scale, '/')
}

.svm_rfe_orientation <- function(model) {
  # LIBSVM's binary decision > 0 predicts the first model label. Derive
  # orientation from the fitted class order, never from observed AUC.
  if (length(model$labels) != 2L || length(model$levels) != 2L)
    stop('Expected a binary factor-classification SVM')
  class_order <- model$levels[model$labels]
  if (!setequal(class_order, c('Control', 'MI'))) stop('Unexpected SVM class labels')
  list(positive_raw_decision_class=class_order[1L],
       negative_raw_decision_class=class_order[2L],
       MI_multiplier=if (class_order[1L] == 'MI') 1 else -1)
}

.svm_rfe_decision <- function(model, standardized_x) {
  predicted <- stats::predict(model, standardized_x, decision.values=TRUE)
  raw <- attr(predicted, 'decision.values')
  if (is.null(raw) || ncol(as.matrix(raw)) != 1L) stop('Missing binary decision values')
  raw <- as.numeric(raw)
  orientation <- .svm_rfe_orientation(model)
  # Independent algebraic check of e1071's decision values in the same frame.
  w <- drop(t(model$coefs) %*% as.matrix(model$SV))
  names(w) <- colnames(model$SV)
  calculated <- drop(standardized_x[, names(w), drop=FALSE] %*% w - model$rho)
  tolerance <- 1e-8 * (1 + max(abs(raw)))
  if (max(abs(calculated - raw)) > tolerance) stop('Primal decision check failed')
  nonzero <- abs(raw) > tolerance
  implied <- ifelse(raw > 0, orientation$positive_raw_decision_class,
                    orientation$negative_raw_decision_class)
  if (any(as.character(predicted)[nonzero] != implied[nonzero]))
    stop('LIBSVM decision/class orientation check failed')
  list(score_MI=orientation$MI_multiplier * raw, raw_decision=raw,
       predicted_class=as.character(predicted), orientation=orientation,
       maximum_primal_decision_difference=max(abs(calculated - raw)))
}

classical_svm_rfe_path <- function(x, y, cost, keep_sizes=seq_len(ncol(x))) {
  if (!requireNamespace('e1071', quietly=TRUE)) stop('Package e1071 is required')
  x <- .svm_rfe_matrix(x, 'Training x')
  y <- .svm_rfe_labels(y, rownames(x))
  if (length(cost) != 1L || !is.finite(cost) || cost <= 0) stop('cost must be positive')
  genes <- sort(colnames(x), method='radix')
  x <- x[, genes, drop=FALSE]
  prep <- .svm_rfe_preprocess(x)
  z <- .svm_rfe_transform(x, prep)
  keep_sizes <- sort(unique(as.integer(keep_sizes)))
  if (anyNA(keep_sizes) || any(keep_sizes < 1L | keep_sizes > ncol(x))) stop('Invalid keep_sizes')
  active <- genes
  path_rows <- vector('list', length(genes))
  weight_rows <- vector('list', length(genes))
  models <- list()
  warnings <- character()
  step <- 0L
  while (length(active)) {
    step <- step + 1L
    k <- length(active)
    fit <- withCallingHandlers(
      e1071::svm(x=z[, active, drop=FALSE], y=y, type='C-classification',
                 kernel='linear', cost=cost, scale=FALSE, probability=FALSE),
      warning=function(w) {
        warnings <<- c(warnings, paste0('size=', k, ': ', conditionMessage(w)))
      })
    if (nrow(fit$coefs) == 0L) stop('Empty SVM at feature count ', k)
    # e1071 drops SV dimnames when the input has one predictor. Restore only
    # names, after checking the retained vectors against their original input
    # rows and ordered columns; no numerical model quantity is modified.
    sv <- as.matrix(fit$SV)
    expected_sv <- z[fit$index, active, drop=FALSE]
    if (!identical(dim(sv), dim(expected_sv))) stop('Unexpected support-vector dimensions')
    sv_input_difference <- max(abs(unname(sv) - unname(expected_sv)))
    if (!is.finite(sv_input_difference) || sv_input_difference > 1e-12)
      stop('Support vectors do not match the ordered training coordinates')
    restored_sv_names <- is.null(colnames(sv))
    if (restored_sv_names) colnames(fit$SV) <- active
    if (!identical(colnames(fit$SV), active)) stop('Support-vector columns do not match the active genes')
    fit$rfe_feature_names <- active
    w <- drop(t(fit$coefs) %*% as.matrix(fit$SV))
    names(w) <- colnames(fit$SV)
    if (!setequal(names(w), active)) stop('Support-vector columns do not match the active genes')
    w <- w[active]
    if (any(!is.finite(w))) stop('Nonfinite primal weights')
    w2 <- w * w
    # Refit and rerank at EVERY elimination step. Exact ties: gene lexical order.
    ordering <- order(w2, names(w2), method='radix')
    removed <- if (k > 1L) names(w2)[ordering[1L]] else NA_character_
    orientation <- .svm_rfe_orientation(fit)
    path_rows[[step]] <- data.frame(step=step, n_features=k, cost=cost,
      features=paste(active, collapse=';'), eliminated_gene=removed,
      elimination_weight_squared=if(k > 1L) unname(w2[removed]) else NA_real_,
      raw_positive_class=orientation$positive_raw_decision_class,
      MI_decision_multiplier=orientation$MI_multiplier,
      restored_missing_sv_column_names=restored_sv_names,
      SV_training_coordinate_max_abs_difference=sv_input_difference,
      stringsAsFactors=FALSE)
    weight_rows[[step]] <- data.frame(step=step, n_features=k, cost=cost,
      gene=active, weight=as.numeric(w), weight_squared=as.numeric(w2),
      eliminated=if(k > 1L) active == removed else FALSE, stringsAsFactors=FALSE)
    if (k %in% keep_sizes) models[[as.character(k)]] <- fit
    if (k == 1L) break
    active <- active[active != removed]
  }
  list(cost=cost, preprocessing=prep, path=do.call(rbind, path_rows),
       weights=do.call(rbind, weight_rows), models=models,
       warnings=warnings, training_ids=rownames(x), feature_universe=genes,
       method='Linear SVM primal weight-squared RFE; one gene removed per refit',
       tie_rule='Exact equal squared weights: ascending gene name (radix order)')
}

classical_svm_rfe_predict <- function(path, newx, n_features) {
  newx <- as.matrix(newx)
  storage.mode(newx) <- 'double'
  if (any(!is.finite(newx))) stop('Nonfinite prediction values')
  fit <- path$models[[as.character(n_features)]]
  if (is.null(fit)) stop('Requested model size was not retained')
  z <- .svm_rfe_transform(newx, path$preprocessing)
  genes <- colnames(fit$SV)
  .svm_rfe_decision(fit, z[, genes, drop=FALSE])
}

classical_svm_rfe_select <- function(x, y, fold_id,
    costs=c(.01, .1, 1, 10), sizes=1:7, seed=20261019L, fold_data=NULL) {
  if (!requireNamespace('pROC', quietly=TRUE)) stop('Package pROC is required')
  x <- .svm_rfe_matrix(x, 'Full discovery x')
  ids <- rownames(x)
  y <- .svm_rfe_labels(y, ids)
  if (is.null(names(fold_id)) || anyDuplicated(names(fold_id)) ||
      !setequal(names(fold_id), ids) || anyNA(fold_id))
    stop('fold_id must have one named assignment for each sample ID')
  fold_id <- setNames(as.character(fold_id), names(fold_id))[ids]
  folds <- sort(unique(fold_id), method='radix')
  if (length(folds) != 5L) stop('Locked protocol requires exactly 5 folds')
  costs <- sort(unique(as.numeric(costs)))
  sizes <- sort(unique(as.integer(sizes)))
  if (!length(costs) || any(!is.finite(costs) | costs <= 0)) stop('Invalid costs')
  if (!length(sizes) || anyNA(sizes) || any(sizes < 1L | sizes > ncol(x))) stop('Invalid sizes')
  if (!is.null(fold_data) && (is.null(names(fold_data)) ||
      !setequal(names(fold_data), folds))) stop('fold_data must be named by fold_id values')
  if (length(seed)!=1L || !is.finite(seed)) stop('Invalid seed')
  had_seed <- exists('.Random.seed', envir=.GlobalEnv, inherits=FALSE)
  if (had_seed) previous_seed <- get('.Random.seed', envir=.GlobalEnv)
  on.exit({if(had_seed)assign('.Random.seed',previous_seed,envir=.GlobalEnv)
           else if(exists('.Random.seed',envir=.GlobalEnv,inherits=FALSE))rm('.Random.seed',envir=.GlobalEnv)}, add=TRUE)
  set.seed(as.integer(seed))
  metrics <- list(); predictions <- list(); paths <- list(); fold_audit <- list()
  for (fi in seq_along(folds)) {
    f <- folds[fi]
    train_ids <- ids[fold_id != f]; validation_ids <- ids[fold_id == f]
    if (is.null(fold_data)) {
      train_x <- x[train_ids,,drop=FALSE]
      validation_x <- x[validation_ids,,drop=FALSE]
    } else {
      supplied <- fold_data[[f]]
      train_x <- .svm_rfe_matrix(supplied$train_x,paste0('Fold ',f,' training x'))
      validation_x <- .svm_rfe_matrix(supplied$validation_x,paste0('Fold ',f,' validation x'))
      if (!setequal(rownames(train_x),train_ids) || !setequal(rownames(validation_x),validation_ids))
        stop('Fold ',f,': supplied training/validation IDs do not match fold_id')
      if (!setequal(colnames(train_x),colnames(x)) || !setequal(colnames(validation_x),colnames(x)))
        stop('Fold ',f,': supplied gene names differ from the frozen candidate set')
      train_x <- train_x[train_ids,colnames(x),drop=FALSE]
      validation_x <- validation_x[validation_ids,colnames(x),drop=FALSE]
    }
    train_y <- .svm_rfe_labels(y[train_ids],train_ids)
    validation_y <- .svm_rfe_labels(y[validation_ids],validation_ids)
    fold_audit[[f]] <- list(training_ids=train_ids,validation_ids=validation_ids,
      training_gene_means=colMeans(train_x),training_gene_SD=apply(train_x,2L,stats::sd),
      data_source=if(is.null(fold_data))'split of supplied fixed matrix' else 'caller-provided within-fold probe-choice matrices')
    for (ci in seq_along(costs)) {
      cost <- costs[ci]
      key <- paste0('fold_',f,'__C_',format(cost,scientific=FALSE,trim=TRUE))
      path <- classical_svm_rfe_path(train_x,train_y,cost=cost,keep_sizes=sizes)
      paths[[key]] <- path
      for (size in sizes) {
        pred <- classical_svm_rfe_predict(path,validation_x,n_features=size)
        roc <- pROC::roc(validation_y,pred$score_MI,levels=c('Control','MI'),direction='<',quiet=TRUE)
        metrics[[length(metrics)+1L]] <- data.frame(fold=f,cost=cost,n_features=size,
          n_training=length(train_ids),n_validation=length(validation_ids),
          ROC=as.numeric(pROC::auc(roc)),decision_algebra_max_abs_difference=pred$maximum_primal_decision_difference)
        predictions[[length(predictions)+1L]] <- data.frame(fold=f,cost=cost,n_features=size,
          sample_id=validation_ids,truth=as.character(validation_y),score_MI=pred$score_MI,
          raw_decision=pred$raw_decision,raw_positive_class=pred$orientation$positive_raw_decision_class,
          MI_multiplier=pred$orientation$MI_multiplier)
      }
    }
  }
  metrics <- do.call(rbind,metrics)
  predictions <- do.call(rbind,predictions)
  tuning <- do.call(rbind,lapply(costs,function(cost)do.call(rbind,lapply(sizes,function(size){
    a<-metrics$ROC[metrics$cost==cost & metrics$n_features==size]
    if(length(a)!=5L || any(!is.finite(a)))stop('Incomplete CV result')
    data.frame(cost=cost,n_features=size,mean_ROC=mean(a),SD_ROC=stats::sd(a),n_folds=length(a))
  }))))
  # Exact mean-AUC ties: smaller subset first, then lower C, as locked.
  tuning <- tuning[order(-tuning$mean_ROC,tuning$n_features,tuning$cost),]
  rownames(tuning)<-NULL
  best <- tuning[1L,,drop=FALSE]
  final_path <- classical_svm_rfe_path(x,y,cost=best$cost,keep_sizes=best$n_features)
  selected <- colnames(final_path$models[[as.character(best$n_features)]]$SV)
  result <- list(selected_features=selected,bestTune=best,
    cv_results=tuning,cv_fold_metrics=metrics,cv_predictions=predictions,
    cv_paths=paths,fold_audit=fold_audit,final_path=final_path,
    final_model=final_path$models[[as.character(best$n_features)]],
    fold_id=fold_id,seed=as.integer(seed),cost_grid=costs,size_grid=sizes,
    criterion='Maximum mean 5-fold ROC; exact ties: fewer features then smaller C',
    score_orientation='MI-positive decision score derived from e1071 model labels, never by AUC flipping',
    method='Classical linear SVM-RFE; w=t(coefs)%*%SV; one-gene w-squared elimination with reranking after each refit',
    probe_selection_scope=if(is.null(fold_data))'fixed input matrix supplied by caller' else 'caller provided separate training-only probe-choice matrices for each inner fold',
    package_versions=list(e1071=as.character(utils::packageVersion('e1071')),pROC=as.character(utils::packageVersion('pROC'))))
  class(result)<-c('classical_svm_rfe_selection','list')
  result
}
