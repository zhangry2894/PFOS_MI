options(stringsAsFactors=FALSE,width=180,warn=1)
suppressPackageStartupMessages({library(jsonlite);library(pROC);library(digest)})
args<-commandArgs(trailingOnly=TRUE)
base<-normalizePath(args[1],winslash='/',mustWork=TRUE)
qa_file<-file.path(dirname(base),'04_independent_QA','full_pipeline_QA_summary.json')
qa<-fromJSON(qa_file)
stopifnot(isTRUE(qa$accepted_complete_evaluation),qa$n_fold_QA_pass==30L,qa$n_failed_checks==0L,qa$n_review_checks==0L)
od<-file.path(base,'aggregate_results')
if(dir.exists(od))stop('Aggregate output exists; refuse to overwrite')
inp<-readRDS(file.path(base,'inputs.rds'))
variants<-c('overlap38','overlap37');rules<-c('one_SE_style','maximum_AUC')
preds<-locks<-members<-execution<-list();j<-0L
for(v in variants)for(fn in names(inp$partitions)){
 d<-file.path(base,'runs',v,fn);normal<-file.path(d,'COMPLETED.json');cont<-file.path(d,'COMPLETED_CONTINUATION.json')
 stopifnot(file.exists(normal)||file.exists(cont))
 marker<-if(file.exists(cont))cont else normal
 p<-read.csv(file.path(d,'outer_test_predictions.csv'),check.names=FALSE)
 l<-read.csv(file.path(d,'SELECTION_LOCK_BEFORE_OUTER_TEST.csv'),check.names=FALSE,na.strings='NA')
 l<-l[,c('rule','subset_id','genes','n_genes','selection_AUC','AUC_SE','log_loss','Brier','lambda_1se','one_SE_floor','panel_status')]
 m<-read.csv(file.path(d,'selector_membership.csv'),check.names=FALSE)
 part<-inp$partitions[[fn]];testids<-c(part$discovery_test,part$selection_test)
 stopifnot(setequal(p$sample_id,testids),setequal(p$rule,rules),all(table(p$sample_id)==2),all(p$variant==v),all(p$repeat_id==part$repeat_id),all(p$fold==part$fold))
 stopifnot(all(p$truth==inp$metadata$group[match(p$sample_id,inp$metadata$sample_id)]),all(is.finite(p$probability_MI)),all(p$probability_MI>=0&p$probability_MI<=1))
 for(rr in rules)stopifnot(setequal(p$sample_id[p$rule==rr],testids))
 j<-j+1L;preds[[j]]<-p;l$variant<-v;l$repeat_id<-part$repeat_id;l$fold<-part$fold;l$fold_name<-fn;locks[[j]]<-l
 m$variant<-v;m$repeat_id<-part$repeat_id;m$fold<-part$fold;m$fold_name<-fn;members[[j]]<-m
 pool_n<-sum(m$n_algorithms>=2);n_sub<-if(pool_n<2)0 else sum(choose(pool_n,2:min(7,pool_n)))
 execution[[j]]<-data.frame(variant=v,fold_name=fn,mode=if(file.exists(cont))'exact_block_continuation' else 'normal',n_pool=pool_n,n_subsets=n_sub,initial_resource_failure_preserved=file.exists(file.path(d,'FAILED.json')),marker_sha256=digest(file=marker,algo='sha256'),predictions_sha256=digest(file=file.path(d,'outer_test_predictions.csv'),algo='sha256'))
}
pred<-do.call(rbind,preds);lock<-do.call(rbind,locks);member<-do.call(rbind,members);exe<-do.call(rbind,execution)
stopifnot(nrow(exe)==30L,nrow(lock)==60L,nrow(pred)==2L*2L*3L*99L,!anyDuplicated(pred[,c('variant','rule','repeat_id','sample_id')]))
metric<-function(z){
 y<-as.integer(z$truth=='MI');pr<-pmin(pmax(z$probability_MI,1e-8),1-1e-8)
 r<-pROC::roc(factor(z$truth,levels=c('Control','MI')),z$probability_MI,levels=c('Control','MI'),direction='<',quiet=TRUE)
 data.frame(n=nrow(z),n_MI=sum(y),n_Control=sum(!y),AUC=as.numeric(pROC::auc(r)),Brier=mean((pr-y)^2),log_loss=-mean(y*log(pr)+(1-y)*log(1-pr)))
}
repmet<-list();meanmet<-list();meanscores<-list();foldmet<-list();k<-0L;q<-0L;t<-0L
for(v in variants)for(rr in rules)for(cc in c('Discovery','Validation')){
 z<-pred[pred$variant==v&pred$rule==rr&pred$cohort==cc,];expected<-inp$metadata$sample_id[inp$metadata$cohort==cc]
 stopifnot(setequal(z$sample_id,expected),all(table(z$sample_id)==3L))
 for(rep in 1:3){a<-z[z$repeat_id==rep,];stopifnot(nrow(a)==length(expected),!anyDuplicated(a$sample_id));k<-k+1L;repmet[[k]]<-cbind(data.frame(variant=v,rule=rr,cohort=cc,repeat_id=rep),metric(a))}
 a<-aggregate(probability_MI~sample_id+truth,z,mean);a$variant<-v;a$rule<-rr;a$cohort<-cc;q<-q+1L;meanscores[[q]]<-a
 meanmet[[q]]<-cbind(data.frame(variant=v,rule=rr,cohort=cc,interpretation='descriptive_AUC_of_subject_mean_three_repeat_OOF_scores'),metric(a))
 for(rep in 1:3)for(ff in 1:5){a<-z[z$repeat_id==rep&z$fold==ff,];t<-t+1L;foldmet[[t]]<-cbind(data.frame(variant=v,rule=rr,cohort=cc,repeat_id=rep,fold=ff),metric(a))}
}
repmet<-do.call(rbind,repmet);meanmet<-do.call(rbind,meanmet);meanscores<-do.call(rbind,meanscores);foldmet<-do.call(rbind,foldmet)
repdescription<-do.call(rbind,lapply(split(repmet,interaction(repmet$variant,repmet$rule,repmet$cohort,drop=TRUE)),function(x)data.frame(variant=x$variant[1],rule=x$rule[1],cohort=x$cohort[1],dependent_repeats=nrow(x),AUC_mean=mean(x$AUC),AUC_min=min(x$AUC),AUC_max=max(x$AUC),Brier_mean=mean(x$Brier),log_loss_mean=mean(x$log_loss))))
paired<-merge(repmet[repmet$variant=='overlap38',],repmet[repmet$variant=='overlap37',],by=c('rule','cohort','repeat_id'),suffixes=c('_38','_37'))
paired$AUC_difference_38_minus_37<-paired$AUC_38-paired$AUC_37
freq<-list();pfreq<-list();sfreq<-list();q<-0L;t<-0L;k<-0L
for(v in variants)for(rr in rules){
 l<-lock[lock$variant==v&lock$rule==rr,];stopifnot(nrow(l)==15L)
 panels<-strsplit(ifelse(is.na(l$genes),'',l$genes),';',fixed=TRUE)
 for(g in inp$candidate_sets[[v]]){q<-q+1L;freq[[q]]<-data.frame(variant=v,rule=rr,gene=g,selected_fits=sum(vapply(panels,function(a)g%in%a,logical(1))),total_dependent_outer_fits=15L)}
 tb<-table(ifelse(is.na(l$genes)|l$genes=='','INTERCEPT_ONLY',l$genes));t<-t+1L;pfreq[[t]]<-data.frame(variant=v,rule=rr,panel=names(tb),selected_fits=as.integer(tb),total_dependent_outer_fits=15L)
}
for(v in variants)for(g in inp$candidate_sets[[v]]){
 m<-member[member$variant==v&member$gene==g,];stopifnot(nrow(m)==15L)
 k<-k+1L;sfreq[[k]]<-data.frame(variant=v,gene=g,LASSO_fits=sum(m$LASSO),SVM_RFE_fits=sum(m[['SVM-RFE']]),Boruta_fits=sum(m$Boruta),XGBoost_fits=sum(m$XGBoost),vote_pool_fits=sum(m$n_algorithms>=2),total_dependent_outer_fits=15L)
}
freq<-do.call(rbind,freq);freq$selection_fraction<-freq$selected_fits/freq$total_dependent_outer_fits
pfreq<-do.call(rbind,pfreq);pfreq$selection_fraction<-pfreq$selected_fits/pfreq$total_dependent_outer_fits
sfreq<-do.call(rbind,sfreq)
pairlocks<-merge(lock[lock$variant=='overlap38',],lock[lock$variant=='overlap37',],by=c('rule','repeat_id','fold','fold_name'),suffixes=c('_38','_37'))
pairlocks$same_selected_panel<-ifelse(is.na(pairlocks$genes_38),'',pairlocks$genes_38)==ifelse(is.na(pairlocks$genes_37),'',pairlocks$genes_37)
dir.create(od)
out<-list(all_outer_predictions=pred,all_selection_locks=lock,fold_execution_inventory=exe,repeat_OOF_metrics=repmet,repeat_metric_descriptive_summary=repdescription,subject_mean_OOF_scores=meanscores,subject_mean_OOF_descriptive_metrics=meanmet,within_fold_descriptive_metrics=foldmet,paired_repeat_metrics=paired,panel_selection_frequency=pfreq,gene_selection_frequency=freq,selector_and_vote_frequency=sfreq,paired_selected_panels=pairlocks)
for(n in names(out))write.csv(out[[n]],file.path(od,paste0(n,'.csv')),row.names=FALSE)
write_json(list(status='completed_all_30_outer_fits',number_fits=30,number_predictions=nrow(pred),rules=rules,folds=5,repeats=3,independent_subjects=99,independent_subjects_discovery=43,independent_subjects_internal_selection=56,external_data_used=FALSE,resource_continued_fits=sum(exe$mode=='exact_block_continuation'),intercept_only_rule_fits=sum(lock$panel_status=='no_eligible_panel'),total_subsets=sum(exe$n_subsets),notes=c('All repeated folds are dependent; selection frequencies are descriptive.','No unconditional confidence interval derived from CV folds.','OOF pooled score AUC is a descriptive repeat-level quantity, not AUC of one final model.','Original GEO preprocessing and historical analytic choices still condition this evaluation.','No comparison selects a final 38/37 primary definition.')),file.path(od,'summary.json'),pretty=TRUE,auto_unbox=TRUE)
writeLines(capture.output(sessionInfo()),file.path(od,'sessionInfo.txt'))
print(repdescription);print(meanmet);print(pfreq);print(exe)
