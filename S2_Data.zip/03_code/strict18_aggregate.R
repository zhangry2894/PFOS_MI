options(stringsAsFactors=FALSE,width=180,warn=1)
suppressPackageStartupMessages({library(jsonlite);library(pROC);library(glmnet);library(digest)})
args<-commandArgs(trailingOnly=TRUE)
script<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
base<-normalizePath(if(length(args))args[1]else dirname(script),winslash='/',mustWork=TRUE)
report_root<-if(length(args)>=2)args[2]else base;dir.create(report_root,recursive=TRUE,showWarnings=FALSE)
outer<-file.path(base,'outer');od<-file.path(report_root,'aggregate');dir.create(od,showWarnings=FALSE)
inp<-readRDS(file.path(outer,'inputs.rds'));rules<-c('one_SE_style','maximum_AUC')
checks<-list();preds<-list();locks<-list();members<-list();execution<-list()
check<-function(fold,item,pass,detail=''){checks[[length(checks)+1L]]<<-data.frame(fold=fold,check=item,pass=isTRUE(pass),detail=detail);if(!isTRUE(pass))stop(paste(fold,item,detail))}
for(fn in names(inp$partitions)){
 d<-file.path(outer,'runs/strict18',fn);part<-inp$partitions[[fn]]
 check(fn,'completed_marker_exists',file.exists(file.path(d,'COMPLETED.json')))
 marker<-fromJSON(file.path(d,'COMPLETED.json'));p<-read.csv(file.path(d,'outer_test_predictions.csv'),check.names=FALSE);l<-read.csv(file.path(d,'SELECTION_LOCK_BEFORE_OUTER_TEST.csv'),check.names=FALSE)
 m<-read.csv(file.path(d,'selector_membership.csv'),check.names=FALSE);probe<-read.csv(file.path(d,'selected_probe_map.csv'),check.names=FALSE)
 check(fn,'eighteen_real_candidates',marker$n_candidates==18L&&setequal(m$gene,inp$candidate_sets$strict18)&&!any(c('F2','ALPL','PLAU')%in%m$gene))
 ids<-c(part$discovery_test,part$selection_test)
 check(fn,'no_train_test_overlap',!length(intersect(ids,c(part$discovery_train,part$selection_train))))
 check(fn,'all_expected_heldout_predictions',setequal(p$sample_id,ids)&&all(table(p$sample_id)==2L)&&setequal(p$rule,rules)&&all(p$repeat_id==part$repeat_id)&&all(p$fold==part$fold))
 check(fn,'truth_matches_metadata',all(p$truth==inp$metadata$group[match(p$sample_id,inp$metadata$sample_id)]))
 map<-inp$probe_map;map$IQR_outer_discovery_train<-apply(inp$probe_expression[map$PROBEID,part$discovery_train,drop=FALSE],1,IQR)
 map<-map[order(map$SYMBOL,-map$IQR_outer_discovery_train,map$PROBEID),];map<-map[!duplicated(map$SYMBOL),]
 check(fn,'probe_selection_uses_training_only',identical(map$PROBEID,probe$PROBEID)&&identical(map$SYMBOL,probe$SYMBOL)&&max(abs(map$IQR_outer_discovery_train-probe$IQR_outer_discovery_train))<1e-12)
 check(fn,'vote_membership_arithmetic',all(rowSums(m[,c('LASSO','SVM-RFE','Boruta','XGBoost')])==m$n_algorithms))
 pool<-sort(m$gene[m$n_algorithms>=2]);nsub<-if(length(pool)<2)0 else sum(choose(length(pool),2:min(7,length(pool))))
 check(fn,'subsets_complete',marker$n_subsets==nsub)
 if(nsub>0){
  met<-read.csv(file.path(d,'all_subset_selection_metrics.csv'))
  check(fn,'enumerated_all_subsets',nrow(met)==nsub&&!anyDuplicated(met$genes)&&all(vapply(strsplit(met$genes,';',fixed=TRUE),function(g)all(g%in%pool),logical(1))))
  best<-met[order(-met$selection_AUC,met$n_genes,met$log_loss,met$genes),][1,];floor<-best$selection_AUC-best$AUC_SE;el<-met[met$selection_AUC>=floor,];chosen<-el[order(el$n_genes,el$log_loss,-el$selection_AUC,el$genes),][1,]
  check(fn,'internal_choice_recomputed',l$subset_id[l$rule=='one_SE_style']==chosen$subset_id&&l$subset_id[l$rule=='maximum_AUC']==best$subset_id)
 }
 mm<-readRDS(file.path(d,'selected_models.rds'));xt<-t(inp$probe_expression[probe$PROBEID,ids,drop=FALSE]);colnames(xt)<-probe$SYMBOL
 for(rule in rules){mod<-mm[[rule]];native<-if(length(mod$genes))as.numeric(predict(mod$model,newx=xt[,mod$genes,drop=FALSE],s=mod$lambda_1se,type='response'))else rep(mod$prevalence,nrow(xt));q<-p[p$rule==rule,];q<-q[match(ids,q$sample_id),];check(fn,paste0('saved_prediction_replay_',rule),max(abs(native-q$probability_MI))<1e-12)}
 p$fold_name<-fn;l$repeat_id<-part$repeat_id;l$fold<-part$fold;l$fold_name<-fn;m$fold_name<-fn
 preds[[fn]]<-p;locks[[fn]]<-l;members[[fn]]<-m
 execution[[fn]]<-data.frame(fold=fn,n_candidates=marker$n_candidates,n_pool=length(pool),n_subsets=nsub,fallback=marker$fallback,elapsed_seconds=marker$elapsed_seconds)
}
pred<-do.call(rbind,preds);lock<-do.call(rbind,locks);member<-do.call(rbind,members);exe<-do.call(rbind,execution)
check('all','prediction_count',nrow(pred)==594L&&!anyDuplicated(pred[,c('rule','repeat_id','sample_id')]))
metric<-function(z){y<-as.integer(z$truth=='MI');prob<-z$probability_MI;pr<-pmin(pmax(prob,1e-8),1-1e-8);r<-roc(z$truth,prob,levels=c('Control','MI'),direction='<',quiet=TRUE);auc_rank<-(sum(rank(prob,ties.method='average')[y==1])-sum(y)*(sum(y)+1)/2)/(sum(y)*sum(!y));check('aggregate','independent_rank_auc',abs(as.numeric(auc(r))-auc_rank)<1e-12);data.frame(n=length(y),n_MI=sum(y),n_control=sum(!y),AUC=as.numeric(auc(r)),AUC_independent_rank=auc_rank,Brier=mean((prob-y)^2),log_loss=-mean(y*log(pr)+(1-y)*log(1-pr)))}
reps<-list()
for(rule in rules)for(cohort in c('Discovery','Validation'))for(rep in 1:3){z<-pred[pred$rule==rule&pred$cohort==cohort&pred$repeat_id==rep,];check('aggregate',paste(rule,cohort,rep,'one_prediction_per_subject'),setequal(z$sample_id,inp$metadata$sample_id[inp$metadata$cohort==cohort])&&!anyDuplicated(z$sample_id));reps[[length(reps)+1L]]<-cbind(data.frame(rule=rule,cohort=cohort,repeat_id=rep),metric(z))}
reps<-do.call(rbind,reps)
desc<-do.call(rbind,lapply(split(reps,interaction(reps$rule,reps$cohort,drop=TRUE)),function(z)data.frame(rule=z$rule[1],cohort=z$cohort[1],n_dependent_repeats=nrow(z),AUC_mean=mean(z$AUC),AUC_min=min(z$AUC),AUC_max=max(z$AUC),Brier_mean=mean(z$Brier),log_loss_mean=mean(z$log_loss))))
gfs<-list();pfs<-list()
for(rule in rules){l<-lock[lock$rule==rule,];panels<-strsplit(ifelse(is.na(l$genes),'',l$genes),';',fixed=TRUE);gfs[[rule]]<-data.frame(rule=rule,gene=inp$candidate_sets$strict18,selected_fits=vapply(inp$candidate_sets$strict18,function(g)sum(vapply(panels,function(p)g%in%p,logical(1))),integer(1)),total_dependent_fits=15L);tb<-table(l$genes);pfs[[rule]]<-data.frame(rule=rule,panel=names(tb),selected_fits=as.integer(tb),total_dependent_fits=15L)}
gf<-do.call(rbind,gfs);pf<-do.call(rbind,pfs)
outs<-list(all_outer_predictions=pred,all_selection_locks=lock,all_selector_membership=member,fold_execution=exe,repeat_OOF_metrics=reps,repeat_metric_descriptive_summary=desc,gene_selection_frequency=gf,panel_selection_frequency=pf,QA_checks=do.call(rbind,checks))
for(n in names(outs))write.csv(outs[[n]],file.path(od,paste0(n,'.csv')),row.names=FALSE)
fit<-fromJSON(file.path(base,'fit_result.json'));external<-read.csv(file.path(base,'external/external_fixed_score_performance.csv'))
result<-list(status='completed_full_strict18_sensitivity',post_review=TRUE,preregistered=FALSE,n_current_positive_source_candidates=18,strict_score_gt5_and_top10_same_set=TRUE,full_data_selected_panel=fit$selected$genes,full_data_n_vote_pool=length(fit$vote_pool),full_data_n_subsets=fit$n_subsets,internal_selection_AUC=fit$selected$ROC_AUC_internal,full_data_maxAUC_panel=fit$maximum$genes,internal_maxAUC=fit$maximum$ROC_AUC_internal,external_primary=external[external$rule=='one_SE_style',],outer_fits_completed=nrow(exe),outer_fits_expected=15,full_workflow_with_foldwise_probe_selection=TRUE,outer_no_eligible_panel_fallbacks=sum(exe$fallback),outer_total_subsets=sum(exe$n_subsets),OOF_repeat_descriptive_summary=desc,primary_gene_selection_frequency=gf[gf$rule=='one_SE_style',],primary_panel_selection_frequency=pf[pf$rule=='one_SE_style',],QA_checks_passed=all(outs$QA_checks$pass),n_QA_checks=nrow(outs$QA_checks),original_37gene_primary_analysis_changed=FALSE,notes=c('The 18-gene branch is not the archived 19-gene branch. F2 and the original ALPL/PLAU panel are absent.','Same original selector, voting and panel-selection procedure; no external-outcome-based method selection.','Dependent resampling repeats and folds do not justify binomial or independent-repeat confidence intervals.','GSE61144 n=17 yields AUC=1 and degenerate DeLong intervals; this does not imply zero population uncertainty.','Clinical/technical confounding, unmeasured PFOS exposure and historical exploration remain unresolved.','This sensitivity demonstrates disease-definition dependence; it does not validate a unique optimal PFOS-MI panel.'))
write_json(result,file.path(report_root,'strict18_summary.json'),auto_unbox=TRUE,pretty=TRUE,digits=17)
write_json(list(status='passed',n_checks=nrow(outs$QA_checks),complete_fits=nrow(exe),all_checks_passed=all(outs$QA_checks$pass)),file.path(od,'QA_summary.json'),auto_unbox=TRUE,pretty=TRUE)
writeLines(capture.output(sessionInfo()),file.path(od,'R_sessionInfo.txt'))
print(desc);print(pf);cat('ALL_STRICT18_QA_PASSED\n')
