options(stringsAsFactors=FALSE,width=200,warn=1)
suppressPackageStartupMessages({library(caret);library(glmnet);library(pROC);library(randomForest);library(xgboost);library(Boruta);library(jsonlite);library(digest)})
args<-commandArgs(trailingOnly=TRUE); base<-normalizePath(args[1],winslash='/',mustWork=TRUE); variant<-args[2]; foldname<-args[3]
inp<-readRDS(file.path(base,'inputs.rds')); part<-inp$partitions[[foldname]];stopifnot(variant%in%names(inp$candidate_sets),!is.null(part))
od<-file.path(base,'runs',variant,foldname);dir.create(od,recursive=TRUE,showWarnings=FALSE)
if(file.exists(file.path(od,'COMPLETED.json')))stop('Completed fold exists; refusing overwrite')
warnings_log<-character(); start<-Sys.time()
note<-function(...) {cat(format(Sys.time()),..., '\n');flush.console()}
write_status<-function(stage,extra=list())write_json(c(list(variant=variant,fold=foldname,stage=stage,time=as.character(Sys.time())),extra),file.path(od,'status.json'),pretty=TRUE,auto_unbox=TRUE)
worker<-function(){
 md<-inp$metadata; ep<-inp$probe_expression; map<-inp$probe_map
 ids_d<-part$discovery_train;ids_s<-part$selection_train;ids_t<-c(part$discovery_test,part$selection_test)
 stopifnot(!length(intersect(ids_t,c(ids_d,ids_s))),!length(intersect(ids_d,ids_s)))
 genes<-inp$candidate_sets[[variant]]; map<-map[map$SYMBOL%in%genes,]
 map$IQR_outer_discovery_train<-apply(ep[map$PROBEID,ids_d,drop=FALSE],1,IQR)
 map<-map[order(map$SYMBOL,-map$IQR_outer_discovery_train,map$PROBEID),];map<-map[!duplicated(map$SYMBOL),]
 write.csv(map,file.path(od,'selected_probe_map.csv'),row.names=FALSE)
 xx<-t(ep[map$PROBEID,c(ids_d,ids_s),drop=FALSE]);colnames(xx)<-map$SYMBOL
 x_dev<<-as.data.frame(xx[ids_d,,drop=FALSE],check.names=FALSE);xs<-as.matrix(xx[ids_s,,drop=FALSE])
 y<-factor(md$group[match(ids_d,md$sample_id)],levels=c('MI','Control'));ys<-factor(md$group[match(ids_s,md$sample_id)],levels=c('Control','MI'))
 stopifnot(all(is.finite(as.matrix(x_dev))),all(table(y)>=10),all(table(ys)>=10))
 seed<-20261018L+part$repeat_id*10000L+part$fold*1000L
 archived<-file.path(normalizePath(file.path(base,'../..'),winslash='/',mustWork=TRUE),'01_inputs/extracted/S2_Data/consensus_ml/code/02_nested_ml_consensus.R')
 required<-c('make_inner_control','lasso_grid','xgb_grid','svm_grid','fit_xgb_native','predict_xgb_native','fit_one')
 for(ex in parse(archived)) if(is.call(ex)&&identical(as.character(ex[[1]]),'<-')&&is.symbol(ex[[2]])&&as.character(ex[[2]])%in%required)eval(ex,envir=.GlobalEnv)
 rfe_sizes<<-unique(pmin(ncol(x_dev),c(5,10,20,40,80,120)))
 set.seed(seed+10L);lasso_index<-createMultiFolds(y,k=5,times=3)
 full_ctrl<-trainControl(method='repeatedcv',number=5,repeats=3,classProbs=TRUE,summaryFunction=twoClassSummary,savePredictions='final',allowParallel=FALSE,index=lasso_index)
 set.seed(seed+20L);ridge_testfolds<-createFolds(y,k=5,returnTrain=FALSE);foldid<-integer(length(y));for(k in seq_along(ridge_testfolds))foldid[ridge_testfolds[[k]]]<-k
 write.csv(data.frame(sample_id=ids_d,fold=foldid),file.path(od,'ridge_inner_folds.csv'),row.names=FALSE)
 write_json(lapply(lasso_index,function(i)ids_d[i]),file.path(od,'lasso_inner_train_ids.json'),pretty=TRUE)
 write_json(list(discovery_train=ids_d,selection_train=ids_s,discovery_test=part$discovery_test,selection_test=part$selection_test,seed=seed,archived_function_sha256=digest(file=archived,algo='sha256')),file.path(od,'split_and_provenance.json'),pretty=TRUE,auto_unbox=TRUE)
 sets<-list();params<-list()
 for(a in c('LASSO','SVM-RFE','XGBoost')){
  write_status(paste0('fit_',a)); note('START',variant,foldname,a)
  aseed<-seed+c(LASSO=101L,`SVM-RFE`=202L,XGBoost=303L)[[a]]
  fit<-fit_one(a,x_dev,y,aseed,final_control=full_ctrl)
  if(a=='LASSO') {cf<-as.matrix(coef(fit$finalModel,s=fit$bestTune$lambda));sets[[a]]<-sort(setdiff(rownames(cf)[cf[,1]!=0],'(Intercept)'));cv<-fit$results;tune<-fit$bestTune;saveRDS(fit$control$index,file.path(od,'LASSO_cv_index.rds'))}
  if(a=='SVM-RFE') {sets[[a]]<-sort(predictors(fit));cv<-fit$results;tune<-cbind(n_features=length(sets[[a]]),fit$fit$bestTune);saveRDS(fit$control$index,file.path(od,'SVM_RFE_cv_index.rds'))}
  if(a=='XGBoost') {vi<-xgb.importance(model=fit$model);fc<-if('Features'%in%names(vi))'Features' else 'Feature';sets[[a]]<-sort(vi[[fc]][vi$Gain>0]);cv<-fit$cv_results;tune<-fit$bestTune;write.csv(vi,file.path(od,'XGBoost_importance.csv'),row.names=FALSE)}
  safe<-gsub('-','_',a);write.csv(cv,file.path(od,paste0(safe,'_cv.csv')),row.names=FALSE);write.csv(tune,file.path(od,paste0(safe,'_tuning.csv')),row.names=FALSE)
  saveRDS(fit,file.path(od,paste0(safe,'_model.rds')),compress=FALSE)
  params[[a]]<-list(seed=aseed,genes=sets[[a]],tuning=tune);note('SELECTED',a,paste(sets[[a]],collapse=';'));rm(fit);invisible(gc())
 }
 write_status('fit_Boruta');note('START Boruta')
 set.seed(seed+404L);b<-Boruta(x=x_dev,y=factor(as.character(y),levels=c('Control','MI')),maxRuns=500,doTrace=0,holdHistory=TRUE,getImp=getImpRfZ)
 sets$Boruta<-sort(getSelectedAttributes(b,withTentative=FALSE));bs<-attStats(b);bs$gene<-rownames(bs)
 write.csv(bs,file.path(od,'Boruta_statistics.csv'),row.names=FALSE);saveRDS(b,file.path(od,'Boruta_model.rds'),compress=FALSE)
 params$Boruta<-list(seed=seed+404L,maxRuns=500,genes=sets$Boruta)
 membership<-data.frame(gene=genes);for(a in c('LASSO','SVM-RFE','Boruta','XGBoost'))membership[[a]]<-as.integer(genes%in%sets[[a]])
 membership$n_algorithms<-rowSums(membership[,-1]);pool<-sort(membership$gene[membership$n_algorithms>=2]);write.csv(membership,file.path(od,'selector_membership.csv'),row.names=FALSE)
 write_json(params,file.path(od,'selector_parameters.json'),pretty=TRUE,auto_unbox=TRUE)
 ncombs<-if(length(pool)<2)0 else sum(choose(length(pool),2:min(7,length(pool))))
 note('POOL',length(pool),'SUBSETS',ncombs,paste(pool,collapse=';'))
 write_status('subset_enumeration',list(n_pool=length(pool),n_subsets=ncombs))
 if(ncombs>50000)stop('RESOURCE_LIMIT: more than 50000 subsets; no favorable subset substituted')
 y01<-as.integer(y=='MI');ys01<-as.integer(ys=='MI');models_selected<-list();metrics<-list()
 if(ncombs>0){
  combs<-unlist(lapply(2:min(7,length(pool)),function(k)combn(pool,k,simplify=FALSE)),recursive=FALSE)
  bestauc<-NULL;allmodels<-list()
  for(i in seq_along(combs)){
   g<-combs[[i]];sid<-sprintf('S%05d',i)
   f<-cv.glmnet(x=as.matrix(x_dev[,g,drop=FALSE]),y=y01,family='binomial',alpha=0,foldid=foldid,type.measure='deviance',standardize=TRUE,intercept=TRUE)
   prob<-as.numeric(predict(f,newx=xs[,g,drop=FALSE],s='lambda.1se',type='response'));pr<-pmin(pmax(prob,1e-8),1-1e-8)
   r<-roc(ys,pr,levels=c('Control','MI'),direction='<',quiet=TRUE)
   metrics[[i]]<-data.frame(subset_id=sid,genes=paste(g,collapse=';'),n_genes=length(g),selection_AUC=as.numeric(auc(r)),AUC_SE=sqrt(as.numeric(pROC::var(r))),log_loss=-mean(ys01*log(pr)+(1-ys01)*log(1-pr)),Brier=mean((pr-ys01)^2),lambda_1se=f$lambda.1se)
   # Keep compact trained glmnet model only; CV trajectories and lambda are independently reproducible.
   allmodels[[sid]]<-list(genes=g,lambda_1se=f$lambda.1se,model=f$glmnet.fit)
   if(i%%100==0){note('RIDGE',i,'/',ncombs);write_status('subset_enumeration',list(n_pool=length(pool),n_subsets=ncombs,completed_subsets=i))}
  }
  met<-do.call(rbind,metrics);write.csv(met,file.path(od,'all_subset_selection_metrics.csv'),row.names=FALSE)
  best<-met[order(-met$selection_AUC,met$n_genes,met$log_loss,met$genes),][1,]
  floor<-best$selection_AUC-best$AUC_SE;eligible<-met[met$selection_AUC>=floor,]
  chosen<-eligible[order(eligible$n_genes,eligible$log_loss,-eligible$selection_AUC,eligible$genes),][1,]
  lock<-rbind(cbind(rule='one_SE_style',chosen),cbind(rule='maximum_AUC',best));lock$one_SE_floor<-floor;lock$panel_status<-'selected'
  models_selected<-list(one_SE_style=allmodels[[chosen$subset_id]],maximum_AUC=allmodels[[best$subset_id]])
  rm(allmodels);invisible(gc())
 } else {
  lock<-data.frame(rule=c('one_SE_style','maximum_AUC'),subset_id='INTERCEPT_ONLY',genes='',n_genes=0,selection_AUC=.5,AUC_SE=0,log_loss=NA_real_,Brier=NA_real_,lambda_1se=NA_real_,one_SE_floor=NA_real_,panel_status='no_eligible_panel')
  models_selected<-list(one_SE_style=list(genes=character(),prevalence=mean(y01)),maximum_AUC=list(genes=character(),prevalence=mean(y01)))
 }
 # This selection lock is written BEFORE any held-out expression is assembled or labels scored.
 write.csv(lock,file.path(od,'SELECTION_LOCK_BEFORE_OUTER_TEST.csv'),row.names=FALSE)
 saveRDS(models_selected,file.path(od,'selected_models.rds'),compress=FALSE)
 write_status('selection_locked');note('LOCKED',paste(lock$genes,collapse=' | '))
 xt<-t(ep[map$PROBEID,ids_t,drop=FALSE]);colnames(xt)<-map$SYMBOL
 preds<-lapply(names(models_selected),function(rule){
  mod<-models_selected[[rule]];p<-if(length(mod$genes))as.numeric(predict(mod$model,newx=xt[,mod$genes,drop=FALSE],s=mod$lambda_1se,type='response')) else rep(mod$prevalence,nrow(xt))
  data.frame(variant=variant,repeat_id=part$repeat_id,fold=part$fold,rule=rule,sample_id=ids_t,cohort=md$cohort[match(ids_t,md$sample_id)],truth=md$group[match(ids_t,md$sample_id)],probability_MI=p,selected_genes=paste(mod$genes,collapse=';'))
 })
 preds<-do.call(rbind,preds);stopifnot(all(is.finite(preds$probability_MI)),all(preds$probability_MI>=0&preds$probability_MI<=1))
 write.csv(preds,file.path(od,'outer_test_predictions.csv'),row.names=FALSE)
 writeLines(capture.output(sessionInfo()),file.path(od,'sessionInfo.txt'))
 write_json(list(status='completed',variant=variant,fold=foldname,n_candidates=length(genes),n_pool=length(pool),n_subsets=ncombs,elapsed_seconds=as.numeric(difftime(Sys.time(),start,units='secs')),primary_genes=lock$genes[lock$rule=='one_SE_style'],fallback=ncombs==0,external_data_loaded=FALSE),file.path(od,'COMPLETED.json'),pretty=TRUE,auto_unbox=TRUE)
 note('COMPLETE',variant,foldname)
}
status<-tryCatch(withCallingHandlers({worker();'completed'},warning=function(w){warnings_log<<-c(warnings_log,conditionMessage(w))}),error=function(e){write_json(list(status='failed',error=conditionMessage(e),time=as.character(Sys.time())),file.path(od,'FAILED.json'),pretty=TRUE,auto_unbox=TRUE);note('FAILED',conditionMessage(e));'failed'})
writeLines(warnings_log,file.path(od,'warnings.txt'));if(status=='failed')quit(status=1)
