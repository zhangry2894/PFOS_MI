"""Read-only source audit of three frozen external cohorts. No model reselection.

All generated outputs are confined to this script's directory. Public metadata
requests contain GEO accessions only; no manuscript or private data are uploaded.
"""
from pathlib import Path
import csv, json, hashlib, urllib.request, datetime, re, sys, shutil, zipfile
from collections import Counter
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
BASE = Path('H:/NT/xinnei/MI/PFOS/tougao/revise/file1/UPLOAD_READY_FINAL/complete')
ARCHIVE = BASE / '09_additional_experiments_20261018/02_metadata_external'
PRED = BASE / '10_literature_guided_reselection_20261019/external/external_prediction_rows.csv'
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()
sys.stdout.reconfigure(encoding='utf-8')
for sub in ['sources', 'results']:
    (ROOT/sub).mkdir(exist_ok=True)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def writecsv(name, rows, fields=None):
    if fields is None:
        fields = list(dict.fromkeys(k for r in rows for k in r))
    with (ROOT/'results'/name).open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def parse_soft(text):
    samples=[]; current=None; scope=None; series={}
    for line in text.splitlines():
        if line.startswith('^'):
            tag, _, value = line.partition(' = ')
            scope = tag[1:]
            if scope == 'SAMPLE':
                current={'sample_id': value, 'fields': {}}; samples.append(current)
        elif line.startswith('!'):
            key, _, value = line[1:].partition(' = ')
            if scope == 'SAMPLE' and key.startswith('Sample_'):
                current['fields'].setdefault(key, []).append(value)
            elif scope == 'SERIES' and key.startswith('Series_'):
                series.setdefault(key, []).append(value)
    return {'samples':samples, 'series':series}

def characteristics(s):
    ch={}
    for field,values in s['fields'].items():
        if 'characteristics_ch' in field:
            for val in values:
                k,sep,v=val.partition(': ')
                if sep: ch[k.lower().strip()]=v.strip()
    return ch

def join(s,k):
    return ' || '.join(s['fields'].get(k,[]))

def group_of(acc,s):
    c=characteristics(s)
    if acc=='GSE48060':
        t=join(s,'Sample_title').lower()
        return 'Control' if 'normal control' in t else 'MI' if 'patient' in t else 'Unresolved'
    if acc=='GSE61144':
        return {'patients with STEMI (before PCI)':'MI','Non-disease control':'Control'}.get(c.get('subject group'), 'Excluded follow-up')
    if c.get('samples collection')=='on the 1st day of MI (admission)': return 'MI'
    if c.get('hf progression')=='stable CAD': return 'Control'
    return 'Excluded follow-up'

manifest=[]; availability=[]; crosswalk=[]; candidate_fields=[]; supplementary=[]; datasets={}
current_package=BASE/'11_revision_37gene_20261019/01_submission/S2_Data.zip'
with zipfile.ZipFile(current_package) as z:
    candidates=[n for n in z.namelist() if n.endswith('/external_prediction_rows.csv')]
    matches=[n for n in candidates if hashlib.sha256(z.read(n)).hexdigest()==sha(PRED)]
assert matches, 'Frozen prediction file does not exactly match the current submission S2 package'
manifest.append({'source':str(current_package),'kind':'current-package identity verification','matching_member':matches[0],'sha256':sha(PRED),'status':'byte-identical'})
predrows=list(csv.DictReader(PRED.open(encoding='utf-8-sig',newline='')))
predrows=[r for r in predrows if r['model']=='Baseline_ALPL_PLAU']
shutil.copy2(PRED,ROOT/'sources'/'frozen_external_prediction_rows.csv')
manifest.append({'source':str(PRED),'local_file':'sources/frozen_external_prediction_rows.csv','retrieved_utc':NOW,'kind':'frozen prediction input','sha256':sha(PRED)})
old_manifest=json.loads((ARCHIVE/'download_manifest.json').read_text(encoding='utf-8'))
for acc in ['GSE48060','GSE61144','GSE59867']:
    archived_path=ARCHIVE/'metadata'/(acc+'_metadata.json')
    d=json.loads(archived_path.read_text(encoding='utf-8'))
    original=ARCHIVE/'metadata'/(acc+'_metadata_only.soft.txt')
    shutil.copy2(original,ROOT/'sources'/(acc+'_archived_metadata_only.soft.txt'))
    shutil.copy2(archived_path,ROOT/'sources'/(acc+'_archived_metadata.json'))
    orig_record=next(x for x in old_manifest if x['accession']==acc)
    manifest.append({'accession':acc,'source':orig_record['url'],'archived_retrieval_utc':orig_record['accessed_at'],'original_family_sha256':orig_record['sha256'],'source_file':str(original),'local_file':'sources/'+acc+'_archived_metadata_only.soft.txt','retrieved_utc':NOW,'kind':'archived official metadata extract','sha256':sha(original)})
    url=f'https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc={acc}&targ=all&form=text&view=quick'
    fresh=ROOT/'sources'/(acc+'_current_GEO_quick.soft.txt')
    rec={'accession':acc,'source':url,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'current public GEO metadata refresh'}
    try:
        reused=fresh.exists()
        if not fresh.exists():
            req=urllib.request.Request(url,headers={'User-Agent':'ExternalCovariateAudit/1.0'})
            with urllib.request.urlopen(req,timeout=45) as response:
                data=response.read()
            fresh.write_bytes(data)
        if reused:
            rec['retrieved_utc']=datetime.datetime.fromtimestamp(fresh.stat().st_mtime,datetime.timezone.utc).isoformat()
        rec['snapshot_reused']=reused
        text=fresh.read_text(encoding='utf-8',errors='replace')
        freshd=parse_soft(text)
        rec.update(local_file='sources/'+fresh.name,sha256=sha(fresh),bytes=fresh.stat().st_size,n_samples=len(freshd['samples']))
        if len(freshd['samples'])!=len(d['samples']):
            rec['status']='incomplete_response_use_archived_metadata'; rec['expected_samples']=len(d['samples'])
        else:
            rec['status']='complete_sample_inventory'
            af={s['sample_id']:characteristics(s) for s in d['samples']}
            ff={s['sample_id']:characteristics(s) for s in freshd['samples']}
            rec['characteristics_equal_to_archive']=af==ff
            d=freshd
    except Exception as e:
        rec.update(status='refresh_failed_use_archived_metadata',error=repr(e))
    manifest.append(rec); datasets[acc]=d
    p={r['sample_id']:r for r in predrows if r['cohort']==acc}
    assert len(p)==len([r for r in predrows if r['cohort']==acc])
    byid={s['sample_id']:s for s in d['samples']}
    assert set(p)<=set(byid),f'{acc}: missing GSM'
    for s in d['samples']:
        c=characteristics(s)
        for key,vals in s['fields'].items():
            if re.search(r'(^|[^a-z])(age|sex|gender|batch|run)([^a-z]|$)',key.lower()):
                candidate_fields.append({'accession':acc,'sample_id':s['sample_id'],'field':key,'value':' || '.join(vals),'reason':'field-name candidate'})
        for key,value in c.items():
            if re.search(r'(^|[^a-z])(age|sex|gender|batch|run)([^a-z]|$)',key):
                candidate_fields.append({'accession':acc,'sample_id':s['sample_id'],'field':key,'value':value,'reason':'characteristic-name candidate'})
        # Audit free text, but do not infer covariates from title/name or expression.
        for key in ['Sample_description','Sample_title']:
            val=join(s,key)
            if re.search(r'\b(age|sex|gender|batch|female|male|years? old)\b',val,re.I):
                candidate_fields.append({'accession':acc,'sample_id':s['sample_id'],'field':key,'value':val,'reason':'free-text candidate requiring manual validation'})
        group=group_of(acc,s); included=s['sample_id'] in p
        if included: assert p[s['sample_id']]['truth']==group,(acc,s['sample_id'],group)
        age=next((v for k,v in c.items() if k in ['age','age (years)','age:ch1']), '')
        sex=next((v for k,v in c.items() if k in ['sex','gender','sex:ch1','gender:ch1']), '')
        batch=next((v for k,v in c.items() if k in ['batch','technical batch','processing batch','array batch','run id']), '')
        crosswalk.append({'accession':acc,'sample_id':s['sample_id'],'title':join(s,'Sample_title'),'source_subject_id':c.get('subject id',''),'frozen_subject_id':p.get(s['sample_id'],{}).get('subject_id',''),'source_group':group,'included_in_frozen_evaluation':included,'age':age,'sex':sex,'technical_batch':batch,'submission_date':join(s,'Sample_submission_date'),'platform':join(s,'Sample_platform_id'),'linear_score':p.get(s['sample_id'],{}).get('linear_score',''),'mapping_method':'exact GSM; group checked against explicit GEO characteristics/title','covariate_mapping_status':'not available' if not any([age,sex,batch]) else 'requires manual validation'})
    selected=[r for r in crosswalk if r['accession']==acc and r['included_in_frozen_evaluation']]
    expected={'GSE48060':52,'GSE61144':17,'GSE59867':157}[acc]
    assert len(selected)==expected
    for domain in ['age','sex','technical_batch']:
        values=[r[domain] for r in selected]
        nonempty=[v for v in values if v and v.upper() not in ['N/A','NA','NONE','NOT AVAILABLE']]
        availability.append({'accession':acc,'domain':domain,'all_GEO_samples':len(d['samples']),'eligible_n':len(selected),'MI_n':sum(r['source_group']=='MI' for r in selected),'Control_n':sum(r['source_group']=='Control' for r in selected),'n_reliably_linked_values':len(nonempty),'n_missing':len(selected)-len(nonempty),'distinct_values':len(set(nonempty)),'adjustment_estimable':False,'reason':'No GSM-linked '+domain+' in inspected GEO metadata' if not nonempty else 'Manual review required before estimation'})
    print(acc,rec['status'],'eligible',len(selected),'covariates',[(r['domain'],r['n_reliably_linked_values']) for r in availability if r['accession']==acc],flush=True)

# Public primary-paper sources already archived during the preceding evidence audit.
for pmc in ['PMC4115027','PMC4536992','PMC4432772']:
    src=ARCHIVE/'primary_papers'/(pmc+('.html' if pmc=='PMC4115027' else '.xml'))
    shutil.copy2(src,ROOT/'sources'/src.name)
    manifest.append({'source':'https://pmc.ncbi.nlm.nih.gov/articles/'+pmc+'/','source_file':str(src),'local_file':'sources/'+src.name,'retrieved_utc':NOW,'kind':'archived public primary paper','sha256':sha(src)})
    if src.suffix=='.xml':
        tree=ET.parse(src)
        for node in tree.iter():
            if node.tag in ['supplementary-material','media']:
                supplementary.append({'paper':pmc,'element':node.tag,'href':node.attrib.get('{http://www.w3.org/1999/xlink}href',''),'text':' '.join(' '.join(node.itertext()).split())})
        tables=[]
        for table in tree.findall('.//table-wrap'):
            text=' '.join(' '.join(table.itertext()).split())
            if re.search(r'age|sex|gender|characteristics',text,re.I): tables.append(text)
        (ROOT/'sources'/(pmc+'_clinical_table_text.txt')).write_text('\n\n'.join(tables),encoding='utf-8')
    for f in (ARCHIVE/'primary_papers'/(pmc+'_supplementary')).glob('*.extracted.txt'):
        shutil.copy2(f,ROOT/'sources'/f.name)
        manifest.append({'source_file':str(f),'local_file':'sources/'+f.name,'retrieved_utc':NOW,'kind':'archived public supplement text','sha256':sha(f)})

writecsv('sample_covariate_crosswalk.csv',crosswalk)
writecsv('covariate_availability.csv',availability)
writecsv('candidate_covariate_fields.csv',candidate_fields, ['accession','sample_id','field','value','reason'])
writecsv('paper_supplement_inventory.csv',supplementary,['paper','element','href','text'])
writecsv('submission_date_by_group.csv',[{'accession':a,'group':g,'submission_date':dt,'n':n,'interpretation':'administrative upload date, not established technical batch'} for (a,g,dt),n in Counter((r['accession'],r['source_group'],r['submission_date']) for r in crosswalk if r['included_in_frozen_evaluation']).items()])
(ROOT/'source_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
result={'audit_utc':NOW,'cohorts':availability,'prediction_input_matches_current_submission':matches,'n_frozen_evaluation_samples':sum(r['included_in_frozen_evaluation'] for r in crosswalk),'all_frozen_GSMs_mapped_and_group_checked':True,'candidate_covariate_fields_n':len(candidate_fields),'adjusted_models_run':False,'reason':'Current inspected GEO metadata contain no sample-linked age, sex or defensible technical batch. Primary-paper/supplement audit must be consulted for remaining mapping uncertainty. Do not impute group means, infer sex from expression, or use upload date as batch.','scope':'Frozen ALPL/PLAU only. No feature selection, coefficient tuning, score-direction changes, sample exclusions, or new predictive-performance claims.'}
(ROOT/'results'/'audit_result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
