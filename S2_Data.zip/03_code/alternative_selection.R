options(stringsAsFactors=FALSE,width=180,warn=1)
suppressPackageStartupMessages({library(glmnet);library(pROC);library(jsonlite);library(digest)})
script<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
base<-normalizePath(file.path(dirname(script),'..'),winslash='/',mustWork=TRUE)
root<-dirname(base);old<-file.path(root,'09_additional_experiments_20261018/01_full_pipeline_validation')
source(file.path(base,'code/classical_svm_rfe.R'))
inp<-readRDS(file.path(old,'inputs.rds'));md<-inp$metadata;genes<-sort(inp$candidate_sets$overlap37)
stopifnot(length(genes)==36,!('F2'%in%genes),!('CES1'%in%genes))
mode<-commandArgs(trailingOnly=TRUE)[1];if(is.na(mode))mode<-'all'
glmnet.control(fdev=0,devmax=1)
note<-function(...){cat(format(Sys.time()),...,'\n');flush.console()}
write_json(list(protocol_sha256=digest(file=file.path(base,'PROTOCOL_BEFORE_RESULTS.txt'),algo='sha256'),input_sha256=digest(file=file.path(old,'inputs.rds'),algo='sha256'),candidate_genes=genes,external_data_loaded=FALSE,started=as.character(Sys.time())),file.path(base,'analysis_provenance.json'),pretty=TRUE,auto_unbox=TRUE)
choose_map<-function(ids){
 m<-inp$probe_map[inp$probe_map$SYMBOL%in%genes,]
 m$training_IQR<-apply(inp$probe_expression[m$PROBEID,ids,drop=FALSE],1,IQR)
 m<-m[order(m$SYMBOL,-m$training_IQR,m$PROBEID),];m<-m[!duplicated(m$SYMBOL),]
 stopifnot(identical(m$SYMBOL,genes));m
}
matrix_by_map<-function(m,ids){z<-t(inp$probe_expression[m$PROBEID,ids,drop=FALSE]);colnames(z)<-m$SYMBOL;stopifnot(all(is.finite(z)));z}
truth<-function(ids)factor(md$group[match(ids,md$sample_id)],levels=c('Control','MI'))
named_coefs<-function(f,lambda){c<-as.matrix(coef(f,s=lambda));setNames(as.numeric(c[,1]),rownames(c))}
save_coefs<-function(co,od,name){write.csv(data.frame(term=names(co),coefficient=unname(co)),file.path(od,paste0(name,'_coefficients.csv')),row.names=FALSE)}
score_coefs<-function(co,x){g<-setdiff(names(co),'(Intercept)');if(length(g))plogis(co['(Intercept)']+as.numeric(x[,g,drop=FALSE]%*%co[g])) else rep(plogis(co['(Intercept)']),nrow(x))}
auc_metrics<-function(y,p){r<-roc(y,p,levels=c('Control','MI'),direction='<',quiet=TRUE);ci<-as.numeric(ci.auc(r,method='delong'));pp<-pmin(pmax(p,1e-8),1-1e-8);yy<-as.integer(y=='MI');data.frame(n=length(y),MI=sum(yy),Control=sum(yy==0),AUC=as.numeric(auc(r)),CI_low=ci[1],CI_high=ci[3],Brier=mean((p-yy)^2),log_loss=-mean(yy*log(pp)+(1-yy)*log(1-pp)))}

fit_sparse_en<-function(x,y,foldid,fd,od){
 lambdas<-10^seq(1,-4,length.out=201);y01<-as.integer(y=='MI');kvals<-sort(unique(foldid))
 losses<-matrix(NA_real_,length(kvals),length(lambdas));oof<-matrix(NA_real_,length(y),length(lambdas))
 for(k in kvals){tr<-which(foldid!=k);te<-which(foldid==k);d<-fd[[as.character(k)]]
  f<-glmnet(d$train_x,y01[tr],family='binomial',alpha=.5,lambda=lambdas,standardize=TRUE,intercept=TRUE)
  p<-as.matrix(predict(f,newx=d$validation_x,s=lambdas,type='response'));p<-pmin(pmax(p,1e-8),1-1e-8)
  loss<--2*(y01[te]*log(p)+(1-y01[te])*log(1-p));losses[match(k,kvals),]<-colMeans(loss);oof[te,]<-p
 }
 f<-glmnet(x,y01,family='binomial',alpha=.5,lambda=lambdas,standardize=TRUE,intercept=TRUE)
 cf<-as.matrix(coef(f,s=lambdas));ng<-colSums(cf[-1,,drop=FALSE]!=0)
 tab<-data.frame(lambda=lambdas,n_genes=ng,mean_deviance=colMeans(losses),SE=apply(losses,2,sd)/sqrt(length(kvals)))
 feasible<-which(ng<=7);best<-feasible[order(tab$mean_deviance[feasible],-tab$lambda[feasible])][1]
 cutoff<-tab$mean_deviance[best]+tab$SE[best];ok<-feasible[tab$mean_deviance[feasible]<=cutoff];j<-ok[which.max(tab$lambda[ok])]
 tab$feasible_cap7<-ng<=7;tab$within_constrained_1SE<-tab$feasible_cap7&tab$mean_deviance<=cutoff;tab$selected<-seq_len(nrow(tab))==j
 write.csv(tab,file.path(od,'ElasticNet_full_CV_path.csv'),row.names=FALSE)
 write.csv(data.frame(fold=kvals,losses,check.names=FALSE),file.path(od,'ElasticNet_fold_deviance.csv'),row.names=FALSE)
 write.csv(data.frame(sample_id=rownames(x),truth=as.character(y),probability_MI=oof[,j]),file.path(od,'ElasticNet_inner_OOF_at_selected_lambda.csv'),row.names=FALSE)
 co<-cf[,j];co<-co[names(co)=='(Intercept)'|co!=0];gg<-sort(setdiff(names(co),'(Intercept)'))
 stopifnot(length(gg)<=7);save_coefs(co,od,'ElasticNet')
 saveRDS(f,file.path(od,'ElasticNet_fit.rds'))
 list(genes=gg,coefficients=co,alpha=.5,lambda=lambdas[j],constrained_lambda_min=lambdas[best],one_SE_cutoff=cutoff,selection_rule='constrained_min_deviance_then_largest_lambda_within_1SE_cap7')
}
fit_svm_ridge<-function(x,y,foldid,fd,od,seed){
 s<-classical_svm_rfe_select(x=x,y=y,fold_id=foldid,costs=c(.01,.1,1,10),sizes=1:7,seed=seed,fold_data=fd)
 saveRDS(s,file.path(od,'Classical_SVM_RFE_selector.rds'))
 # Interface fields are defined in classical_svm_rfe.R and checked before execution.
 write.csv(s$cv_results,file.path(od,'Classical_SVM_RFE_CV_grid.csv'),row.names=FALSE)
 write.csv(s$cv_fold_metrics,file.path(od,'Classical_SVM_RFE_fold_metrics.csv'),row.names=FALSE)
 write.csv(s$cv_predictions,file.path(od,'Classical_SVM_RFE_inner_predictions.csv'),row.names=FALSE)
 write.csv(s$final_path$path,file.path(od,'Classical_SVM_RFE_final_elimination_path.csv'),row.names=FALSE)
 write.csv(s$final_path$weights,file.path(od,'Classical_SVM_RFE_final_step_weights.csv'),row.names=FALSE)
 gg<-sort(s$selected_features);stopifnot(length(gg)>=1,length(gg)<=7,all(gg%in%genes))
 z<-x[,gg,drop=FALSE];dummy<-ncol(z)==1;if(dummy)z<-cbind(z,`__constant_dummy__`=0)
 f<-cv.glmnet(z,as.integer(y=='MI'),family='binomial',alpha=0,foldid=unname(foldid),type.measure='deviance',standardize=TRUE,intercept=TRUE)
 co<-named_coefs(f,f$lambda.1se);if(dummy){stopifnot(co['__constant_dummy__']==0);co<-co[names(co)!='__constant_dummy__']}
 saveRDS(f,file.path(od,'Classical_SVM_RFE_ridge_fit.rds'));save_coefs(co,od,'Classical_SVM_RFE_ridge')
 write.csv(data.frame(lambda=f$lambda,cvm=f$cvm,cvsd=f$cvsd,lambda_min=f$lambda.min,lambda_1se=f$lambda.1se),file.path(od,'Classical_SVM_RFE_ridge_CV.csv'),row.names=FALSE)
 list(genes=gg,coefficients=co,lambda=f$lambda.1se,lambda_min=f$lambda.min,selector_parameters=s$bestTune,selector_seed=seed,selection_rule='classical_weight_squared_SVM_RFE_inner_max_AUC_then_ridge_lambda_1se')
}
run_one<-function(name,ids,foldid,ids_test,seed,repeat_id=NA_integer_,outer_fold=NA_integer_){
 od<-file.path(base,if(name=='FINAL')'final' else file.path('outer',name));dir.create(od,recursive=TRUE,showWarnings=FALSE)
 if(file.exists(file.path(od,'COMPLETED.json')))stop('Refusing overwrite completed run: ',name)
 stopifnot(!length(intersect(ids,ids_test)),length(ids)==length(foldid),all(!is.na(foldid)))
 names(foldid)<-ids;m<-choose_map(ids);x<-matrix_by_map(m,ids);y<-truth(ids)
 write.csv(m,file.path(od,'selected_probe_map.csv'),row.names=FALSE)
 write.csv(data.frame(sample_id=ids,truth=as.character(y),fold=unname(foldid)),file.path(od,'inner_fold_assignments.csv'),row.names=FALSE)
 fd<-list()
 for(k in sort(unique(foldid))){tr<-ids[foldid!=k];te<-ids[foldid==k];mi<-choose_map(tr);write.csv(mi,file.path(od,paste0('inner_fold',k,'_probe_map.csv')),row.names=FALSE);fd[[as.character(k)]]<-list(train_x=matrix_by_map(mi,tr),validation_x=matrix_by_map(mi,te))}
 write_json(list(name=name,training_ids=ids,test_ids=ids_test,selection_cohort_used_for_fit=FALSE,external_loaded=FALSE,seed=seed),file.path(od,'provenance.json'),pretty=TRUE,auto_unbox=TRUE)
 note('START',name,'ElasticNet');en<-fit_sparse_en(x,y,foldid,fd,od)
 note('START',name,'classical_SVM_RFE');sv<-fit_svm_ridge(x,y,foldid,fd,od,seed)
 models<-list(ElasticNet=en,Classical_SVM_RFE_ridge=sv)
 saveRDS(models,file.path(od,'frozen_models.rds'))
 write_json(models,file.path(od,'MODEL_LOCK_BEFORE_TEST.json'),pretty=TRUE,auto_unbox=TRUE,digits=17)
 if(name=='FINAL')write_json(list(status='locked',models_sha256=digest(file=file.path(od,'frozen_models.rds'),algo='sha256'),probe_map_sha256=digest(file=file.path(od,'selected_probe_map.csv'),algo='sha256'),time=as.character(Sys.time()),external_data_loaded=FALSE),file.path(base,'FINAL_MODELS_LOCKED.json'),pretty=TRUE,auto_unbox=TRUE)
 # Held-out expression and labels are assembled only after all models have been locked.
 xt<-matrix_by_map(m,ids_test);yt<-truth(ids_test);preds<-list();metrics<-list()
 for(nm in names(models)){p<-score_coefs(models[[nm]]$coefficients,xt);stopifnot(length(p)==length(ids_test),all(is.finite(p)))
  preds[[nm]]<-data.frame(run=name,method=nm,repeat_id=repeat_id,fold=outer_fold,sample_id=ids_test,cohort=md$cohort[match(ids_test,md$sample_id)],truth=as.character(yt),probability_MI=p,selected_genes=paste(models[[nm]]$genes,collapse=';'))
  for(cc in unique(preds[[nm]]$cohort)){ii<-preds[[nm]]$cohort==cc;metrics[[paste(nm,cc)]]<-cbind(method=nm,cohort=cc,genes=paste(models[[nm]]$genes,collapse=';'),auc_metrics(yt[ii],p[ii]))}
 }
 write.csv(do.call(rbind,preds),file.path(od,'heldout_predictions.csv'),row.names=FALSE)
 write.csv(do.call(rbind,metrics),file.path(od,'heldout_metrics.csv'),row.names=FALSE)
 write_json(list(status='completed',time=as.character(Sys.time()),selected_genes=lapply(models,`[[`,'genes')),file.path(od,'COMPLETED.json'),pretty=TRUE,auto_unbox=TRUE)
 note('COMPLETE',name,paste(vapply(models,function(z)paste(z$genes,collapse=';'),''),collapse=' | '))
}
if(mode%in%c('final','all')){
 ids<-md$sample_id[md$cohort=='Discovery'];test<-md$sample_id[md$cohort!='Discovery'];stopifnot(length(ids)==43,length(test)==56)
 af<-read.csv(file.path(root,'01_inputs/extracted/S1_Data/compact_panel/results/discovery_fold_assignment.csv'))
 fi<-af$fold[match(ids,af$sample_id)];run_one('FINAL',ids,fi,test,20261019L)
}
if(mode%in%c('outer','all'))for(nm in names(inp$partitions)){
 p<-inp$partitions[[nm]];ids<-p$discovery_train;af<-read.csv(file.path(old,'runs/overlap37',nm,'ridge_inner_folds.csv'));fi<-af$fold[match(ids,af$sample_id)]
 run_one(nm,ids,fi,c(p$discovery_test,p$selection_test),20261019L+p$repeat_id*10000L+p$fold*1000L,p$repeat_id,p$fold)
}
writeLines(capture.output(sessionInfo()),file.path(base,paste0('sessionInfo_',mode,'.txt')))
note('RUN FINISHED',mode)
