options(stringsAsFactors=FALSE,width=200)
suppressPackageStartupMessages({library(jsonlite);library(digest);library(glmnet);library(pROC);library(ggplot2)})
args <- commandArgs(trailingOnly=TRUE)
script_arg <- sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
root <- normalizePath(if(length(args)) args[[1]] else file.path(dirname(script_arg),'..'),winslash='/',mustWork=TRUE)
out <- file.path(root,'03_ml'); s1 <- file.path(root,'01_inputs/extracted/S1_Data'); s2 <- file.path(root,'01_inputs/extracted/S2_Data')
sink(file.path(out,'02_targets_score_and_plot.log'),split=TRUE)
read_csv <- function(p) read.csv(p,check.names=FALSE,stringsAsFactors=FALSE)
truth <- function(x) toupper(as.character(x))=='TRUE'
pf <- read_csv(file.path(s1,'target_inputs/PFOS_target_evidence_and_tiers.csv'))
mi <- read_csv(file.path(s1,'target_inputs/MI_gene_evidence_and_tiers.csv'))
sources <- c('superpred','pharmmapper','swisstargetprediction','stitch','targetnet')
pf$n_sources_recomputed <- rowSums(sapply(sources,function(s)truth(pf[[paste0(s,'_present')]])))
pf$n_strictly_positive_sources <- rowSums(sapply(sources,function(s)truth(pf[[paste0(s,'_present')]]) & !is.na(pf[[paste0(s,'_score')]]) & pf[[paste0(s,'_score')]]>0))
stopifnot(all(pf$n_sources_recomputed==pf$n_sources))
write.csv(pf,file.path(out,'PFOS_source_count_audit_all_genes.csv'),row.names=FALSE)
swiss <- pf[truth(pf$swisstargetprediction_present),]
write.csv(swiss,file.path(out,'SwissTargetPrediction_all_present_records.csv'),row.names=FALSE)
source_summary <- do.call(rbind,lapply(sources,function(s)data.frame(source=s,present=sum(truth(pf[[paste0(s,'_present')]])),positive=sum(truth(pf[[paste0(s,'_present')]]) & pf[[paste0(s,'_score')]]>0,na.rm=TRUE),high_confidence=sum(truth(pf[[paste0(s,'_high_confidence')]])))))
write.csv(source_summary,file.path(out,'PFOS_source_count_summary.csv'),row.names=FALSE)
consensus <- sort(pf$gene[truth(pf$tier_consensus_2plus)])
stopifnot(length(consensus)==74,identical(consensus,sort(pf$gene[pf$n_sources_recomputed>=2])))
positive_consensus <- sort(pf$gene[pf$n_strictly_positive_sources>=2])
write.csv(data.frame(gene=union(consensus,positive_consensus),archived_consensus=union(consensus,positive_consensus)%in%consensus,strict_positive_consensus=union(consensus,positive_consensus)%in%positive_consensus),file.path(out,'PFOS_archived_vs_positive_only_consensus.csv'),row.names=FALSE)
expr <- as.matrix(read_csv(gzfile(file.path(root,'01_inputs/S3_Data.csv.gz')))[,-1])
gene <- read_csv(gzfile(file.path(root,'01_inputs/S3_Data.csv.gz')))[[1]]
rownames(expr)<-gene; storage.mode(expr)<-'double'
extdf <- read_csv(gzfile(file.path(root,'01_inputs/S4_Data.csv.gz'))); ext <- as.matrix(extdf[,-1]);rownames(ext)<-extdf[[1]];storage.mode(ext)<-'double';rm(extdf)
md <- read_csv(file.path(s2,'base_pipeline/processed/GSE66360_sample_metadata.csv'))
me <- read_csv(file.path(s2,'base_pipeline/processed/GSE48060_sample_metadata.csv'))
stopifnot(all(md$sample_id%in%colnames(expr)),all(me$sample_id%in%colnames(ext)))
definitions <- c(original='tier_original_2841',median_plus_omim='tier_genecards_median_plus_omim',score_gt5_plus_omim='tier_genecards_score_gt5_plus_omim',top10pct_plus_omim='tier_genecards_top10pct_plus_omim')
candidate_sets<-list();membership<-list();summaries<-list()
for(v in names(definitions)) {
 disease<-sort(mi$gene[truth(mi[[definitions[[v]]]])]); overlap<-intersect(consensus,disease);measured<-sort(intersect(overlap,intersect(rownames(expr),rownames(ext))))
 candidate_sets[[v]]<-measured
 h<-digest(paste(measured,collapse='\n'),algo='sha256',serialize=FALSE)
 summaries[[v]]<-data.frame(variant=v,disease_genes=length(disease),PFOS_consensus=length(consensus),overlap_genes=length(overlap),measured_genes=length(measured),candidate_sha256=h,ALPL_in_overlap='ALPL'%in%overlap,PLAU_in_overlap='PLAU'%in%overlap,ALPL_measured='ALPL'%in%measured,PLAU_measured='PLAU'%in%measured)
 membership[[v]]<-data.frame(variant=v,gene=consensus,in_disease=consensus%in%disease,in_PFOS_MI_overlap=consensus%in%overlap,measured_both=consensus%in%measured)
 writeLines(overlap,file.path(out,paste0('candidates_',v,'_overlap.txt')))
 writeLines(measured,file.path(out,paste0('candidates_',v,'_measured.txt')))
}
summary<-do.call(rbind,summaries);summary$reuse_representative<-summary$variant[match(summary$candidate_sha256,summary$candidate_sha256)]
write.csv(summary,file.path(out,'disease_threshold_candidate_summary.csv'),row.names=FALSE)
write.csv(do.call(rbind,membership),file.path(out,'disease_threshold_candidate_membership.csv'),row.names=FALSE)
saveRDS(list(candidate_sets=candidate_sets,expr=expr,metadata=md),file.path(out,'sensitivity_inputs_discovery_internal_only.rds'),compress='xz')
cat('CANDIDATE SUMMARY\n');print(summary)
metadata_fields<-do.call(rbind,lapply(list(GSE66360=md,GSE48060=me),function(d)data.frame(field=names(d),n=length(d[[1]]),nonmissing=vapply(d,function(x)sum(!is.na(x)&as.character(x)!=''),integer(1)),unique_values=vapply(d,function(x)length(unique(x[!is.na(x)])),integer(1)),examples=vapply(d,function(x)paste(head(unique(as.character(x)),4),collapse=';'),character(1)))))
metadata_fields$cohort<-sub('\\..*$','',rownames(metadata_fields))
write.csv(metadata_fields,file.path(out,'archived_metadata_field_inventory.csv'),row.names=FALSE)
conf<-do.call(rbind,lapply(names(list(GSE66360=md,GSE48060=me)),function(cohort){d<-list(GSE66360=md,GSE48060=me)[[cohort]];data.frame(cohort=cohort,domain=c('age','sex','smoking','diabetes','medications','technical_batch','recurrence_status'),present_in_archived_metadata=vapply(c('age','sex|gender','smok','diabet','medicat|treatment|statin','batch|scan_date|array_date|plate','recurrence'),function(pat)any(grepl(pat,names(d),ignore.case=TRUE)),logical(1)))}))
write.csv(conf,file.path(out,'archived_metadata_confounder_availability.csv'),row.names=FALSE)
model<-readRDS(file.path(out,'locked_ALPL_PLAU_model_readonly_copy.rds')); sid<-fromJSON(file.path(out,'locked_model_identity.json'))$subset_id
stored<-read_csv(file.path(s1,'compact_panel/results/all_120_subset_predictions.csv'));stored<-stored[stored$subset_id==sid,]
checks<-list();preds<-list()
for(cohort in c('GSE66360_predefined_validation','GSE48060_external')) {
 d<-stored[stored$cohort==cohort,];mat<-if(cohort=='GSE48060_external')ext else expr
 x<-t(mat[model$genes,d$sample_id,drop=FALSE]); p<-as.numeric(predict(model$cvfit,newx=x,s='lambda.1se',type='response'))
 diff<-p-d$probability_MI
 rocobj<-roc(d$truth,p,levels=c('Control','MI'),direction='<',quiet=TRUE);ci<-as.numeric(ci.auc(rocobj))
 checks[[cohort]]<-data.frame(cohort=cohort,n=nrow(d),max_abs_prediction_difference=max(abs(diff)),tolerance=1e-12,pass=max(abs(diff))<1e-12,AUC=as.numeric(auc(rocobj)),CI_lower=ci[1],CI_upper=ci[3])
 preds[[cohort]]<-data.frame(cohort=cohort,sample_id=d$sample_id,truth=d$truth,archived_probability=d$probability_MI,recomputed_probability=p,difference=diff)
}
write.csv(do.call(rbind,checks),file.path(out,'locked_prediction_reproduction_checks.csv'),row.names=FALSE)
write.csv(do.call(rbind,preds),file.path(out,'locked_predictions_recomputed.csv'),row.names=FALSE)
coefmat<-as.matrix(coef(model$cvfit,s='lambda.1se'))
write.csv(data.frame(term=rownames(coefmat),coefficient=coefmat[,1],lambda=model$lambda_1se),file.path(out,'locked_ALPL_PLAU_coefficients.csv'),row.names=FALSE)
cat('LOCKED PREDICTION CHECK\n');print(do.call(rbind,checks))
cv<-read_csv(file.path(out,'lasso_final37_cv_results.csv'));lam<-read_csv(file.path(out,'lasso_final37_selected_lambda.csv'))$lambda
stopifnot(all(is.finite(cv$lambda)),all(cv$lambda>0))
cv$selected<-abs(cv$lambda-lam)<1e-12;cv$n_resamples<-15L
write.csv(cv,file.path(out,'S3_Fig_source_lasso_lambda_cv.csv'),row.names=FALSE)
p<-ggplot(cv,aes(lambda,ROC))+geom_errorbar(aes(ymin=ROC-ROCSD,ymax=ROC+ROCSD),width=0.055,linewidth=.3,color='#8798A4')+geom_line(linewidth=.55,color='#276185')+geom_point(size=1.7,color='#276185')+geom_vline(xintercept=lam,linetype='dashed',linewidth=.45,color='#C4662B')+geom_point(data=cv[cv$selected,],size=2.6,color='#C4662B')+scale_x_log10(breaks=c(1e-4,1e-3,1e-2,1e-1,1),labels=c('0.0001','0.001','0.01','0.1','1'))+labs(x=expression(lambda~'(log scale)'),y='Mean cross-validated ROC AUC',tag='A',subtitle=sprintf('Selected lambda = %.8f; error bars: resample SD',lam))+theme_classic(base_size=9,base_family='Arial')+theme(plot.tag=element_text(face='bold',size=12),plot.subtitle=element_text(size=8),axis.text=element_text(size=8),axis.line=element_line(linewidth=.35),plot.margin=margin(8,10,6,8))
base<-file.path(out,'S3_Fig');w<-180/25.4;h<-105/25.4
svglite::svglite(paste0(base,'.svg'),width=w,height=h);print(p);dev.off()
grDevices::cairo_pdf(paste0(base,'.pdf'),width=w,height=h,family='Arial');print(p);dev.off()
ragg::agg_tiff(paste0(base,'.tif'),width=w,height=h,units='in',res=600,compression='lzw');print(p);dev.off()
ragg::agg_jpeg(paste0(base,'.jpg'),width=w,height=h,units='in',res=300,quality=95);print(p);dev.off()
ragg::agg_png(paste0(base,'_preview.png'),width=w,height=h,units='in',res=300);print(p);dev.off()
writeLines(c('S3 Figure. Cross-validation tuning curve of the final discovery-cohort LASSO selector.',
'Twenty candidate lambda values (alpha = 1) were evaluated by repeated five-fold cross-validation (three repeats) in 43 GSE66360 discovery samples using 37 candidates. Points show mean ROC AUC and error bars show SD across 15 resamples, not confidence intervals. The dashed line marks the lambda retained in the archived caret bestTune (0.1438449888). The two highest means were tied; the archived choice is preserved, not reselected. This tuning curve is not an unbiased evaluation of the later voting and subset-selection workflow.',
'No model was retrained to generate this plot. Source: saved final_models_discovery_trained.rds, LASSO$results and LASSO$bestTune.'),file.path(out,'S3_Fig_legend.txt'))
write_json(list(n_archived_PFOS_consensus=length(consensus),n_strictly_positive_PFOS_consensus=length(positive_consensus),changed_genes=setdiff(consensus,positive_consensus),swiss_present=swiss$gene,swiss_scores=swiss$swisstargetprediction_score,primary_rule_unchanged=TRUE,locked_predictions_verified=all(do.call(rbind,checks)$pass),lasso_lambda=lam,lasso_mean_ties=cv$lambda[abs(cv$ROC-max(cv$ROC))<1e-12]),file.path(out,'short_analysis_summary.json'),pretty=TRUE,auto_unbox=TRUE)
cat('Completed short audits and actual saved-model LASSO curve.\n');sink()
