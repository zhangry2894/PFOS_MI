suppressPackageStartupMessages({library(clusterProfiler);library(org.Hs.eg.db);library(AnnotationDbi)})
args <- commandArgs(trailingOnly=TRUE)
script_file <- sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
root <- normalizePath(if(length(args))args[1] else file.path(dirname(script_file),'..'),winslash='/',mustWork=TRUE)
src <- file.path(root,'01_inputs/extracted/S1_Data/results')
out <- file.path(root,'05_figures/positive_support_enrichment')
dir.create(out,recursive=TRUE,showWarnings=FALSE)
writeLines(c('Post-review sensitivity amendment recorded before execution, 2026-10-16.','Reason: the archived >=2-source occurrence rule counted a zero-score SwissTargetPrediction F2 record. A strictly-positive-source rule excludes F2.','Freeze: retain primary archived38 result with explicit source-occurrence label; recompute enrichment of original38 and positive-support37 using the same ontology parameters and retained KEGG map. No selection based on FDR or pathways.','Report both results; this does not prove pathway direction or PFOS effects.'),file.path(out,'PLAN_BEFORE_ANALYSIS.txt'))
mapping<-read.csv(file.path(src,'PFOS_MI_38_gene_symbol_entrez_mapping.csv'),colClasses='character')
stopifnot(length(unique(mapping$SYMBOL))==38,'F2'%in%mapping$SYMBOL)
t2g<-read.csv(file.path(src,'KEGG_LEGACY_term2gene_snapshot.csv'),colClasses='character')
t2n<-read.csv(file.path(src,'KEGG_LEGACY_term2name_snapshot.csv'),colClasses='character')
rows<-list()
for(rule in c('archived_source_occurrence_38','positive_source_support_37')) {
 m<-if(rule=='archived_source_occurrence_38') mapping else subset(mapping,SYMBOL!='F2')
 genes<-unique(m$ENTREZID)
 write.csv(m,file.path(out,paste0(rule,'_input.csv')),row.names=FALSE)
 for(ont in c('BP','MF','CC','KEGG')) {
   if(ont=='KEGG') {
     res<-enricher(genes,universe=unique(t2g$gene),TERM2GENE=t2g,TERM2NAME=t2n,pAdjustMethod='BH',pvalueCutoff=1,qvalueCutoff=1,minGSSize=10,maxGSSize=500)
     res<-setReadable(res,OrgDb=org.Hs.eg.db,keyType='ENTREZID')
   } else {
     res<-enrichGO(genes,universe=keys(org.Hs.eg.db,keytype='ENTREZID'),OrgDb=org.Hs.eg.db,keyType='ENTREZID',ont=ont,pAdjustMethod='BH',pvalueCutoff=1,qvalueCutoff=1,minGSSize=10,maxGSSize=500,readable=TRUE)
   }
   dd<-as.data.frame(res)
   write.csv(dd,file.path(out,paste0(rule,'_',ont,'_all.csv')),row.names=FALSE)
   pathway<-dd[dd$ID=='KEGG_COMPLEMENT_AND_COAGULATION_CASCADES',,drop=FALSE]
   rows[[length(rows)+1]]<-data.frame(rule=rule,n_input_symbols=length(unique(m$SYMBOL)),ontology=ont,tested_terms=nrow(dd),significant_BH_005=sum(dd$p.adjust<.05),complement_coagulation_FDR=if(nrow(pathway))pathway$p.adjust else NA,complement_coagulation_genes=if(nrow(pathway))pathway$geneID else NA)
 }
}
summary<-do.call(rbind,rows)
write.csv(summary,file.path(out,'summary.csv'),row.names=FALSE)
print(summary)
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo.txt'))
