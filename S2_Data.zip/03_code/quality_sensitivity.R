## Post hoc descriptive sensitivity only. No fitting, tuning or selection.
options(stringsAsFactors=FALSE)
suppressPackageStartupMessages({library(glmnet);library(pROC);library(jsonlite);library(digest)})
args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))normalizePath(args[1],winslash='/')else dirname(normalizePath(sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),winslash='/'))
complete<-normalizePath(file.path(root,'../../..'),winslash='/')
pred_path<-file.path(complete,'03_ml/locked_predictions_recomputed.csv')
expr_path<-file.path(complete,'03_ml/sensitivity_inputs_discovery_internal_only.rds')
cross_path<-file.path(root,'../metadata/GSE66360_author_repository_QC_crosswalk.csv')
model_path<-file.path(root,'../frozen_model/locked_ALPL_PLAU_model_readonly_copy.rds')
snapshot_path<-file.path(root,'fixed_QC_input_snapshot.rds')
if(file.exists(snapshot_path)) {
  input<-readRDS(snapshot_path)
} else {
  allp<-read.csv(pred_path,check.names=FALSE)
  p<-allp[allp$cohort=='GSE66360_predefined_validation',]
  x<-readRDS(expr_path)
  cross<-read.csv(cross_path,check.names=FALSE,fileEncoding='UTF-8-BOM')
  input<-list(predictions=p,expression=x$expr[c('ALPL','PLAU'),p$sample_id,drop=FALSE],metadata=x$metadata[match(p$sample_id,x$metadata$sample_id),],crosswalk=cross,model=readRDS(model_path))
  saveRDS(input,snapshot_path,compress='xz')
}
p<-input$predictions;x<-input$expression;m<-input$metadata;cross<-input$crosswalk
stopifnot(nrow(p)==56L,!anyDuplicated(p$sample_id),identical(colnames(x),p$sample_id),identical(m$sample_id,p$sample_id),all(is.finite(x)))
stopifnot(identical(p$truth,m$group),all(m$cohort=='Validation'))
fit<-if(inherits(input$model,'cv.glmnet'))input$model else input$model$cvfit
co<-as.matrix(coef(fit,s='lambda.1se'))[,1]
expected<-c('(Intercept)'=-2.75365860826474673,ALPL=.29409821773437633,PLAU=.19254761259727726)
stopifnot(max(abs(co[names(expected)]-expected))<1e-12,abs(fit$lambda.1se-.42537840661909015)<1e-12)
linear<-drop(co['(Intercept)']+t(x)%*%co[c('ALPL','PLAU')])
prob<-plogis(linear)
prediction_difference<-max(abs(prob-p$archived_probability))
stopifnot(prediction_difference<1e-12,max(abs(drop(predict(fit,newx=t(x),s='lambda.1se',type='link'))-linear))<1e-12)
flagged<-cross[trimws(cross$repository_cohort)=='DISCARDED (LOW SN)',]
stopifnot(nrow(flagged)==18L,!anyDuplicated(flagged$sample_id),all(flagged$sample_id%in%p$sample_id),all(flagged$geo_cohort=='VALIDATION'))
c<-cross[match(p$sample_id,cross$sample_id),]
stopifnot(!anyNA(c$sample_id))
geo_group<-ifelse(c$geo_disease=='Control','Control',ifelse(c$geo_disease=='Myocardial Infarction','MI',NA_character_))
stopifnot(identical(geo_group,p$truth))
d<-data.frame(sample_id=p$sample_id,title=m$title,group=p$truth,ALPL=as.numeric(x['ALPL',]),PLAU=as.numeric(x['PLAU',]),archived_fixed_model_score=p$archived_probability,verified_linear_score=linear,excluded_LOW_SN=p$sample_id%in%flagged$sample_id,original_array_ID=c$source_array_id,repository_cohort=c$repository_cohort,exclusion_source='Author TorkamaniLab/CEC figures/microarray_samples.xls; ArrayID-to-GSM crosswalk; not the paper8 PCA list')
stopifnot(identical(as.integer(table(factor(d$group,levels=c('Control','MI')))),c(28L,28L)),identical(as.integer(table(factor(d$group[!d$excluded_LOW_SN],levels=c('Control','MI')))),c(20L,18L)))
write.csv(d,file.path(root,'all56_predictions_expression_and_QC_flags.csv'),row.names=FALSE)
write.csv(d[d$excluded_LOW_SN,],file.path(root,'exact18_LOW_SN_exclusions.csv'),row.names=FALSE)
auc_rows<-list();means<-list();effects<-list();rocs<-list()
for (label in c('Original_selection56','Retained_after_author_LOW_SN_exclusion38')) {
  z<-if(label=='Original_selection56')d else d[!d$excluded_LOW_SN,]
  r<-pROC::roc(z$group,z$archived_fixed_model_score,levels=c('Control','MI'),direction='<',quiet=TRUE)
  ci<-as.numeric(pROC::ci.auc(r,method='delong',conf.level=.95))
  r2<-pROC::roc(z$group,z$verified_linear_score,levels=c('Control','MI'),direction='<',quiet=TRUE)
  stopifnot(abs(as.numeric(pROC::auc(r))-as.numeric(pROC::auc(r2)))<1e-14)
  auc_rows[[label]]<-data.frame(analysis=label,n=nrow(z),n_MI=sum(z$group=='MI'),n_Control=sum(z$group=='Control'),AUC=as.numeric(pROC::auc(r)),CI95_lower=ci[1],CI95_upper=ci[3],CI_method='DeLong',positive_class='MI',direction='<')
  rocs[[label]]<-r
  for(gene in c('ALPL','PLAU')) {
    for(group in c('Control','MI')) {
      v<-z[z$group==group,gene]
      means[[paste(label,gene,group)]]<-data.frame(analysis=label,gene=gene,group=group,n=length(v),mean_log2=mean(v),SD_log2=sd(v),median_log2=median(v),Q1_log2=unname(quantile(v,.25)),Q3_log2=unname(quantile(v,.75)))
    }
    effects[[paste(label,gene)]]<-data.frame(analysis=label,gene=gene,mean_difference_log2FC_MI_minus_control=mean(z[z$group=='MI',gene])-mean(z[z$group=='Control',gene]),scope='Descriptive only; no new P values or FDR claims')
  }
}
auc_df<-do.call(rbind,auc_rows);rownames(auc_df)<-NULL
mean_df<-do.call(rbind,means);rownames(mean_df)<-NULL
effect_df<-do.call(rbind,effects);rownames(effect_df)<-NULL
write.csv(auc_df,file.path(root,'QC_fixed_score_AUC_comparison.csv'),row.names=FALSE)
write.csv(mean_df,file.path(root,'ALPL_PLAU_expression_group_descriptives.csv'),row.names=FALSE)
write.csv(effect_df,file.path(root,'ALPL_PLAU_mean_differences.csv'),row.names=FALSE)
saveRDS(rocs,file.path(root,'QC_ROC_objects.rds'))
source_paths<-c(pred_path,expr_path,cross_path,model_path)
sources<-data.frame(path=source_paths,sha256=vapply(source_paths,function(p)digest::digest(file=p,algo='sha256'),''))
write.csv(sources,file.path(root,'source_SHA256.csv'),row.names=FALSE)
sink(file.path(root,'R_sessionInfo.txt'));print(sessionInfo());sink()
summary<-list(protocol='PROTOCOL_QC_POSTHOC.txt',run_UTC=format(Sys.time(),tz='UTC',usetz=TRUE),analysis_type='Post hoc QC sensitivity within the same internal combination-selection cohort',n_excluded=18,excluded_MI=10,excluded_Control=8,model_refit=FALSE,feature_or_direction_change=FALSE,archived_probability_reproduction_max_absolute_difference=prediction_difference,coefficients=as.list(co),lambda_1se=fit$lambda.1se,AUC_results=auc_df,descriptive_AUC_change=auc_df$AUC[2]-auc_df$AUC[1],gene_mean_differences=effect_df,warning='Not new independent or external validation. Does not remove prior panel-selection optimism. The author LOW SN18 labels are not the paper8 PCA exclusions. Raw SN values and exact paper8 GSM identities remain unavailable. All original results remain unchanged.')
jsonlite::write_json(summary,file.path(root,'QC_sensitivity_summary.json'),pretty=TRUE,auto_unbox=TRUE,digits=16)
print(auc_df);print(effect_df);cat('PASS: fixed score reproduced with max difference',prediction_difference,'; no fitting performed.\n')
