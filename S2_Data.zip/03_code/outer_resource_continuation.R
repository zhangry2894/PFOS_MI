options(stringsAsFactors=FALSE,width=200,warn=1,digits=17)
suppressPackageStartupMessages({library(glmnet);library(pROC);library(jsonlite);library(digest);library(data.table)})
a<-commandArgs(trailingOnly=TRUE);base<-normalizePath(a[1],winslash='/',mustWork=TRUE);variant<-a[2];fn<-a[3];mode<-a[4]
od<-file.path(base,'runs',variant,fn);cd<-file.path(od,'resource_continuation');dir.create(cd,recursive=TRUE,showWarnings=FALSE)
metric<-function(y,p){p<-pmin(pmax(p,1e-8),1-1e-8);r<-roc(y,p,levels=c('Control','MI'),direction='<',quiet=TRUE);yy<-as.integer(y=='MI');c(selection_AUC=as.numeric(auc(r)),AUC_SE=sqrt(as.numeric(pROC::var(r))),log_loss=-mean(yy*log(p)+(1-yy)*log(1-p)),Brier=mean((p-yy)^2))}
if(mode=='prepare'){
 fail<-fromJSON(file.path(od,'FAILED.json'));stopifnot(grepl('RESOURCE_LIMIT',fail$error))
 inp<-readRDS(file.path(base,'inputs.rds'));part<-inp$partitions[[fn]];md<-inp$metadata
 mp<-read.csv(file.path(od,'selected_probe_map.csv'));mem<-read.csv(file.path(od,'selector_membership.csv'),check.names=FALSE)
 pool<-sort(mem$gene[mem$n_algorithms>=2]);ncs<-sapply(2:min(7,length(pool)),function(k)choose(length(pool),k));total<-sum(ncs)
 x<-t(inp$probe_expression[mp$PROBEID,part$discovery_train,drop=FALSE]);xs<-t(inp$probe_expression[mp$PROBEID,part$selection_train,drop=FALSE]);colnames(x)<-colnames(xs)<-mp$SYMBOL
 folds<-read.csv(file.path(od,'ridge_inner_folds.csv'));fid<-folds$fold[match(rownames(x),folds$sample_id)];stopifnot(!anyNA(fid))
 z<-list(x=x,xs=xs,y=factor(md$group[match(rownames(x),md$sample_id)],levels=c('Control','MI')),ys=factor(md$group[match(rownames(xs),md$sample_id)],levels=c('Control','MI')),foldid=fid,pool=pool,counts=ncs,total=total)
 saveRDS(z,file.path(cd,'training_only_inputs.rds'),compress=FALSE)
 starts<-seq(1,total,by=10000);chunks<-data.frame(chunk_id=seq_along(starts),start=starts,end=pmin(starts+9999,total))
 write.csv(chunks,file.path(cd,'chunks.csv'),row.names=FALSE)
 write_json(list(variant=variant,fold=fn,n_pool=length(pool),n_subsets=total,n_chunks=nrow(chunks),training_only_sha256=digest(file=file.path(cd,'training_only_inputs.rds'),algo='sha256'),selected_probe_map_sha256=digest(file=file.path(od,'selected_probe_map.csv'),algo='sha256'),membership_sha256=digest(file=file.path(od,'selector_membership.csv'),algo='sha256'),ridge_folds_sha256=digest(file=file.path(od,'ridge_inner_folds.csv'),algo='sha256')),file.path(cd,'INPUT_LOCK.json'),pretty=TRUE,auto_unbox=TRUE)
 cat('PREPARED',variant,fn,total,nrow(chunks),'\n')
} else if(mode=='chunk'){
 ci<-as.integer(a[5]);chunks<-read.csv(file.path(cd,'chunks.csv'));chunk<-chunks[chunks$chunk_id==ci,];stopifnot(nrow(chunk)==1)
 of<-file.path(cd,sprintf('chunk_%04d.rds',ci));if(file.exists(of))stop('Existing chunk preserved; no overwrite')
 z<-readRDS(file.path(cd,'training_only_inputs.rds'));rows<-list();counter<-0L;offset<-0L;t0<-Sys.time();warns<-character()
 status<-tryCatch(withCallingHandlers({
  for(k in 2:min(7,length(z$pool))){
   nk<-choose(length(z$pool),k);lo<-max(1,chunk$start-offset);hi<-min(nk,chunk$end-offset)
   if(lo<=hi){
    cmb<-combn(z$pool,k)
    for(j in seq(lo,hi)){
     idx<-offset+j;g<-cmb[,j];f<-cv.glmnet(x=z$x[,g,drop=FALSE],y=as.integer(z$y=='MI'),family='binomial',alpha=0,foldid=z$foldid,type.measure='deviance',standardize=TRUE,intercept=TRUE,parallel=FALSE)
     stopifnot(all(is.finite(f$cvm)),all(is.finite(f$cvsd)),all(is.finite(f$lambda)))
     p<-as.numeric(predict(f,newx=z$xs[,g,drop=FALSE],s='lambda.1se',type='response'));stopifnot(all(is.finite(p)))
     m<-metric(z$ys,p);stopifnot(all(is.finite(m)),is.finite(f$lambda.1se))
     counter<-counter+1L;rows[[counter]]<-data.frame(global_index=idx,subset_id=sprintf('S%05d',idx),genes=paste(g,collapse=';'),n_genes=k,selection_AUC=m[1],AUC_SE=m[2],log_loss=m[3],Brier=m[4],lambda_1se=f$lambda.1se,row.names=NULL)
     if(counter%%500==0){cat(format(Sys.time()),'CHUNK',ci,counter,'/',chunk$end-chunk$start+1,'\n');flush.console()}
    };rm(cmb);invisible(gc())
   };offset<-offset+nk
  }
  stopifnot(!any(grepl('model fit failed|missing values|nonfinite|convergence.*not reached|convergence.*failed',warns,ignore.case=TRUE)))
  ans<-do.call(rbind,rows);stopifnot(nrow(ans)==chunk$end-chunk$start+1,all(ans$global_index==seq(chunk$start,chunk$end)))
  saveRDS(ans,of,compress=FALSE);write.csv(ans,sub('rds$','csv',of),row.names=FALSE)
  write_json(list(status='completed',chunk=ci,n=nrow(ans),elapsed_seconds=as.numeric(difftime(Sys.time(),t0,units='secs')),rds_sha256=digest(file=of,algo='sha256')),sub('rds$','json',of),pretty=TRUE,auto_unbox=TRUE);'completed'
 },warning=function(w){warns<<-c(warns,conditionMessage(w))}),error=function(e){write_json(list(status='failed',error=conditionMessage(e)),file.path(cd,sprintf('chunk_%04d_FAILED.json',ci)),pretty=TRUE,auto_unbox=TRUE);cat('ERROR',conditionMessage(e),'\n');'failed'})
 writeLines(warns,file.path(cd,sprintf('chunk_%04d_warnings.txt',ci)));if(status=='failed')quit(status=1)
} else if(mode=='finalize'){
 z<-readRDS(file.path(cd,'training_only_inputs.rds'));chunks<-read.csv(file.path(cd,'chunks.csv'))
 files<-file.path(cd,sprintf('chunk_%04d.rds',chunks$chunk_id));stopifnot(all(file.exists(files)))
 stopifnot(!length(list.files(cd,pattern='chunk_[0-9]+_FAILED.json$')))
 blocks<-lapply(seq_len(nrow(chunks)),function(i){
  jf<-sub('rds$','json',files[i]);stopifnot(file.exists(jf));j<-fromJSON(jf)
  stopifnot(identical(j$status,'completed'),identical(j$rds_sha256,digest(file=files[i],algo='sha256')))
  w<-readLines(file.path(cd,sprintf('chunk_%04d_warnings.txt',chunks$chunk_id[i])),warn=FALSE)
  stopifnot(!any(grepl('model fit failed|missing values|nonfinite|convergence.*not reached|convergence.*failed',w,ignore.case=TRUE)))
  b<-readRDS(files[i]);stopifnot(nrow(b)==chunks$end[i]-chunks$start[i]+1,all(b$global_index==seq(chunks$start[i],chunks$end[i])))
  b
 });met<-rbindlist(blocks);rm(blocks);invisible(gc());stopifnot(nrow(met)==z$total,!anyDuplicated(met$global_index),!anyDuplicated(met$genes),all(sort(met$global_index)==seq_len(z$total)))
 stopifnot(all(is.finite(as.matrix(met[,.(selection_AUC,AUC_SE,log_loss,Brier,lambda_1se)]))))
 setorderv(met,c('selection_AUC','n_genes','log_loss','genes'),c(-1,1,1,1));best<-met[1];floor<-best$selection_AUC-best$AUC_SE
 eligible<-met[selection_AUC>=floor];setorderv(eligible,c('n_genes','log_loss','selection_AUC','genes'),c(1,1,-1,1));chosen<-eligible[1]
 lock<-rbind(cbind(rule='one_SE_style',as.data.frame(chosen)),cbind(rule='maximum_AUC',as.data.frame(best)));lock$one_SE_floor<-floor;lock$panel_status<-'selected'
 write.csv(lock,file.path(od,'SELECTION_LOCK_BEFORE_OUTER_TEST.csv'),row.names=FALSE)
 mods<-list();checks<-list()
 for(rule in lock$rule){
  row<-lock[lock$rule==rule,];g<-strsplit(row$genes,';',fixed=TRUE)[[1]]
  f<-cv.glmnet(x=z$x[,g,drop=FALSE],y=as.integer(z$y=='MI'),family='binomial',alpha=0,foldid=z$foldid,type.measure='deviance',standardize=TRUE,intercept=TRUE,parallel=FALSE)
  p<-as.numeric(predict(f,newx=z$xs[,g,drop=FALSE],s='lambda.1se',type='response'));mm<-metric(z$ys,p)
  old<-as.numeric(row[,c('selection_AUC','AUC_SE','log_loss','Brier','lambda_1se')]);new<-c(mm,f$lambda.1se);delta<-max(abs(old-new));stopifnot(delta<1e-12)
  checks[[rule]]<-data.frame(rule=rule,max_abs_difference=delta);mods[[rule]]<-list(genes=g,lambda_1se=f$lambda.1se,model=f$glmnet.fit)
 }
 write.csv(do.call(rbind,checks),file.path(cd,'selected_model_refit_checks.csv'),row.names=FALSE);saveRDS(mods,file.path(od,'selected_models.rds'),compress=FALSE)
 # Test data are accessed only after the exhaustive global selection lock and refit verification.
 inp<-readRDS(file.path(base,'inputs.rds'));part<-inp$partitions[[fn]];md<-inp$metadata;ids<-c(part$discovery_test,part$selection_test);mp<-read.csv(file.path(od,'selected_probe_map.csv'))
 xt<-t(inp$probe_expression[mp$PROBEID,ids,drop=FALSE]);colnames(xt)<-mp$SYMBOL
 preds<-do.call(rbind,lapply(names(mods),function(rule){m<-mods[[rule]];p<-as.numeric(predict(m$model,newx=xt[,m$genes,drop=FALSE],s=m$lambda_1se,type='response'));data.frame(variant=variant,repeat_id=part$repeat_id,fold=part$fold,rule=rule,sample_id=ids,cohort=md$cohort[match(ids,md$sample_id)],truth=md$group[match(ids,md$sample_id)],probability_MI=p,selected_genes=paste(m$genes,collapse=';'))}))
 write.csv(preds,file.path(od,'outer_test_predictions.csv'),row.names=FALSE)
 write_json(list(status='completed_continuation',variant=variant,fold=fn,n_pool=length(z$pool),n_subsets=z$total,n_chunks=nrow(chunks),all_indices_unique_complete=TRUE,all_gene_signatures_unique=TRUE,initial_failure_preserved=TRUE,primary_genes=chosen$genes),file.path(od,'COMPLETED_CONTINUATION.json'),pretty=TRUE,auto_unbox=TRUE)
 writeLines(capture.output(sessionInfo()),file.path(cd,'sessionInfo.txt'));cat('CONTINUATION_COMPLETE',variant,fn,z$total,'\n')
} else stop('Unknown mode')
