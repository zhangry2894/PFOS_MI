"""Extract official processed expression after PROTOCOL_EXTERNAL_LOCKED, no fitting."""
from pathlib import Path
import csv, gzip, json, re, collections, hashlib, datetime
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'locked_external_inputs'
OUT.mkdir(exist_ok=True)
eligible = pd.read_csv(ROOT/'metadata/candidate_sample_eligibility.csv')
all_summaries = []

def gene_symbols(row, acc):
    if acc == 'GSE61144':
        raw = row.get('Symbol', '').strip()
        if not raw or raw == '---': return [], raw
        return sorted(set(x.strip() for x in re.split(r'\s*///\s*|\s*//\s*|[;,|]', raw) if x.strip())), raw
    raw = row.get('gene_assignment', '').strip()
    symbols = []
    for block in raw.split(' /// '):
        fields = block.split(' // ')
        if len(fields) >= 2 and fields[1].strip() not in ['', '---', 'NA']:
            symbols.append(fields[1].strip())
    return sorted(set(symbols)), raw

for acc in ['GSE61144', 'GSE59867']:
    samples = eligible[(eligible.accession == acc) & (eligible.group != 'excluded')].copy()
    subjects = []
    for _, s in samples.iterrows():
        if acc == 'GSE61144':
            sid = str(s.explicit_subject_id)
            if sid in ['', 'nan']: raise ValueError('Missing explicit subject ID')
            subjects.append(s.group + ':' + sid)
        else:
            title = s.sample_title
            match = re.fullmatch(r'Patient\s+([^,]+),\s*sampling\s+1', title, re.I) if s.group == 'MI' else re.fullmatch(r'Control patient\s+(.+)', title, re.I)
            if not match: raise ValueError('Uninterpretable subject title: ' + title)
            subjects.append(s.group + ':' + match.group(1).strip())
    samples['subject_id_verified'] = subjects
    if samples.subject_id_verified.duplicated().any(): raise ValueError('Duplicate included subject')
    sample_ids = samples.sample_id.tolist()
    chosen = set(sample_ids)
    annotation = []
    values = {}
    with gzip.open(ROOT/'raw_official'/f'{acc}_family.soft.gz', 'rt', encoding='utf8', newline='') as f:
        active_sample = None
        for line in f:
            if line.startswith('^SAMPLE = '): active_sample = line.strip().split(' = ', 1)[1]
            elif line.startswith('!platform_table_begin'):
                headers = next(csv.reader([next(f)], delimiter='\t'))
                for line in f:
                    if line.startswith('!platform_table_end'): break
                    fields = next(csv.reader([line], delimiter='\t'))
                    row = dict(zip(headers, fields))
                    syms, raw = gene_symbols(row, acc)
                    annotation.append({'probe_id': row['ID'], 'gene_symbol': syms[0] if len(syms) == 1 else '', 'n_unique_gene_symbols': len(syms), 'raw_gene_assignment': raw})
            elif line.startswith('!sample_table_begin'):
                headers = next(csv.reader([next(f)], delimiter='\t'))
                if active_sample not in chosen:
                    for line in f:
                        if line.startswith('!sample_table_end'): break
                    continue
                ix_id = headers.index('ID_REF'); ix_val = headers.index('VALUE')
                rows = []
                for line in f:
                    if line.startswith('!sample_table_end'): break
                    fields = next(csv.reader([line], delimiter='\t'))
                    rows.append((fields[ix_id], float(fields[ix_val])))
                values[active_sample] = rows
    anno = pd.DataFrame(annotation)
    anno['duplicate_annotation_id'] = anno.probe_id.duplicated(keep=False)
    anno['keep_mapping'] = (anno.n_unique_gene_symbols == 1) & ~anno.duplicate_annotation_id
    anno['mapping_reason'] = np.select([anno.duplicate_annotation_id, anno.n_unique_gene_symbols == 0, anno.n_unique_gene_symbols > 1], ['duplicate_feature_id', 'no_gene_symbol', 'multiple_gene_symbols'], default='unique_gene_symbol')
    anno.to_csv(OUT/f'{acc}_probe_mapping_audit.csv.gz', index=False, compression='gzip')
    if set(values) != chosen: raise ValueError('Missing selected sample table')
    duplicated_expression_ids = set()
    for sid, rows in values.items():
        counts = collections.Counter(x[0] for x in rows)
        duplicated_expression_ids.update(k for k,v in counts.items() if v > 1)
    matrix = pd.DataFrame({sid: {k:v for k,v in rows if k not in duplicated_expression_ids} for sid,rows in values.items()})
    matrix = matrix[sample_ids]
    mapping = anno[anno.keep_mapping & ~anno.probe_id.isin(duplicated_expression_ids)].set_index('probe_id').gene_symbol
    matched = mapping.index.intersection(matrix.index)
    x = matrix.loc[matched].copy()
    finite = np.isfinite(x.to_numpy()).all(axis=1)
    nonfinite_features = x.index[~finite].tolist()
    x = x.loc[finite]
    x['gene_symbol'] = mapping.reindex(x.index)
    gene = x.groupby('gene_symbol', sort=True).median()
    for target in ['ALPL', 'PLAU']:
        if target not in gene.index or not np.isfinite(gene.loc[target].to_numpy()).all(): raise ValueError('Target absent or nonfinite')
    gene.to_csv(OUT/f'{acc}_gene_expression_log2.csv.gz', index_label='gene_symbol', compression='gzip')
    samples.to_csv(OUT/f'{acc}_eligible_samples.csv', index=False)
    target_map = anno[anno.gene_symbol.isin(['ALPL', 'PLAU'])].copy()
    target_map['present_in_sample_tables'] = target_map.probe_id.isin(matrix.index)
    target_map['used_for_median'] = target_map.probe_id.isin(x.index)
    target_map.to_csv(OUT/f'{acc}_ALPL_PLAU_probe_mapping.csv', index=False)
    summary = {'accession':acc, 'n_samples': len(samples), 'n_MI':int((samples.group == 'MI').sum()), 'n_control':int((samples.group == 'Control').sum()), 'n_unique_subjects': samples.subject_id_verified.nunique(), 'n_platform_rows':len(anno), 'n_unique_symbol_mapped_features':int(anno.keep_mapping.sum()), 'n_expression_features':len(matrix), 'duplicate_expression_ids_excluded':sorted(duplicated_expression_ids), 'nonfinite_features_excluded':nonfinite_features, 'n_features_after_mapping_and_finite_check':len(x), 'n_genes_for_transcriptome_BH':len(gene), 'gene_expression_range_all_samples':[float(gene.to_numpy().min()),float(gene.to_numpy().max())], 'transformation':'None added; official submitter log2 processed data', 'aggregation':'sample-wise median across uniquely single-gene mapped features', 'target_features':{t:target_map[(target_map.gene_symbol==t)&target_map.used_for_median].probe_id.tolist() for t in ['ALPL','PLAU']}}
    all_summaries.append(summary)
    print(json.dumps(summary), flush=True)
(OUT/'expression_extraction_summary.json').write_text(json.dumps(all_summaries,indent=2),encoding='utf8')
manifest = []
for p in OUT.iterdir():
    if p.is_file(): manifest.append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(OUT/'input_manifest.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':manifest},indent=2),encoding='utf8')
