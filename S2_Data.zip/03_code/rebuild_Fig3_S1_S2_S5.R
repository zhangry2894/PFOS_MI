# Presentation-only rendering of archived observations; no model re-fitting.
suppressPackageStartupMessages({library(ggplot2);library(patchwork);library(ragg);library(svglite)})
f<-sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1])
root<-dirname(normalizePath(f,winslash='/'))
out<-file.path(root,'outputs');dir.create(out,showWarnings=FALSE)
read<-function(n)read.csv(file.path(root,'inputs',n),fileEncoding='UTF-8-BOM',check.names=FALSE)
theme_set(theme_classic(base_size=9,base_family='Arial')+theme(
 axis.text=element_text(size=8,colour='#222222'),axis.title=element_text(size=9),
 plot.title=element_text(size=10,face='bold',margin=margin(b=8)),
 legend.text=element_text(size=8),legend.title=element_text(size=8),
 plot.margin=margin(7,8,7,7),plot.tag=element_text(size=12,face='bold')))
savefig<-function(p,stem,w,h){
 ww<-w/25.4;hh<-h/25.4
 cairo_pdf(file.path(out,paste0(stem,'.pdf')),width=ww,height=hh,family='Arial');print(p);dev.off()
 svglite(file.path(out,paste0(stem,'.svg')),width=ww,height=hh,bg='white');print(p);dev.off()
 agg_tiff(file.path(out,paste0(stem,'.tif')),width=ww,height=hh,units='in',res=600,compression='lzw',background='white');print(p);dev.off()
 agg_jpeg(file.path(out,paste0(stem,'.jpg')),width=ww,height=hh,units='in',res=600,quality=98,background='white');print(p);dev.off()
 agg_png(file.path(out,paste0(stem,'_preview.png')),width=ww,height=hh,units='in',res=200,background='white');print(p);dev.off()
}
n<-read('native_per_seed.csv');wet<-read('water_per_seed.csv');s<-read('PFOS_scores_per_seed.csv')
nd<-rbind(n[,c('variant','seed','top1_RMSD_A')],data.frame(variant='water',seed=wet$seed,top1_RMSD_A=wet$top1_RMSD_A))
keys<-c('ALPL_AB_primary','ALPL_A_sensitivity','PLAU_zwitterion_primary','PLAU_neutral_sensitivity','water')
labels<-c('ALPL A+B\ndry (primary)','ALPL A-only\ndry','PLAU zwitterion\ndry (primary)','PLAU neutral\ndry','PLAU zwitterion\nfixed water O')
nd$y<-6-match(nd$variant,keys);nd$seed<-factor(nd$seed)
nd$yp<-nd$y+c(.13,0,-.13)[match(nd$seed,levels(nd$seed))]
nd$status<-ifelse(nd$top1_RMSD_A<=2,'Meets 2-A criterion','Does not meet criterion')
ns<-do.call(rbind,lapply(keys,function(k){x<-nd[nd$variant==k,];data.frame(variant=k,y=unique(x$y),mean=mean(x$top1_RMSD_A),sd=sd(x$top1_RMSD_A),pass=sum(x$top1_RMSD_A<=2))}))
stopifnot(nrow(nd)==15,nrow(s)==9,all(table(nd$variant)==3))
pal<-c('Meets 2-A criterion'='#176B82','Does not meet criterion'='#C46C2B')
pa<-ggplot(nd,aes(top1_RMSD_A,yp))+
 geom_vline(xintercept=2,linetype='dashed',linewidth=.4,colour='#555555')+
 geom_segment(data=ns,aes(x=mean-sd,xend=mean+sd,y=y,yend=y),inherit.aes=FALSE,linewidth=.6)+
 geom_point(aes(shape=seed,colour=status),size=2.0)+
 geom_point(data=ns,aes(mean,y),inherit.aes=FALSE,shape=3,size=2.2)+
 geom_text(data=ns,aes(x=11.0,y=y,label=paste0(pass,'/3')),inherit.aes=FALSE,size=8/ggplot2::.pt,hjust=.5)+
 annotate('text',x=11,y=5.7,label='Pass',size=8/ggplot2::.pt)+
 scale_shape_manual(values=c(16,17,15),name='Search seed')+
 scale_colour_manual(values=pal,guide='none')+
 scale_y_continuous(breaks=5:1,labels=labels,limits=c(.5,5.9),expand=c(0,0))+
 scale_x_continuous(breaks=seq(0,10,2),limits=c(0,11.6),expand=c(0,0))+
 labs(title='Native-ligand pose recovery',x='Top-ranked heavy-atom RMSD (\u00c5)',y=NULL)+
 theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),legend.position='bottom')
skeys<-c('dry_pocket','fixed_water_oxygen','surface_reference')
s$y<-4-match(s$condition,skeys);s$seed<-factor(s$seed)
s$yp<-s$y+c(.12,0,-.12)[match(s$seed,levels(s$seed))]
ss<-do.call(rbind,lapply(skeys,function(k){x<-s[s$condition==k,];data.frame(condition=k,y=unique(x$y),mean=mean(x$top1_score_kcal_mol),sd=sd(x$top1_score_kcal_mol))}))
pb<-ggplot(s,aes(top1_score_kcal_mol,yp))+
 geom_segment(data=ss,aes(x=mean-sd,xend=mean+sd,y=y,yend=y),inherit.aes=FALSE,linewidth=.6)+
 geom_point(aes(shape=seed),size=2,colour='#176B82')+
 geom_point(data=ss,aes(mean,y),inherit.aes=FALSE,shape=3,size=2.2)+
 geom_text(data=ss,aes(x=-8.05,y=y-.30,label=sprintf('%.3f \u00b1 %.3f',mean,sd)),inherit.aes=FALSE,size=8/ggplot2::.pt,hjust=0)+
 scale_shape_manual(values=c(16,17,15),name='Search seed',guide='none')+
 scale_y_continuous(breaks=3:1,labels=c('Dry pocket','Fixed water O\npocket','Dry surface\nreference'),limits=c(.45,3.8),expand=c(0,0))+
 scale_x_continuous(breaks=-8:-4,limits=c(-8.15,-3.7),expand=c(0,0))+
 labs(title='PLAU PFOS scores',x='Vina score (kcal/mol)',y=NULL)+
 theme(axis.line.y=element_blank(),axis.ticks.y=element_blank(),legend.position='bottom')
p<-(pa|pb)+plot_layout(widths=c(1.28,1),guides='collect')+plot_annotation(tag_levels='A',caption='Points: three predefined search seeds. Crosses and horizontal lines: mean \u00b1 SD.\nThe surface condition is a computational reference, not a validated non-binding control.') & theme(legend.position='bottom',plot.caption=element_text(size=8,hjust=0))
savefig(p,'Fig3',190,120)
write.csv(nd,file.path(out,'Fig3A_all15_runs.csv'),row.names=FALSE)
write.csv(ns,file.path(out,'Fig3A_summary.csv'),row.names=FALSE)
write.csv(s,file.path(out,'Fig3B_all9_scores.csv'),row.names=FALSE)
write.csv(ss,file.path(out,'Fig3B_summary.csv'),row.names=FALSE)
pca<-read('PCA_coordinates.csv')
pca$cohort<-ifelse(pca$cohort=='Discovery','Discovery (n=43)',ifelse(pca$dataset=='GSE66360','Combination selection (n=56)','External (n=52)'))
pca_panel<-function(ds){
 d<-subset(pca,dataset==ds)
 p<-ggplot(d,aes(PC1,PC2,colour=group))+geom_hline(yintercept=0,colour='grey90',linewidth=.3)+geom_vline(xintercept=0,colour='grey90',linewidth=.3)
 if(ds=='GSE66360')p<-p+geom_point(aes(shape=cohort),size=2,alpha=.85)+scale_shape_manual(values=c(17,16),name='Analytical role') else p<-p+geom_point(size=2,alpha=.85)
 p+scale_colour_manual(values=c(Control='#267DAD',MI='#C86436'),name='Status')+labs(title=ds,x=sprintf('PC1 (%.1f%%)',unique(d$var1)),y=sprintf('PC2 (%.1f%%)',unique(d$var2)))+theme(legend.position='bottom',legend.margin=margin(0,0,0,0))
}
p<-(pca_panel('GSE66360')|pca_panel('GSE48060'))+plot_layout(guides='collect')+plot_annotation(tag_levels='A') & theme(legend.position='bottom',legend.box='vertical',legend.spacing.y=grid::unit(1,'mm'))
savefig(p,'S1_Fig',190,112)
write.csv(pca,file.path(out,'S1_all_PCA_coordinates.csv'),row.names=FALSE)
writeLines(capture.output(sessionInfo()),file.path(out,'R_sessionInfo.txt'))
cat('RENDER_COMPLETE Fig3 S1; all archived observations retained\n')
