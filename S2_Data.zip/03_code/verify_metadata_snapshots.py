"""Limited offline metadata-snapshot check, not a recreation of the full audit."""
from pathlib import Path
import argparse,gzip,json,re

def main():
 ap=argparse.ArgumentParser();ap.add_argument('s2');ap.add_argument('new_output');a=ap.parse_args()
 root=Path(a.s2);out=Path(a.new_output)
 if out.exists():raise FileExistsError('Choose a nonexistent output file')
 result=[]
 for acc in ['GSE48060','GSE61144','GSE59867']:
  text=gzip.decompress((root/'01_inputs'/f'{acc}_GEO_metadata.soft.txt.gz').read_bytes()).decode('utf-8-sig')
  records=re.split(r'(?m)^\^SAMPLE = ',text)[1:]
  ids=[x.splitlines()[0].strip() for x in records]
  if not ids or len(ids)!=len(set(ids)):raise ValueError('Missing/duplicate GSM record')
  sample_fields=sorted({line.split(' = ',1)[0] for r in records for line in r.splitlines() if line.startswith('!Sample_')})
  result.append({'accession':acc,'n_deposited_samples':len(ids),'sample_ids':ids,'sample_fields':sample_fields})
 report={'scope':'LIMITED_OFFLINE_PUBLIC_GEO_METADATA_SNAPSHOT_INVENTORY','results':result,
  'not_reproduced':['original multi-source publication/supplement audit','individual age/sex/batch adjustment'],
  'interpretation':'An inventory of deposited fields does not prove that covariates are unavailable elsewhere. Original final crosswalk/availability results are in S1.'}
 out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({r['accession']:r['n_deposited_samples'] for r in result},indent=2))

if __name__=='__main__':main()
