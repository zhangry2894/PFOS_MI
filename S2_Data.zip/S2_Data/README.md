# S2 Data: public analysis reproducibility bundle

This GitHub-safe archive contains analysis code, processed probe/sample metadata,
fitted model objects, QA reports, software-session records and a complete source
manifest. It deliberately excludes raw third-party database exports.

The standardized PFOS and MI gene-evidence tables and all analysis result tables
are in S1 Data. The normalized expression matrices are in S3 and S4 Data. Docking
inputs and outputs are in S5 Data.

Machine-specific paths in scripts and logs were replaced with relative or generic
paths. Use the documented environment variables or command-line arguments when
rerunning scripts. Exact ingestion from the third-party providers requires the
user to retrieve new exports under the providers' current terms.
