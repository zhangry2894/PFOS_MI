options(stringsAsFactors = FALSE)
suppressPackageStartupMessages({
  library(readxl)
})

clean <- function(x) {
  x <- trimws(as.character(x))
  unique(x[!is.na(x) & nzchar(x)])
}

base_dir <- Sys.getenv("PFOS_MI_INPUT_ROOT", unset = "./inputs/MI")
pfos_dir <- file.path(base_dir, "PFOS")

final <- clean(readLines(file.path(pfos_dir, "PFOS.txt"), warn = FALSE))
spmap <- read_excel(file.path(pfos_dir, "SuperPred", "idmapping_2026_05_04 (1).xlsx"))
pmmap <- read_excel(file.path(pfos_dir, "PharmMapper", "idmapping_2026_05_04.xlsx"))
sw <- read.csv(file.path(pfos_dir, "SwissTargetPrediction", "SwissTargetPrediction (44).csv"), check.names = FALSE)
st <- read.delim(file.path(pfos_dir, "STITCH", "stitch_interactions (6).tsv"), check.names = FALSE)
tn <- read_excel(file.path(pfos_dir, "TargetNet", "tn.xlsx"))
sp <- read.csv(file.path(pfos_dir, "SuperPred", "Targets (7).csv"), check.names = FALSE)
pm <- read.csv(file.path(pfos_dir, "PharmMapper", "260426135603.csv"), skip = 2, check.names = FALSE, fill = TRUE)

stitch_direct <- clean(c(
  st[["#node1"]][grepl("perfluoroo", st[["node2"]], ignore.case = TRUE)],
  st[["node2"]][grepl("perfluoroo", st[["#node1"]], ignore.case = TRUE)]
))

sets <- list(
  SuperPred = clean(spmap$To),
  PharmMapper = clean(pmmap$To),
  Swiss = clean(sw[["Common name"]]),
  STITCH_direct = stitch_direct
)

cat("FINAL_PFOS_TARGETS\t", length(final), "\n", sep = "")
for (n in names(sets)) {
  s <- sets[[n]]
  cat(
    n,
    "\tn=", length(s),
    "\tsource_in_final=", sum(s %in% final),
    "\tfinal_supported=", sum(final %in% s),
    "\tsource_not_final=", paste(setdiff(s, final), collapse = ";"),
    "\n",
    sep = ""
  )
}

u <- unique(c(sets$SuperPred, sets$PharmMapper))
cat(
  "UNION_SUPERPRED_PHARMMAPPER",
  "\tn=", length(u),
  "\tmatches_final=", setequal(u, final),
  "\tmissing=", paste(setdiff(final, u), collapse = ";"),
  "\textra=", paste(setdiff(u, final), collapse = ";"),
  "\n",
  sep = ""
)

cat("\nTARGETNET_PROBABILITY\n")
print(summary(tn$Prob))
cat("positive=", sum(tn$Prob > 0, na.rm = TRUE), "\tge_0.5=", sum(tn$Prob >= 0.5, na.rm = TRUE), "\n", sep = "")

cat("\nSUPERPRED_PROBABILITY_PERCENT\n")
sp_prob <- as.numeric(sub("%", "", sp$Probability))
print(summary(sp_prob))
cat("ge_50=", sum(sp_prob >= 50), "\tge_70=", sum(sp_prob >= 70), "\n", sep = "")

cat("\nPHARMMAPPER_NORM_FIT\n")
print(summary(pm[["Norm Fit"]]))
cat("ge_0.8=", sum(pm[["Norm Fit"]] >= 0.8), "\tge_0.9=", sum(pm[["Norm Fit"]] >= 0.9), "\n", sep = "")

cat("\nOVERLAP_MATRIX\n")
all_sets <- c(sets, list(Final = final))
mat <- outer(
  names(all_sets), names(all_sets),
  Vectorize(function(a, b) length(intersect(all_sets[[a]], all_sets[[b]])))
)
dimnames(mat) <- list(names(all_sets), names(all_sets))
print(mat)
