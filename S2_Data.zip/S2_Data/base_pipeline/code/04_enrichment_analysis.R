options(stringsAsFactors = FALSE, width = 180)
set.seed(20260914)

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(clusterProfiler)
  library(msigdbr)
  library(org.Hs.eg.db)
})

work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
results_dir <- file.path(work, "04_results")
logs_dir <- file.path(work, "08_logs")

target <- read.csv(file.path(results_dir, "PFOS_target_evidence_and_tiers.csv"), check.names = FALSE)
disease <- read.csv(file.path(results_dir, "MI_gene_evidence_and_tiers.csv"), check.names = FALSE)

definitions <- list(
  broad_original = intersect(target$gene[target$tier_original_broad], disease$gene[disease$tier_original_2841]),
  PFOS_highconf_disease_original = intersect(target$gene[target$tier_high_confidence_any], disease$gene[disease$tier_original_2841]),
  PFOS_consensus2_disease_original = intersect(target$gene[target$tier_consensus_2plus], disease$gene[disease$tier_original_2841]),
  PFOS_original_disease_score_gt5 = intersect(target$gene[target$tier_original_broad], disease$gene[disease$tier_genecards_score_gt5_plus_omim]),
  PFOS_original_disease_top10pct = intersect(target$gene[target$tier_original_broad], disease$gene[disease$tier_genecards_top10pct_plus_omim])
)

symbol_to_entrez <- AnnotationDbi::select(
  org.Hs.eg.db,
  keys = unique(unlist(definitions)),
  keytype = "SYMBOL",
  columns = "ENTREZID"
)
symbol_to_entrez <- unique(symbol_to_entrez[!is.na(symbol_to_entrez$ENTREZID), ])

universe_map <- AnnotationDbi::select(
  org.Hs.eg.db,
  keys = keys(org.Hs.eg.db, keytype = "SYMBOL"),
  keytype = "SYMBOL",
  columns = "ENTREZID"
)
universe <- unique(na.omit(universe_map$ENTREZID))
entrez_to_symbol <- split(universe_map$SYMBOL, universe_map$ENTREZID)

kegg_medicus <- msigdbr(
  species = "Homo sapiens",
  collection = "C2",
  subcollection = "CP:KEGG_MEDICUS"
)
kegg_term2gene <- unique(data.frame(term = kegg_medicus$gs_name, gene = as.character(kegg_medicus$ncbi_gene)))
kegg_term2name <- unique(data.frame(term = kegg_medicus$gs_name, name = kegg_medicus$gs_description))
kegg_db_version <- unique(kegg_medicus$db_version)

convert_gene_ids <- function(gene_id_string) {
  ids <- unique(unlist(strsplit(gene_id_string, "/", fixed = TRUE)))
  symbols <- unique(unlist(entrez_to_symbol[ids], use.names = FALSE))
  paste(sort(symbols[!is.na(symbols) & nzchar(symbols)]), collapse = "/")
}

tidy_enrich <- function(obj, definition, database, ontology = NA_character_) {
  if (is.null(obj) || nrow(as.data.frame(obj)) == 0) return(NULL)
  z <- as.data.frame(obj)
  z$definition <- definition
  z$database <- database
  z$ontology <- ontology
  z$gene_symbols <- vapply(z$geneID, convert_gene_ids, character(1))
  z
}

all_results <- list()
run_index <- 0L
for (nm in names(definitions)) {
  genes <- definitions[[nm]]
  entrez <- unique(symbol_to_entrez$ENTREZID[symbol_to_entrez$SYMBOL %in% genes])
  cat(nm, "symbols=", length(genes), "entrez=", length(entrez), "\n")
  for (ont in c("BP", "CC", "MF")) {
    run_index <- run_index + 1L
    ego <- enrichGO(
      gene = entrez,
      universe = universe,
      OrgDb = org.Hs.eg.db,
      keyType = "ENTREZID",
      ont = ont,
      pAdjustMethod = "BH",
      pvalueCutoff = 1,
      qvalueCutoff = 1,
      readable = FALSE
    )
    all_results[[run_index]] <- tidy_enrich(ego, nm, "GO", ont)
  }
  run_index <- run_index + 1L
  ekegg <- enricher(
    gene = entrez,
    universe = universe,
    pAdjustMethod = "BH",
    pvalueCutoff = 1,
    qvalueCutoff = 1,
    TERM2GENE = kegg_term2gene,
    TERM2NAME = kegg_term2name
  )
  all_results[[run_index]] <- tidy_enrich(ekegg, nm, paste0("KEGG_MEDICUS_MSIGDB_", kegg_db_version[1]), NA_character_)
}

all_results <- do.call(rbind, Filter(Negate(is.null), all_results))
all_results <- all_results[, c(
  "definition", "database", "ontology", "ID", "Description", "GeneRatio", "BgRatio",
  "pvalue", "p.adjust", "qvalue", "Count", "geneID", "gene_symbols"
)]
write.csv(all_results, file.path(results_dir, "GO_KEGG_enrichment_all_definitions.csv"), row.names = FALSE)

sig <- all_results[all_results$p.adjust < 0.05, ]
write.csv(sig, file.path(results_dir, "GO_KEGG_enrichment_FDR_lt_0.05.csv"), row.names = FALSE)

sig$ontology[is.na(sig$ontology) | !nzchar(sig$ontology)] <- "Pathway"
term_stability <- aggregate(
  definition ~ database + ontology + ID + Description,
  data = sig,
  FUN = function(x) paste(sort(unique(x)), collapse = ";")
)
names(term_stability)[names(term_stability) == "definition"] <- "significant_definitions"
term_stability$n_definitions <- vapply(strsplit(term_stability$significant_definitions, ";", fixed = TRUE), length, integer(1))
term_stability <- term_stability[order(-term_stability$n_definitions, term_stability$database, term_stability$ontology, term_stability$ID), ]
write.csv(term_stability, file.path(results_dir, "enrichment_term_stability.csv"), row.names = FALSE)

analysis_manifest <- data.frame(
  definition = names(definitions),
  n_symbols = vapply(definitions, length, integer(1)),
  n_entrez = vapply(definitions, function(g) length(unique(symbol_to_entrez$ENTREZID[symbol_to_entrez$SYMBOL %in% g])), integer(1)),
  gene_symbols = vapply(definitions, function(g) paste(sort(g), collapse = ";"), character(1))
)
analysis_manifest$universe_entrez_n <- length(universe)
write.csv(analysis_manifest, file.path(results_dir, "enrichment_analysis_manifest.csv"), row.names = FALSE)

cat("Universe Entrez IDs:", length(universe), "\n")
cat("Significant terms by definition/database/ontology:\n")
print(with(sig, table(definition, database, ontology, useNA = "ifany")))
cat("\nTop stable significant terms:\n")
print(head(term_stability, 30))
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo_after_enrichment.txt"))
