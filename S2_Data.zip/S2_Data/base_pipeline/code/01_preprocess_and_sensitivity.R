options(stringsAsFactors = FALSE, width = 180)
set.seed(20260914)

suppressPackageStartupMessages({
  library(AnnotationDbi)
  library(GEOquery)
  library(hgu133plus2.db)
  library(limma)
  library(org.Hs.eg.db)
  library(readxl)
})

root <- Sys.getenv("PFOS_MI_INPUT_ROOT", unset = "./inputs/MI")
work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = file.path(root, "PFOS", "tougao", "revise", "tmp")
)
raw_dir <- file.path(work, "02_data_raw")
processed_dir <- file.path(work, "03_data_processed")
results_dir <- file.path(work, "04_results")
logs_dir <- file.path(work, "08_logs")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

clean <- function(x) {
  x <- toupper(trimws(as.character(x)))
  unique(x[!is.na(x) & nzchar(x)])
}

write_csv <- function(x, path) {
  write.csv(x, path, row.names = FALSE, na = "")
}

write_csv_gz <- function(x, path, row.names = FALSE) {
  con <- gzfile(path, open = "wt", compression = 9)
  on.exit(close(con), add = TRUE)
  write.csv(x, con, row.names = row.names, na = "")
}

read_geo_local <- function(path) {
  getGEO(filename = path, getGPL = FALSE)
}

collapse_platform <- function(expr66360, discovery_samples) {
  probes <- rownames(expr66360)
  map <- AnnotationDbi::select(
    hgu133plus2.db,
    keys = probes,
    keytype = "PROBEID",
    columns = "SYMBOL"
  )
  map <- unique(map[!is.na(map$SYMBOL) & nzchar(map$SYMBOL), c("PROBEID", "SYMBOL")])
  map$SYMBOL <- toupper(map$SYMBOL)
  counts <- table(map$PROBEID)
  map <- map[map$PROBEID %in% names(counts[counts == 1]), , drop = FALSE]
  iqrs <- apply(expr66360[, discovery_samples, drop = FALSE], 1, IQR, na.rm = TRUE)
  map$IQR_DISCOVERY <- iqrs[map$PROBEID]
  map <- map[order(map$SYMBOL, -map$IQR_DISCOVERY, map$PROBEID), ]
  selected <- map[!duplicated(map$SYMBOL), ]
  rownames(selected) <- selected$SYMBOL
  selected
}

gene_matrix_from_map <- function(expr, selected) {
  keep <- selected$PROBEID %in% rownames(expr)
  selected2 <- selected[keep, , drop = FALSE]
  out <- expr[selected2$PROBEID, , drop = FALSE]
  rownames(out) <- selected2$SYMBOL
  storage.mode(out) <- "double"
  out
}

fit_limma <- function(expr, group, cohort_name) {
  group <- factor(group, levels = c("Control", "MI"))
  design <- model.matrix(~ group)
  fit <- eBayes(lmFit(expr, design), robust = TRUE)
  tab <- topTable(fit, coef = "groupMI", number = Inf, sort.by = "none")
  tab$gene <- rownames(tab)
  tab$cohort <- cohort_name
  tab$mean_control <- rowMeans(expr[, group == "Control", drop = FALSE], na.rm = TRUE)
  tab$mean_MI <- rowMeans(expr[, group == "MI", drop = FALSE], na.rm = TRUE)
  tab <- tab[, c("cohort", "gene", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B", "mean_control", "mean_MI")]
  rownames(tab) <- NULL
  tab
}

cat("Loading locally archived GEO series matrices...\n")
g66360 <- read_geo_local(file.path(root, "GSE66360_series_matrix.txt.gz"))
g48060_path <- file.path(raw_dir, "GSE48060_series_matrix.txt.gz")
if (!file.exists(g48060_path)) {
  bundled_g48060 <- file.path(root, "GSE48060_series_matrix.txt.gz")
  if (!file.exists(bundled_g48060)) {
    stop("GSE48060_series_matrix.txt.gz was not found in either the work/raw or input root directory")
  }
  file.copy(bundled_g48060, g48060_path, overwrite = FALSE)
}
g48060 <- read_geo_local(g48060_path)

p66360 <- pData(g66360)
p48060 <- pData(g48060)

meta66360 <- data.frame(
  sample_id = p66360$geo_accession,
  title = p66360$title,
  group = ifelse(p66360[["disease_status:ch1"]] == "Myocardial Infarction", "MI", "Control"),
  cohort = tools::toTitleCase(tolower(p66360[["cohort:ch1"]])),
  sample_type = p66360[["cell type:ch1"]],
  platform = p66360$platform_id,
  processing = p66360$data_processing,
  stringsAsFactors = FALSE
)

meta48060 <- data.frame(
  sample_id = p48060$geo_accession,
  title = p48060$title,
  group = ifelse(p48060[["disease status:ch1"]] == "normal control", "Control", "MI"),
  recurrence_status = p48060[["disease status:ch1"]],
  sample_type = p48060[["tissue:ch1"]],
  platform = p48060$platform_id,
  processing = p48060$data_processing,
  stringsAsFactors = FALSE
)

write_csv(meta66360, file.path(processed_dir, "GSE66360_sample_metadata.csv"))
write_csv(meta48060, file.path(processed_dir, "GSE48060_sample_metadata.csv"))

cat("GSE66360 group/cohort counts:\n")
print(with(meta66360, table(cohort, group)))
cat("GSE48060 group counts:\n")
print(table(meta48060$group))

expr66360_probe <- exprs(g66360)
expr48060_probe <- exprs(g48060)
cat("Probe-level expression summaries:\n")
print(summary(as.vector(expr66360_probe)))
print(summary(as.vector(expr48060_probe)))

discovery_ids <- meta66360$sample_id[meta66360$cohort == "Discovery"]
probe_map <- collapse_platform(expr66360_probe, discovery_ids)
write_csv(probe_map, file.path(processed_dir, "GPL570_probe_to_gene_selected_by_discovery_IQR.csv"))

expr66360 <- gene_matrix_from_map(expr66360_probe, probe_map)
expr48060 <- gene_matrix_from_map(expr48060_probe, probe_map)
common_gene_order <- intersect(rownames(expr66360), rownames(expr48060))
expr66360 <- expr66360[common_gene_order, meta66360$sample_id, drop = FALSE]
expr48060 <- expr48060[common_gene_order, meta48060$sample_id, drop = FALSE]

saveRDS(expr66360, file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"), compress = "xz")
saveRDS(expr48060, file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"), compress = "xz")
write_csv_gz(data.frame(gene = rownames(expr66360), expr66360, check.names = FALSE), file.path(processed_dir, "GSE66360_gene_expression_RMA.csv.gz"))
write_csv_gz(data.frame(gene = rownames(expr48060), expr48060, check.names = FALSE), file.path(processed_dir, "GSE48060_gene_expression_RMA.csv.gz"))

cat("Gene-level dimensions: GSE66360=", paste(dim(expr66360), collapse = "x"), " GSE48060=", paste(dim(expr48060), collapse = "x"), "\n", sep = "")

# PFOS target provenance and evidence tiers.
pfos_dir <- file.path(root, "PFOS")
sp_raw <- read.csv(file.path(pfos_dir, "SuperPred", "Targets (7).csv"), check.names = FALSE)
sp_map <- read_excel(file.path(pfos_dir, "SuperPred", "idmapping_2026_05_04 (1).xlsx"))
sp_raw$probability <- as.numeric(sub("%", "", sp_raw$Probability)) / 100
sp <- merge(sp_raw, sp_map, by.x = "UniProt ID", by.y = "From", all.x = TRUE)
sp$gene <- toupper(sp$To)

pm_raw <- read.csv(file.path(pfos_dir, "PharmMapper", "260426135603.csv"), skip = 2, check.names = FALSE, fill = TRUE)
pm_map <- read_excel(file.path(pfos_dir, "PharmMapper", "idmapping_2026_05_04.xlsx"))
pm <- merge(pm_raw, pm_map, by.x = "Uniplot", by.y = "From", all.x = TRUE)
pm$gene <- toupper(pm$To)

sw <- read.csv(file.path(pfos_dir, "SwissTargetPrediction", "SwissTargetPrediction (44).csv"), check.names = FALSE)
sw$gene <- toupper(sw[["Common name"]])
sw$probability <- as.numeric(sw[["Probability*"]])

st <- read.delim(file.path(pfos_dir, "STITCH", "stitch_interactions (6).tsv"), check.names = FALSE)
st_direct <- st[grepl("perfluoroo", st[["node2"]], ignore.case = TRUE) | grepl("perfluoroo", st[["#node1"]], ignore.case = TRUE), ]
st_direct$gene <- ifelse(grepl("perfluoroo", st_direct[["node2"]], ignore.case = TRUE), st_direct[["#node1"]], st_direct[["node2"]])
st_direct$gene <- toupper(st_direct$gene)

tn <- read_excel(file.path(pfos_dir, "TargetNet", "tn.xlsx"))
tn_map <- AnnotationDbi::select(org.Hs.eg.db, keys = unique(na.omit(tn$Uniprot_ID)), keytype = "UNIPROT", columns = "SYMBOL")
tn <- merge(tn, tn_map, by.x = "Uniprot_ID", by.y = "UNIPROT", all.x = TRUE)
tn$gene <- toupper(tn$SYMBOL)

evidence_genes <- sort(unique(c(clean(sp$gene), clean(pm$gene), clean(sw$gene), clean(st_direct$gene), clean(tn$gene))))
evidence <- data.frame(gene = evidence_genes)

source_summarise <- function(df, gene_col, score_col, prefix, high_cutoff, positive_cutoff = -Inf) {
  gene <- toupper(as.character(df[[gene_col]]))
  score <- suppressWarnings(as.numeric(df[[score_col]]))
  valid <- !is.na(gene) & nzchar(gene) & !is.na(score)
  z <- aggregate(score[valid], by = list(gene = gene[valid]), FUN = max, na.rm = TRUE)
  names(z)[2] <- paste0(prefix, "_score")
  z[[paste0(prefix, "_present")]] <- z[[paste0(prefix, "_score")]] > positive_cutoff
  z[[paste0(prefix, "_high_confidence")]] <- z[[paste0(prefix, "_score")]] >= high_cutoff
  z
}

ev_sp <- source_summarise(sp, "gene", "probability", "superpred", 0.70, -Inf)
ev_pm <- source_summarise(pm, "gene", "Norm Fit", "pharmmapper", 0.80, -Inf)
ev_sw <- source_summarise(sw, "gene", "probability", "swisstargetprediction", .Machine$double.eps, -Inf)
ev_st <- source_summarise(st_direct, "gene", "combined_score", "stitch", 0.70, -Inf)
ev_tn <- source_summarise(tn, "gene", "Prob", "targetnet", 0.50, 0)

for (z in list(ev_sp, ev_pm, ev_sw, ev_st, ev_tn)) evidence <- merge(evidence, z, by = "gene", all.x = TRUE)
present_cols <- grep("_present$", names(evidence), value = TRUE)
high_cols <- grep("_high_confidence$", names(evidence), value = TRUE)
evidence[present_cols] <- lapply(evidence[present_cols], function(x) ifelse(is.na(x), FALSE, x))
evidence[high_cols] <- lapply(evidence[high_cols], function(x) ifelse(is.na(x), FALSE, x))
evidence$n_sources <- rowSums(evidence[present_cols])
evidence$n_high_confidence_sources <- rowSums(evidence[high_cols])
original_pfos <- clean(readLines(file.path(pfos_dir, "PFOS.txt"), warn = FALSE))
evidence$in_original_423 <- evidence$gene %in% original_pfos
evidence$tier_original_broad <- evidence$in_original_423
evidence$tier_high_confidence_any <- evidence$n_high_confidence_sources >= 1
evidence$tier_consensus_2plus <- evidence$n_sources >= 2
write_csv(evidence, file.path(results_dir, "PFOS_target_evidence_and_tiers.csv"))

# MI-associated genes and sensitivity tiers.
gc <- read_excel(file.path(root, "genecards", "MI.xlsx"), sheet = "gc")
gc <- data.frame(gene = toupper(gc$Symbol), genecards_score = as.numeric(gc$Score))
gc <- gc[!is.na(gc$gene) & nzchar(gc$gene) & !is.na(gc$genecards_score), ]
gc <- gc[order(gc$gene, -gc$genecards_score), ]
gc <- gc[!duplicated(gc$gene), ]
gc_median <- median(gc$genecards_score, na.rm = TRUE)
gc_top10_cut <- as.numeric(quantile(gc$genecards_score, 0.90, na.rm = TRUE, type = 7))

omim_raw <- read_excel(file.path(root, "OMIM", "OMIM-Gene-Map-Search (2).xlsx"), col_names = FALSE)
omim_header <- which(as.character(omim_raw[[1]]) == "Cytogenetic location")[1]
omim <- omim_raw[(omim_header + 1):nrow(omim_raw), , drop = FALSE]
omim_genes <- clean(omim[[6]][grepl("myocardial infarction", as.character(omim[[10]]), ignore.case = TRUE)])

original_mi <- clean(readLines(file.path(root, "MI_gcmedian.txt"), warn = FALSE))
disease <- data.frame(gene = sort(unique(c(gc$gene, omim_genes, original_mi))))
disease <- merge(disease, gc, by = "gene", all.x = TRUE)
disease$in_omim_mi <- disease$gene %in% omim_genes
disease$tier_original_2841 <- disease$gene %in% original_mi
disease$tier_genecards_median_plus_omim <- (!is.na(disease$genecards_score) & disease$genecards_score >= gc_median) | disease$in_omim_mi
disease$tier_genecards_score_gt5_plus_omim <- (!is.na(disease$genecards_score) & disease$genecards_score > 5) | disease$in_omim_mi
disease$tier_genecards_top10pct_plus_omim <- (!is.na(disease$genecards_score) & disease$genecards_score >= gc_top10_cut) | disease$in_omim_mi
write_csv(disease, file.path(results_dir, "MI_gene_evidence_and_tiers.csv"))

pfos_tiers <- list(
  Original_broad = evidence$gene[evidence$tier_original_broad],
  High_confidence_any = evidence$gene[evidence$tier_high_confidence_any],
  Consensus_2plus = evidence$gene[evidence$tier_consensus_2plus]
)
disease_tiers <- list(
  Original_2841 = disease$gene[disease$tier_original_2841],
  GeneCards_median_plus_OMIM = disease$gene[disease$tier_genecards_median_plus_omim],
  GeneCards_score_gt5_plus_OMIM = disease$gene[disease$tier_genecards_score_gt5_plus_omim],
  GeneCards_top10pct_plus_OMIM = disease$gene[disease$tier_genecards_top10pct_plus_omim]
)

hub_original <- c("PDE4B", "CCR2", "TGFBR1", "ALDH2", "STAT3")
sens <- do.call(rbind, lapply(names(pfos_tiers), function(pn) {
  do.call(rbind, lapply(names(disease_tiers), function(dn) {
    genes <- intersect(pfos_tiers[[pn]], disease_tiers[[dn]])
    data.frame(
      pfos_tier = pn,
      disease_tier = dn,
      n_pfos = length(pfos_tiers[[pn]]),
      n_disease = length(disease_tiers[[dn]]),
      n_overlap = length(genes),
      n_measured_GPL570 = sum(genes %in% rownames(expr66360)),
      original_hubs_retained = paste(intersect(hub_original, genes), collapse = ";"),
      overlap_genes = paste(sort(genes), collapse = ";"),
      stringsAsFactors = FALSE
    )
  }))
}))
write_csv(sens, file.path(results_dir, "target_threshold_sensitivity.csv"))

# Differential expression is estimated independently in discovery, internal validation, and external cohorts.
idx_discovery <- meta66360$cohort == "Discovery"
idx_validation <- meta66360$cohort == "Validation"
de_discovery <- fit_limma(expr66360[, idx_discovery, drop = FALSE], meta66360$group[idx_discovery], "GSE66360_discovery")
de_validation <- fit_limma(expr66360[, idx_validation, drop = FALSE], meta66360$group[idx_validation], "GSE66360_validation")
de_all <- fit_limma(expr66360, meta66360$group, "GSE66360_all_descriptive")
de_external <- fit_limma(expr48060, meta48060$group, "GSE48060_external")
de_allcohorts <- rbind(de_discovery, de_validation, de_all, de_external)
write_csv(de_allcohorts, file.path(results_dir, "limma_all_genes_all_cohorts.csv"))
write_csv(de_allcohorts[de_allcohorts$gene %in% hub_original, ], file.path(results_dir, "original_five_hub_genes_validation.csv"))

primary_candidates <- intersect(original_pfos, original_mi)
writeLines(sort(primary_candidates), file.path(processed_dir, "candidate_genes_original_broad_200.txt"))
write_csv(de_allcohorts[de_allcohorts$gene %in% primary_candidates, ], file.path(results_dir, "candidate_gene_limma_results.csv"))

summary_lines <- c(
  sprintf("Seed: %d", 20260914),
  sprintf("GSE66360 dimensions (gene x sample): %d x %d", nrow(expr66360), ncol(expr66360)),
  sprintf("GSE48060 dimensions (gene x sample): %d x %d", nrow(expr48060), ncol(expr48060)),
  sprintf("GSE66360 discovery: %s", paste(capture.output(print(with(meta66360[idx_discovery, ], table(group)))), collapse = " ")),
  sprintf("GSE66360 validation: %s", paste(capture.output(print(with(meta66360[idx_validation, ], table(group)))), collapse = " ")),
  sprintf("GSE48060 external: %s", paste(capture.output(print(table(meta48060$group))), collapse = " ")),
  sprintf("GeneCards median score: %.6f", gc_median),
  sprintf("GeneCards top-10%% score cutoff: %.6f", gc_top10_cut),
  sprintf("OMIM MI-specific approved symbols: %d", length(omim_genes)),
  sprintf("Original PFOS target count: %d", length(original_pfos)),
  sprintf("High-confidence-any PFOS target count: %d", length(pfos_tiers$High_confidence_any)),
  sprintf("Consensus >=2-source PFOS target count: %d", length(pfos_tiers$Consensus_2plus)),
  sprintf("Original network overlap count: %d", length(primary_candidates))
)
writeLines(summary_lines, file.path(logs_dir, "01_preprocess_summary.txt"))
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")
cat("\nOriginal five hub genes across target tiers:\n")
print(evidence[evidence$gene %in% hub_original, c("gene", present_cols, high_cols, "n_sources", "n_high_confidence_sources", "in_original_423")])
cat("\nThreshold sensitivity table:\n")
print(sens[, setdiff(names(sens), "overlap_genes")])
cat("\nOriginal five hub-gene validation:\n")
print(de_allcohorts[de_allcohorts$gene %in% hub_original, c("cohort", "gene", "logFC", "P.Value", "adj.P.Val")])
