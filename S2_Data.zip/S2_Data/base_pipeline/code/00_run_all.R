options(stringsAsFactors = FALSE, width = 180)

args <- commandArgs(trailingOnly = FALSE)
file_arg <- sub("^--file=", "", args[grepl("^--file=", args)])
if (length(file_arg) != 1L) stop("Run this file with Rscript")
code_dir <- dirname(normalizePath(file_arg, winslash = "/", mustWork = TRUE))
bundle_dir <- dirname(code_dir)

if (!nzchar(Sys.getenv("PFOS_MI_INPUT_ROOT"))) {
  Sys.setenv(PFOS_MI_INPUT_ROOT = file.path(bundle_dir, "inputs", "MI"))
}
if (!nzchar(Sys.getenv("PFOS_MI_WORK_ROOT"))) {
  Sys.setenv(PFOS_MI_WORK_ROOT = file.path(bundle_dir, "rerun_output"))
}

work <- Sys.getenv("PFOS_MI_WORK_ROOT")
Sys.setenv(PFOS_REVISE_TMP = work)
dir.create(file.path(work, "02_data_raw"), recursive = TRUE, showWarnings = FALSE)

steps <- c(
  "audit_targets.R",
  "01_preprocess_and_sensitivity.R",
  "02_nested_ml_analysis.R",
  "03_audit_ml_results.R",
  "04_enrichment_analysis.R",
  "05_make_figures.R",
  "06_strict_four_algorithm_intersection.R",
  "07_strict4_downstream_and_figures.R"
)

cat("PFOS_MI_INPUT_ROOT=", Sys.getenv("PFOS_MI_INPUT_ROOT"), "\n", sep = "")
cat("PFOS_MI_WORK_ROOT=", work, "\n", sep = "")
for (step in steps) {
  cat("\n===== ", step, " =====\n", sep = "")
  source(file.path(code_dir, step), chdir = TRUE, echo = FALSE)
}
cat("\nReanalysis completed. Outputs: ", work, "\n", sep = "")
