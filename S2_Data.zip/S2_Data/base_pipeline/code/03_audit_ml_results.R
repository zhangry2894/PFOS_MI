options(stringsAsFactors = FALSE, width = 180)
work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
models <- readRDS(file.path(work, "04_results/final_models_discovery_trained.rds"))

cat("FINAL-MODEL RESAMPLING NA AUDIT\n")
cat("LASSO ROC NAs:", sum(is.na(models[["LASSO"]]$results$ROC)), "/", nrow(models[["LASSO"]]$results), "\n")
cat("RF ROC NAs:", sum(is.na(models[["RF"]]$results$ROC)), "/", nrow(models[["RF"]]$results), "\n")
cat("SVM-RFE result NA counts:\n")
print(colSums(is.na(models[["SVM-RFE"]]$results)))
cat("XGBoost CV mean ROC NAs:", sum(is.na(models[["XGBoost"]]$cv_results$mean_ROC)), "/", nrow(models[["XGBoost"]]$cv_results), "\n")

de <- read.csv(file.path(work, "04_results/limma_all_genes_all_cohorts.csv"))
top5 <- scan(file.path(work, "03_data_processed/prioritized_top5_genes_discovery_only.txt"), what = character(), quiet = TRUE)
top5_de <- de[de$gene %in% top5, c("cohort", "gene", "logFC", "P.Value", "adj.P.Val")]
write.csv(top5_de, file.path(work, "04_results/prioritized_top5_validation.csv"), row.names = FALSE)
cat("\nDISCOVERY-ONLY TOP-FIVE VALIDATION\n")
print(top5_de)

rank <- read.csv(file.path(work, "04_results/ensemble_feature_ranking.csv"))
orig <- c("ALDH2", "CCR2", "PDE4B", "STAT3", "TGFBR1")
cat("\nORIGINAL FIVE POSITIONS IN NEW RANKING\n")
print(rank[rank$gene %in% orig, ])

perf <- read.csv(file.path(work, "04_results/model_performance.csv"))
cat("\nPERFORMANCE RANGE BY COHORT\n")
print(aggregate(ROC_AUC ~ cohort, perf, range))
