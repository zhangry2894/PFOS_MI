options(stringsAsFactors = FALSE, width = 220)
set.seed(20260915)

suppressPackageStartupMessages({
  library(caret)
  library(glmnet)
  library(randomForest)
  library(xgboost)
  library(Boruta)
})

work <- Sys.getenv(
  "PFOS_REVISE_TMP",
  unset = "./rerun_output"
)
stopifnot(dir.exists(work))

processed_dir <- file.path(work, "03_data_processed")
source_results_dir <- file.path(work, "04_results")
out_dir <- file.path(source_results_dir, "strict_four_algorithm")
logs_dir <- file.path(work, "08_logs")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

models_path <- file.path(source_results_dir, "final_models_discovery_trained.rds")
expr_path <- file.path(processed_dir, "GSE66360_gene_expression_RMA.rds")
meta_path <- file.path(processed_dir, "GSE66360_sample_metadata.csv")
candidate_path <- file.path(processed_dir, "candidate_genes_original_broad_200.txt")
limma_path <- file.path(source_results_dir, "limma_all_genes_all_cohorts.csv")

stopifnot(
  file.exists(models_path),
  file.exists(expr_path),
  file.exists(meta_path),
  file.exists(candidate_path),
  file.exists(limma_path)
)

models <- readRDS(models_path)
expr <- readRDS(expr_path)
meta <- read.csv(meta_path, check.names = FALSE)
candidates_listed <- unique(scan(candidate_path, what = character(), quiet = TRUE))
candidates <- sort(intersect(candidates_listed, rownames(expr)))

idx_dev <- meta$cohort == "Discovery"
stopifnot(sum(idx_dev) == 43L)
x_dev <- as.data.frame(
  t(expr[candidates, meta$sample_id[idx_dev], drop = FALSE]),
  check.names = FALSE
)
y_dev <- factor(meta$group[idx_dev], levels = c("Control", "MI"))
stopifnot(nrow(x_dev) == length(y_dev), ncol(x_dev) == length(candidates))

# The three serialized final models were fitted only in the predefined discovery
# cohort by 02_nested_ml_analysis.R. Validation labels were not used for tuning.
lasso_coef <- as.matrix(
  coef(models[["LASSO"]]$finalModel, s = models[["LASSO"]]$bestTune$lambda)
)
lasso_selected <- sort(setdiff(
  rownames(lasso_coef)[lasso_coef[, 1] != 0],
  "(Intercept)"
))

svm_selected <- sort(predictors(models[["SVM-RFE"]]))

xgb_importance <- xgb.importance(model = models[["XGBoost"]]$model)
xgb_feature_col <- if ("Features" %in% names(xgb_importance)) "Features" else "Feature"
xgb_selected <- sort(xgb_importance[[xgb_feature_col]][xgb_importance$Gain > 0])

# Boruta is used instead of an arbitrary RF top-k threshold. The primary result
# uses a locked seed and only Confirmed attributes; Tentative attributes are not
# counted as selected. Repeated seeds quantify the random-forest selection
# stability without consulting either validation cohort.
boruta_seeds <- 20260915L + 0:29
boruta_records <- vector("list", length(boruta_seeds))
boruta_primary <- NULL

cat("Running Boruta across", length(boruta_seeds), "locked seeds...\n")
for (i in seq_along(boruta_seeds)) {
  set.seed(boruta_seeds[i])
  fit <- Boruta(
    x = x_dev,
    y = y_dev,
    maxRuns = 500,
    doTrace = 0,
    holdHistory = TRUE,
    getImp = getImpRfZ
  )
  stats_i <- attStats(fit)
  stats_i$gene <- rownames(stats_i)
  stats_i$seed <- boruta_seeds[i]
  boruta_records[[i]] <- stats_i[, c(
    "gene", "seed", "meanImp", "medianImp", "minImp", "maxImp",
    "normHits", "decision"
  )]
  if (i == 1L) boruta_primary <- fit
  cat(sprintf("  seed %d: confirmed=%d, tentative=%d, rejected=%d\n",
              boruta_seeds[i],
              sum(stats_i$decision == "Confirmed"),
              sum(stats_i$decision == "Tentative"),
              sum(stats_i$decision == "Rejected")))
}

boruta_long <- do.call(rbind, boruta_records)
boruta_primary_stats <- attStats(boruta_primary)
boruta_primary_stats$gene <- rownames(boruta_primary_stats)
boruta_primary_stats <- boruta_primary_stats[, c(
  "gene", "meanImp", "medianImp", "minImp", "maxImp", "normHits", "decision"
)]
boruta_primary_stats <- boruta_primary_stats[
  order(match(boruta_primary_stats$decision, c("Confirmed", "Tentative", "Rejected")),
        -boruta_primary_stats$medianImp,
        boruta_primary_stats$gene),
]
boruta_selected <- sort(getSelectedAttributes(boruta_primary, withTentative = FALSE))

boruta_stability <- aggregate(
  cbind(
    confirmed = as.integer(boruta_long$decision == "Confirmed"),
    tentative = as.integer(boruta_long$decision == "Tentative")
  ) ~ gene,
  data = boruta_long,
  FUN = mean
)
names(boruta_stability)[names(boruta_stability) == "confirmed"] <- "confirmed_frequency"
names(boruta_stability)[names(boruta_stability) == "tentative"] <- "tentative_frequency"
boruta_stability <- boruta_stability[order(-boruta_stability$confirmed_frequency,
                                           -boruta_stability$tentative_frequency,
                                           boruta_stability$gene), ]

selection_sets <- list(
  LASSO = lasso_selected,
  `SVM-RFE` = svm_selected,
  Boruta = boruta_selected,
  XGBoost = xgb_selected
)
strict_core <- sort(Reduce(intersect, selection_sets))

membership <- data.frame(gene = candidates, stringsAsFactors = FALSE)
membership$LASSO <- as.integer(membership$gene %in% lasso_selected)
membership$SVM_RFE <- as.integer(membership$gene %in% svm_selected)
membership$Boruta <- as.integer(membership$gene %in% boruta_selected)
membership$XGBoost <- as.integer(membership$gene %in% xgb_selected)
membership$n_algorithms <- rowSums(membership[, c("LASSO", "SVM_RFE", "Boruta", "XGBoost")])
membership$strict_four_algorithm_core <- as.integer(membership$n_algorithms == 4L)
membership <- merge(membership, boruta_stability, by = "gene", all.x = TRUE, sort = FALSE)
membership <- membership[order(-membership$n_algorithms,
                               -membership$confirmed_frequency,
                               membership$gene), ]

selection_long <- do.call(rbind, lapply(names(selection_sets), function(method) {
  data.frame(method = method, gene = selection_sets[[method]], stringsAsFactors = FALSE)
}))
selection_summary <- data.frame(
  method = names(selection_sets),
  selection_rule = c(
    "non-zero coefficient at the locked cross-validated lambda",
    "predictors in the locked cross-validated optimal RFE subset",
    "Confirmed by Boruta at the primary locked seed; Tentative excluded",
    "non-zero Gain in the locked tuned discovery-only model"
  ),
  n_selected = vapply(selection_sets, length, integer(1)),
  selected_genes = vapply(selection_sets, function(z) paste(z, collapse = ";"), character(1)),
  stringsAsFactors = FALSE
)

limma <- read.csv(limma_path, check.names = FALSE)
core_validation <- limma[limma$gene %in% strict_core,
                          intersect(c("cohort", "gene", "logFC", "AveExpr", "t", "P.Value", "adj.P.Val", "B"), names(limma)),
                          drop = FALSE]
core_validation$direction <- ifelse(core_validation$logFC > 0, "higher_in_MI", "lower_in_MI")
cohort_order <- c(
  "GSE66360_discovery", "GSE66360_validation",
  "GSE66360_all_descriptive", "GSE48060_external"
)
core_validation <- core_validation[order(match(core_validation$cohort, cohort_order),
                                         core_validation$gene), ]

write.csv(selection_long,
          file.path(out_dir, "algorithm_selected_genes_long.csv"), row.names = FALSE)
write.csv(selection_summary,
          file.path(out_dir, "algorithm_selection_summary.csv"), row.names = FALSE)
write.csv(membership,
          file.path(out_dir, "four_algorithm_membership_all_candidates.csv"), row.names = FALSE)
write.csv(boruta_primary_stats,
          file.path(out_dir, "boruta_primary_attribute_statistics.csv"), row.names = FALSE)
write.csv(boruta_long,
          file.path(out_dir, "boruta_all_seed_decisions.csv"), row.names = FALSE)
write.csv(boruta_stability,
          file.path(out_dir, "boruta_30_seed_stability.csv"), row.names = FALSE)
write.csv(core_validation,
          file.path(out_dir, "strict_core_external_expression_validation.csv"), row.names = FALSE)
writeLines(strict_core,
           file.path(out_dir, "strict_four_algorithm_core_genes.txt"))
saveRDS(boruta_primary,
        file.path(out_dir, "boruta_primary_discovery_fit.rds"), compress = "xz")

manifest <- c(
  "Analysis: strict four-algorithm intersection for PFOS-MI candidate genes",
  sprintf("Run date: %s", Sys.Date()),
  "Discovery cohort: predefined GSE66360 discovery subset only",
  sprintf("Discovery samples: %d (Control=%d, MI=%d)",
          length(y_dev), sum(y_dev == "Control"), sum(y_dev == "MI")),
  sprintf("Candidate genes listed/present: %d/%d", length(candidates_listed), length(candidates)),
  "Algorithms: LASSO, SVM-RFE, Boruta, XGBoost",
  "Intersection rule: selected by all four algorithms",
  "Validation cohorts were not used for feature selection or tuning.",
  sprintf("Strict core count: %d", length(strict_core)),
  sprintf("Strict core genes: %s", paste(strict_core, collapse = ", "))
)
writeLines(manifest, file.path(out_dir, "analysis_manifest.txt"))
writeLines(capture.output(sessionInfo()),
           file.path(logs_dir, "R_sessionInfo_after_strict_four_algorithm.txt"))

cat("\nALGORITHM SELECTION COUNTS\n")
print(selection_summary[, c("method", "n_selected", "selection_rule")], row.names = FALSE)
cat("\nSTRICT FOUR-ALGORITHM CORE\n")
print(strict_core)
cat("\nBORUTA CONFIRMATION FREQUENCY FOR STRICT CORE\n")
print(boruta_stability[boruta_stability$gene %in% strict_core, ], row.names = FALSE)
cat("\nEXPRESSION VALIDATION FOR STRICT CORE\n")
print(core_validation, row.names = FALSE)
