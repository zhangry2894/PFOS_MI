options(stringsAsFactors = FALSE, width = 220)
set.seed(20260915)

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(pROC)
})

work <- Sys.getenv(
  "PFOS_REVISE_TMP",
  unset = "./rerun_output"
)
stopifnot(dir.exists(work))

results_dir <- file.path(work, "04_results")
strict_dir <- file.path(results_dir, "strict_four_algorithm")
processed_dir <- file.path(work, "03_data_processed")
fig_dir <- file.path(work, "05_figures")
source_dir <- file.path(work, "09_supplementary", "source_data")
logs_dir <- file.path(work, "08_logs")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

required_files <- c(
  file.path(strict_dir, "four_algorithm_membership_all_candidates.csv"),
  file.path(strict_dir, "strict_core_external_expression_validation.csv"),
  file.path(strict_dir, "strict_four_algorithm_core_genes.txt"),
  file.path(results_dir, "GSE66360_validation_model_predictions.csv"),
  file.path(results_dir, "GSE48060_external_model_predictions.csv"),
  file.path(results_dir, "model_performance.csv"),
  file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"),
  file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"),
  file.path(processed_dir, "GSE66360_sample_metadata.csv"),
  file.path(processed_dir, "GSE48060_sample_metadata.csv")
)
stopifnot(all(file.exists(required_files)))

palette_contract <- c(
  neutral_dark = "#242424",
  neutral_mid = "#737373",
  neutral_light = "#D9D9D9",
  signal_blue = "#2C7FB8",
  signal_teal = "#2A9D8F",
  accent_orange = "#E69F00",
  accent_red = "#C94C4C",
  accent_purple = "#7B6FD0"
)
model_colors <- c(
  LASSO = "#2C7FB8",
  RF = "#2A9D8F",
  `SVM-RFE` = "#E69F00",
  XGBoost = "#7B6FD0",
  Ensemble = "#C94C4C"
)

theme_pub <- function(base_size = 7, base_family = "Arial") {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.text = element_text(size = base_size - 0.1, face = "bold"),
      strip.background = element_rect(fill = "#F2F2F2", colour = "#BDBDBD", linewidth = 0.3),
      plot.title = element_text(size = base_size + 0.6, face = "bold"),
      plot.subtitle = element_text(size = base_size - 0.2, colour = "#4D4D4D"),
      plot.tag = element_text(size = 8, face = "bold"),
      panel.grid = element_blank()
    )
}
theme_set(theme_pub())

save_pub_r <- function(plot, filename, width_mm, height_mm, dpi = 600) {
  w <- width_mm / 25.4
  h <- height_mm / 25.4
  svglite::svglite(paste0(filename, ".svg"), width = w, height = h, bg = "white")
  print(plot)
  dev.off()
  # Retain an editable-text PDF and also provide a path-based journal PDF.
  # The latter avoids false 1-pt font flags caused by Cairo's text transform.
  grDevices::cairo_pdf(paste0(filename, "_editable_text.pdf"), width = w, height = h, family = "Arial", bg = "white")
  print(plot)
  dev.off()
  rsvg::rsvg_pdf(paste0(filename, ".svg"), file = paste0(filename, ".pdf"))
  ragg::agg_tiff(
    paste0(filename, ".tiff"), width = w, height = h, units = "in",
    res = dpi, compression = "lzw", background = "white"
  )
  print(plot)
  dev.off()
  ragg::agg_png(
    paste0(filename, "_preview.png"), width = w, height = h,
    units = "in", res = 300, background = "white"
  )
  print(plot)
  dev.off()
}

make_ensemble <- function(pred_df) {
  z <- reshape(pred_df, idvar = c("sample_id", "truth"), timevar = "algorithm", direction = "wide")
  prob_cols <- grep("^probability_MI\\.", names(z), value = TRUE)
  data.frame(
    sample_id = z$sample_id,
    truth = z$truth,
    algorithm = "Ensemble",
    probability_MI = rowMeans(z[prob_cols])
  )
}

# -----------------------------------------------------------------------------
# Descriptive single-gene transportability analysis.
# The sign learned in discovery is locked before validation. An AUC below 0.5
# therefore represents direction reversal rather than being silently flipped.
# -----------------------------------------------------------------------------
strict_core <- scan(
  file.path(strict_dir, "strict_four_algorithm_core_genes.txt"),
  what = character(), quiet = TRUE
)
stopifnot(identical(sort(strict_core), sort(c("CSK", "MMP9", "PDE4B", "PLAT", "TGFBR1"))))

de_core <- read.csv(
  file.path(strict_dir, "strict_core_external_expression_validation.csv"),
  check.names = FALSE
)
expr66360 <- readRDS(file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"))
expr48060 <- readRDS(file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"))
meta66360 <- read.csv(file.path(processed_dir, "GSE66360_sample_metadata.csv"), check.names = FALSE)
meta48060 <- read.csv(file.path(processed_dir, "GSE48060_sample_metadata.csv"), check.names = FALSE)

discovery_sign <- setNames(
  sign(de_core$logFC[de_core$cohort == "GSE66360_discovery"]),
  de_core$gene[de_core$cohort == "GSE66360_discovery"]
)

gene_auc_one <- function(expr, meta, sample_index, cohort_label, gene) {
  ids <- meta$sample_id[sample_index]
  truth <- factor(meta$group[sample_index], levels = c("Control", "MI"))
  oriented_score <- as.numeric(expr[gene, ids]) * discovery_sign[[gene]]
  roc_fit <- roc(truth, oriented_score, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  ci_fit <- ci.auc(roc_fit, conf.level = 0.95, method = "delong")
  data.frame(
    cohort = cohort_label,
    gene = gene,
    discovery_direction = ifelse(discovery_sign[[gene]] > 0, "higher_in_MI", "lower_in_MI"),
    n_control = sum(truth == "Control"),
    n_MI = sum(truth == "MI"),
    discovery_oriented_AUC = as.numeric(auc(roc_fit)),
    AUC_CI_low = as.numeric(ci_fit[1]),
    AUC_CI_high = as.numeric(ci_fit[3])
  )
}

cohort_specs <- list(
  list(expr = expr66360, meta = meta66360, idx = meta66360$cohort == "Discovery", label = "GSE66360_discovery"),
  list(expr = expr66360, meta = meta66360, idx = meta66360$cohort == "Validation", label = "GSE66360_validation"),
  list(expr = expr48060, meta = meta48060, idx = rep(TRUE, nrow(meta48060)), label = "GSE48060_external")
)
gene_auc <- do.call(rbind, lapply(cohort_specs, function(spec) {
  do.call(rbind, lapply(strict_core, function(gene) {
    gene_auc_one(spec$expr, spec$meta, spec$idx, spec$label, gene)
  }))
}))
write.csv(gene_auc, file.path(strict_dir, "strict_core_single_gene_auc.csv"), row.names = FALSE)

replication <- merge(
  de_core[de_core$cohort %in% c("GSE66360_discovery", "GSE66360_validation", "GSE48060_external"), ],
  data.frame(gene = names(discovery_sign), discovery_sign = as.numeric(discovery_sign)),
  by = "gene", all.x = TRUE
)
replication$same_direction_as_discovery <- sign(replication$logFC) == replication$discovery_sign
replication$FDR_significant <- replication$adj.P.Val < 0.05
replication$concordant_FDR_replication <- replication$same_direction_as_discovery & replication$FDR_significant
replication <- replication[order(match(replication$cohort, c(
  "GSE66360_discovery", "GSE66360_validation", "GSE48060_external"
)), match(replication$gene, strict_core)), ]
write.csv(replication, file.path(strict_dir, "strict_core_replication_flags.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# Figure 2: strict four-method consensus and model transportability.
# -----------------------------------------------------------------------------
membership <- read.csv(
  file.path(strict_dir, "four_algorithm_membership_all_candidates.csv"),
  check.names = FALSE
)
display_membership <- membership[membership$n_algorithms >= 3, ]
display_membership$core_label <- ifelse(
  display_membership$strict_four_algorithm_core == 1,
  paste0(display_membership$gene, " *"),
  display_membership$gene
)
display_membership <- display_membership[order(
  -display_membership$strict_four_algorithm_core,
  -display_membership$n_algorithms,
  display_membership$gene
), ]

method_cols <- c("LASSO", "SVM_RFE", "Boruta", "XGBoost")
membership_long <- do.call(rbind, lapply(method_cols, function(method) {
  data.frame(
    gene = display_membership$gene,
    core_label = display_membership$core_label,
    strict_core = display_membership$strict_four_algorithm_core,
    method = method,
    selected = display_membership[[method]],
    stringsAsFactors = FALSE
  )
}))
membership_long$method <- factor(
  membership_long$method,
  levels = method_cols,
  labels = c("LASSO", "SVM-RFE", "Boruta", "XGBoost")
)
membership_long$core_label <- factor(
  membership_long$core_label,
  levels = rev(display_membership$core_label)
)
write.csv(membership_long, file.path(source_dir, "Figure2_strict_method_membership.csv"), row.names = FALSE)

set_sizes <- c(
  LASSO = sum(membership$LASSO == 1),
  `SVM-RFE` = sum(membership$SVM_RFE == 1),
  Boruta = sum(membership$Boruta == 1),
  XGBoost = sum(membership$XGBoost == 1)
)
set_size_text <- paste(sprintf("%s %d", names(set_sizes), set_sizes), collapse = "; ")

p2a <- ggplot(membership_long, aes(method, core_label, fill = factor(selected))) +
  geom_tile(colour = "white", linewidth = 0.55) +
  scale_fill_manual(values = c(`0` = "#E8E8E8", `1` = unname(palette_contract["signal_blue"])), guide = "none") +
  labs(
    x = NULL, y = NULL,
    title = "Four-method feature consensus",
    subtitle = paste0(
      set_size_text,
      "\nGenes shown: selected by 3 or 4 methods; * strict four-way intersection"
    )
  ) +
  theme_minimal(base_family = "Arial", base_size = 7) +
  theme(
    panel.grid = element_blank(),
    axis.text.x = element_text(angle = 35, hjust = 1, colour = "black"),
    axis.text.y = element_text(colour = "black"),
    plot.subtitle = element_text(size = 5.7, lineheight = 0.95)
  )

val_pred <- read.csv(file.path(results_dir, "GSE66360_validation_model_predictions.csv"), check.names = FALSE)
ext_pred <- read.csv(file.path(results_dir, "GSE48060_external_model_predictions.csv"), check.names = FALSE)
val_pred <- rbind(val_pred, make_ensemble(val_pred))
ext_pred <- rbind(ext_pred, make_ensemble(ext_pred))
write.csv(val_pred, file.path(source_dir, "Figure2_GSE66360_validation_predictions.csv"), row.names = FALSE)
write.csv(ext_pred, file.path(source_dir, "Figure2_GSE48060_external_predictions.csv"), row.names = FALSE)

roc_df <- function(pred, cohort) {
  do.call(rbind, lapply(split(pred, pred$algorithm), function(d) {
    r <- roc(d$truth, d$probability_MI, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
    crd <- coords(r, x = "all", ret = c("specificity", "sensitivity"), transpose = FALSE)
    data.frame(
      algorithm = unique(d$algorithm), cohort = cohort,
      FPR = 1 - crd$specificity, TPR = crd$sensitivity
    )
  }))
}
roc_points <- rbind(
  roc_df(val_pred, "GSE66360 predefined validation"),
  roc_df(ext_pred, "GSE48060 external validation")
)
write.csv(roc_points, file.path(source_dir, "Figure2_ROC_coordinates.csv"), row.names = FALSE)

plot_roc <- function(df, title) {
  ggplot(df, aes(FPR, TPR, colour = algorithm)) +
    geom_abline(slope = 1, intercept = 0, linetype = 2, linewidth = 0.35, colour = palette_contract["neutral_mid"]) +
    geom_path(linewidth = 0.65) +
    scale_colour_manual(values = model_colors) +
    coord_equal(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
    labs(x = "1 - specificity", y = "Sensitivity", colour = NULL, title = title) +
    theme(legend.position = "bottom", legend.key.width = grid::unit(3.0, "mm"))
}
p2b <- plot_roc(
  roc_points[roc_points$cohort == "GSE66360 predefined validation", ],
  "Predefined validation (n = 56)"
)
p2c <- plot_roc(
  roc_points[roc_points$cohort == "GSE48060 external validation", ],
  "External whole blood (n = 52)"
)

perf <- read.csv(file.path(results_dir, "model_performance.csv"), check.names = FALSE)
perf$cohort_short <- factor(
  perf$cohort,
  levels = c(
    "GSE66360_discovery_repeated_nested_CV",
    "GSE66360_predefined_validation",
    "GSE48060_external"
  ),
  labels = c("Nested CV", "Predefined validation", "External whole blood")
)
perf$algorithm <- factor(perf$algorithm, levels = rev(names(model_colors)))
write.csv(perf, file.path(source_dir, "Figure2_model_performance.csv"), row.names = FALSE)
p2d <- ggplot(perf, aes(ROC_AUC, algorithm, colour = algorithm)) +
  geom_vline(xintercept = 0.5, linetype = 2, linewidth = 0.35, colour = palette_contract["neutral_mid"]) +
  geom_errorbar(aes(xmin = AUC_CI_low, xmax = AUC_CI_high), orientation = "y", width = 0.18, linewidth = 0.45) +
  geom_point(size = 1.75) +
  facet_wrap(~ cohort_short, ncol = 1) +
  scale_colour_manual(values = model_colors, guide = "none") +
  scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.25)) +
  labs(x = "ROC AUC (95% DeLong CI)", y = NULL, title = "AUC across cohorts")

fig2 <- (p2a | (p2b / p2c) | p2d) +
  plot_layout(widths = c(1.05, 1.15, 0.90), guides = "collect") +
  plot_annotation(tag_levels = "a") &
  theme(legend.position = "bottom")
save_pub_r(
  fig2,
  file.path(fig_dir, "Figure2_strict_consensus_and_transportability"),
  width_mm = 183, height_mm = 145
)

# -----------------------------------------------------------------------------
# Figure 3: sample-level expression of strict consensus candidates.
# -----------------------------------------------------------------------------
long_expr <- function(expr, meta, sample_idx, cohort_label) {
  m <- expr[strict_core, meta$sample_id[sample_idx], drop = FALSE]
  data.frame(
    gene = rep(rownames(m), times = ncol(m)),
    sample_id = rep(colnames(m), each = nrow(m)),
    expression = as.vector(m),
    group = rep(meta$group[sample_idx], each = nrow(m)),
    cohort = cohort_label
  )
}
expr_long <- rbind(
  long_expr(expr66360, meta66360, meta66360$cohort == "Discovery", "GSE66360 discovery"),
  long_expr(expr66360, meta66360, meta66360$cohort == "Validation", "GSE66360 predefined validation"),
  long_expr(expr48060, meta48060, rep(TRUE, nrow(meta48060)), "GSE48060 external whole blood")
)
expr_long$gene <- factor(expr_long$gene, levels = strict_core)
expr_long$group <- factor(expr_long$group, levels = c("Control", "MI"))
write.csv(expr_long, file.path(source_dir, "Figure3_strict_core_sample_level_expression.csv"), row.names = FALSE)

cohort_map <- c(
  "GSE66360 discovery" = "GSE66360_discovery",
  "GSE66360 predefined validation" = "GSE66360_validation",
  "GSE48060 external whole blood" = "GSE48060_external"
)
plot_expression <- function(label, title) {
  z <- expr_long[expr_long$cohort == label, ]
  ann <- de_core[de_core$cohort == cohort_map[[label]], ]
  ann$gene <- factor(ann$gene, levels = strict_core)
  ann$label <- sprintf(
    "log2FC %+.2f\nq = %s",
    ann$logFC,
    format.pval(ann$adj.P.Val, digits = 2, eps = 1e-4)
  )
  ggplot(z, aes(group, expression, fill = group, colour = group)) +
    geom_violin(width = 0.88, alpha = 0.22, linewidth = 0.3, trim = FALSE) +
    geom_boxplot(width = 0.36, outlier.shape = NA, alpha = 0.65, linewidth = 0.35) +
    geom_point(
      position = position_jitter(width = 0.11, height = 0, seed = 20260915),
      size = 0.75, alpha = 0.72
    ) +
    geom_text(
      data = ann, aes(x = 1.5, y = Inf, label = label),
      inherit.aes = FALSE, vjust = 1.05, size = 2.0,
      lineheight = 0.92, family = "Arial"
    ) +
    facet_wrap(~ gene, nrow = 1, scales = "free_y") +
    scale_fill_manual(values = c(Control = "#BDBDBD", MI = palette_contract["accent_red"])) +
    scale_colour_manual(values = c(Control = "#606060", MI = "#9C2F2F")) +
    labs(x = NULL, y = "RMA expression (log2)", title = title) +
    theme(
      legend.position = "none",
      axis.text.x = element_text(angle = 0),
      panel.spacing.x = grid::unit(1.2, "mm")
    )
}
p3a <- plot_expression("GSE66360 discovery", "Development cohort: 21 MI and 22 controls")
p3b <- plot_expression("GSE66360 predefined validation", "Predefined validation: 28 MI and 28 controls")
p3c <- plot_expression("GSE48060 external whole blood", "External cohort: 31 MI and 21 controls")
fig3 <- p3a / p3b / p3c + plot_annotation(tag_levels = "a")
save_pub_r(
  fig3,
  file.path(fig_dir, "Figure3_strict_core_gene_replication"),
  width_mm = 183, height_mm = 175
)

analysis_summary <- c(
  "Strict four-algorithm downstream analysis",
  sprintf("Run date: %s", Sys.Date()),
  sprintf("Strict consensus candidates (%d): %s", length(strict_core), paste(strict_core, collapse = ", ")),
  sprintf(
    "Predefined validation concordant q<0.05 genes: %s",
    paste(replication$gene[
      replication$cohort == "GSE66360_validation" & replication$concordant_FDR_replication
    ], collapse = ", ")
  ),
  sprintf(
    "External validation concordant q<0.05 genes: %s",
    paste(replication$gene[
      replication$cohort == "GSE48060_external" & replication$concordant_FDR_replication
    ], collapse = ", ")
  ),
  "AUCs are discovery-direction locked; values below 0.5 indicate direction reversal.",
  "No validation label was used for feature selection or tuning."
)
writeLines(analysis_summary, file.path(strict_dir, "strict4_downstream_summary.txt"))
writeLines(
  capture.output(sessionInfo()),
  file.path(logs_dir, "R_sessionInfo_after_strict4_downstream_figures.txt")
)

cat(paste(analysis_summary, collapse = "\n"), "\n")
cat("Figures exported to", fig_dir, "\n")
