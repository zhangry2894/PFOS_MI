options(stringsAsFactors = FALSE, width = 180)
set.seed(20260914)

suppressPackageStartupMessages({
  library(ggplot2)
  library(patchwork)
  library(pROC)
  library(scales)
})

work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
results_dir <- file.path(work, "04_results")
fig_dir <- file.path(work, "05_figures")
source_dir <- file.path(work, "09_supplementary", "source_data")
logs_dir <- file.path(work, "08_logs")
dir.create(fig_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(source_dir, recursive = TRUE, showWarnings = FALSE)

palette_contract <- c(
  neutral_dark = "#242424",
  neutral_mid = "#737373",
  neutral_light = "#D9D9D9",
  signal_blue = "#2C7FB8",
  signal_teal = "#2A9D8F",
  accent_orange = "#E69F00",
  accent_red = "#C94C4C",
  accent_purple = "#7B6FD0"
)

model_colors <- c(
  LASSO = "#2C7FB8",
  RF = "#2A9D8F",
  `SVM-RFE` = "#E69F00",
  XGBoost = "#7B6FD0",
  Ensemble = "#C94C4C"
)

theme_pub <- function(base_size = 7, base_family = "Arial") {
  theme_classic(base_size = base_size, base_family = base_family) +
    theme(
      axis.line = element_line(linewidth = 0.35, colour = "black"),
      axis.ticks = element_line(linewidth = 0.35, colour = "black"),
      axis.title = element_text(size = base_size),
      axis.text = element_text(size = base_size - 0.3, colour = "black"),
      legend.title = element_text(size = base_size - 0.2),
      legend.text = element_text(size = base_size - 0.5),
      strip.text = element_text(size = base_size - 0.1, face = "bold"),
      strip.background = element_rect(fill = "#F2F2F2", colour = "#BDBDBD", linewidth = 0.3),
      plot.title = element_text(size = base_size + 0.6, face = "bold"),
      plot.tag = element_text(size = 8, face = "bold"),
      panel.grid = element_blank()
    )
}

theme_set(theme_pub())

save_pub_r <- function(plot, filename, width_mm, height_mm, dpi = 600) {
  w <- width_mm / 25.4
  h <- height_mm / 25.4
  svglite::svglite(paste0(filename, ".svg"), width = w, height = h, bg = "white")
  print(plot)
  dev.off()
  grDevices::cairo_pdf(paste0(filename, ".pdf"), width = w, height = h, family = "Arial", bg = "white")
  print(plot)
  dev.off()
  ragg::agg_tiff(paste0(filename, ".tiff"), width = w, height = h, units = "in", res = dpi, compression = "lzw", background = "white")
  print(plot)
  dev.off()
  ragg::agg_png(paste0(filename, "_preview.png"), width = w, height = h, units = "in", res = 300, background = "white")
  print(plot)
  dev.off()
}

make_ensemble <- function(pred_df) {
  z <- reshape(pred_df, idvar = c("sample_id", "truth"), timevar = "algorithm", direction = "wide")
  prob_cols <- grep("^probability_MI\\.", names(z), value = TRUE)
  data.frame(sample_id = z$sample_id, truth = z$truth, algorithm = "Ensemble", probability_MI = rowMeans(z[prob_cols]))
}

# Figure 1: workflow and target-threshold sensitivity.
target <- read.csv(file.path(results_dir, "PFOS_target_evidence_and_tiers.csv"), check.names = FALSE)
sens <- read.csv(file.path(results_dir, "target_threshold_sensitivity.csv"), check.names = FALSE)
meta66360 <- read.csv(file.path(work, "03_data_processed", "GSE66360_sample_metadata.csv"), check.names = FALSE)
meta48060 <- read.csv(file.path(work, "03_data_processed", "GSE48060_sample_metadata.csv"), check.names = FALSE)

workflow_boxes <- data.frame(
  xmin = c(0.2, 2.3, 4.4, 6.5, 8.6), xmax = c(1.8, 3.9, 6.0, 8.1, 10.2),
  ymin = 0.25, ymax = 1.45,
  label = c(
    "PFOS target\nprediction\n5 sources",
    "MI gene\nretrieval\nGeneCards + OMIM",
    "Candidate set\n201 broad\n197 measured",
    "Model development\nGSE66360 discovery\nn = 43",
    "Locked validation\nGSE66360 n = 56\nGSE48060 n = 52"
  ),
  fill = c("#E8F2F8", "#E8F2F8", "#E6F3F1", "#FFF0D5", "#F4EAF6")
)
p1a <- ggplot() +
  geom_rect(data = workflow_boxes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill), colour = "#4D4D4D", linewidth = 0.4) +
  geom_text(data = workflow_boxes, aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label), size = 2.35, lineheight = 0.95, family = "Arial") +
  geom_segment(data = data.frame(x = c(1.83, 3.93, 6.03, 8.13), xend = c(2.25, 4.35, 6.45, 8.55)), aes(x = x, xend = xend, y = 0.85, yend = 0.85), arrow = arrow(length = grid::unit(1.5, "mm")), linewidth = 0.45) +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0, 10.4), ylim = c(0, 1.7), clip = "off") +
  theme_void(base_family = "Arial", base_size = 7) +
  labs(title = "Analysis design with prespecified cohort separation") +
  theme(plot.title = element_text(size = 7.6, face = "bold", margin = margin(b = 3)))

source_map <- data.frame(
  source = c("SuperPred", "PharmMapper", "SwissTargetPrediction", "STITCH", "TargetNet"),
  present_col = c("superpred_present", "pharmmapper_present", "swisstargetprediction_present", "stitch_present", "targetnet_present"),
  high_col = c("superpred_high_confidence", "pharmmapper_high_confidence", "swisstargetprediction_high_confidence", "stitch_high_confidence", "targetnet_high_confidence")
)
source_counts <- do.call(rbind, lapply(seq_len(nrow(source_map)), function(i) {
  data.frame(
    source = source_map$source[i],
    tier = c("All positive/predicted", "Source-specific high confidence"),
    n = c(sum(target[[source_map$present_col[i]]]), sum(target[[source_map$high_col[i]]]))
  )
}))
source_counts$source <- factor(source_counts$source, levels = rev(source_map$source))
source_counts$tier <- factor(source_counts$tier, levels = c("All positive/predicted", "Source-specific high confidence"))
write.csv(source_counts, file.path(source_dir, "Figure1_source_counts.csv"), row.names = FALSE)

p1b <- ggplot(source_counts, aes(n, source, fill = tier)) +
  geom_col(position = position_dodge2(width = 0.72, preserve = "single"), width = 0.64) +
  geom_text(aes(label = n), position = position_dodge2(width = 0.72, preserve = "single"), hjust = -0.12, size = 2.05, family = "Arial") +
  scale_fill_manual(values = c("All positive/predicted" = unname(palette_contract["neutral_mid"]), "Source-specific high confidence" = unname(palette_contract["signal_blue"]))) +
  scale_x_continuous(expand = expansion(mult = c(0, 0.14))) +
  labs(x = "Unique human gene targets", y = NULL, fill = NULL, title = "Database-specific target counts") +
  theme(legend.position = "bottom", legend.key.width = grid::unit(3.3, "mm"))

pfos_labels <- c(
  Original_broad = "Original broad\n(n = 423)",
  High_confidence_any = "High-confidence any\n(n = 141)",
  Consensus_2plus = "Two-source consensus\n(n = 74)"
)
disease_labels <- c(
  Original_2841 = "Original\n2,841",
  GeneCards_median_plus_OMIM = "GC median\n+ OMIM",
  GeneCards_score_gt5_plus_OMIM = "GC >5\n+ OMIM",
  GeneCards_top10pct_plus_OMIM = "GC top 10%\n+ OMIM"
)
sens$pfos_label <- factor(unname(pfos_labels[sens$pfos_tier]), levels = unname(pfos_labels))
sens$disease_label <- factor(unname(disease_labels[sens$disease_tier]), levels = unname(disease_labels))
write.csv(sens, file.path(source_dir, "Figure1_threshold_sensitivity.csv"), row.names = FALSE)

p1c <- ggplot(sens, aes(disease_label, pfos_label, fill = n_overlap)) +
  geom_tile(colour = "white", linewidth = 0.7) +
  geom_text(aes(label = n_overlap), size = 2.55, fontface = "bold", family = "Arial") +
  scale_fill_gradient(low = "#EFF6FA", high = palette_contract["signal_blue"], trans = "sqrt") +
  labs(x = "MI-gene definition", y = "PFOS-target definition", fill = "Overlap\ncount", title = "Candidate-set sensitivity to evidence thresholds") +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5), legend.position = "right")

fig1 <- p1a / (p1b | p1c) + plot_layout(heights = c(0.62, 1), widths = c(0.9, 1.2)) + plot_annotation(tag_levels = "A")
save_pub_r(fig1, file.path(fig_dir, "Figure1_workflow_and_target_sensitivity"), width_mm = 183, height_mm = 125)

# Figure 2: model stability and generalization.
rank <- read.csv(file.path(results_dir, "ensemble_feature_ranking.csv"), check.names = FALSE)
top20 <- rank[rank$rank <= 20, ]
top20$gene <- factor(top20$gene, levels = rev(top20$gene))
write.csv(top20, file.path(source_dir, "Figure2_feature_stability.csv"), row.names = FALSE)

p2a <- ggplot(top20, aes(ensemble_score, gene)) +
  geom_col(width = 0.62, fill = palette_contract["signal_blue"], alpha = 0.88) +
  geom_point(aes(x = selection_frequency), shape = 21, fill = "white", colour = palette_contract["accent_red"], size = 1.65, stroke = 0.5) +
  scale_x_continuous(limits = c(0, 1.04), breaks = seq(0, 1, 0.25)) +
  labs(x = "Score / selection frequency", y = NULL, title = "Discovery-only feature stability", caption = "Bars: ensemble score; circles: selection frequency") +
  theme(plot.caption = element_text(size = 5.7, hjust = 0), plot.margin = margin(5.5, 5.5, 5.5, 5.5))

val_pred <- read.csv(file.path(results_dir, "GSE66360_validation_model_predictions.csv"), check.names = FALSE)
ext_pred <- read.csv(file.path(results_dir, "GSE48060_external_model_predictions.csv"), check.names = FALSE)
val_pred <- rbind(val_pred, make_ensemble(val_pred))
ext_pred <- rbind(ext_pred, make_ensemble(ext_pred))
write.csv(val_pred, file.path(source_dir, "Figure2_GSE66360_validation_predictions.csv"), row.names = FALSE)
write.csv(ext_pred, file.path(source_dir, "Figure2_GSE48060_external_predictions.csv"), row.names = FALSE)

roc_df <- function(pred, cohort) {
  do.call(rbind, lapply(split(pred, pred$algorithm), function(d) {
    r <- roc(d$truth, d$probability_MI, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
    crd <- coords(r, x = "all", ret = c("specificity", "sensitivity"), transpose = FALSE)
    data.frame(algorithm = unique(d$algorithm), cohort = cohort, FPR = 1 - crd$specificity, TPR = crd$sensitivity)
  }))
}
roc_points <- rbind(
  roc_df(val_pred, "GSE66360 predefined validation"),
  roc_df(ext_pred, "GSE48060 external validation")
)
write.csv(roc_points, file.path(source_dir, "Figure2_ROC_coordinates.csv"), row.names = FALSE)

plot_roc <- function(df, title) {
  ggplot(df, aes(FPR, TPR, colour = algorithm)) +
    geom_abline(slope = 1, intercept = 0, linetype = 2, linewidth = 0.35, colour = palette_contract["neutral_mid"]) +
    geom_path(linewidth = 0.65) +
    scale_colour_manual(values = model_colors) +
    coord_equal(xlim = c(0, 1), ylim = c(0, 1), expand = FALSE) +
    labs(x = "1 - specificity", y = "Sensitivity", colour = NULL, title = title) +
    theme(legend.position = "bottom", legend.key.width = grid::unit(3.0, "mm"))
}
p2b <- plot_roc(roc_points[roc_points$cohort == "GSE66360 predefined validation", ], "Predefined validation (n = 56)")
p2c <- plot_roc(roc_points[roc_points$cohort == "GSE48060 external validation", ], "External whole blood (n = 52)")

perf <- read.csv(file.path(results_dir, "model_performance.csv"), check.names = FALSE)
perf$cohort_short <- factor(perf$cohort, levels = c("GSE66360_discovery_repeated_nested_CV", "GSE66360_predefined_validation", "GSE48060_external"), labels = c("Nested CV", "Predefined validation", "External whole blood"))
perf$algorithm <- factor(perf$algorithm, levels = rev(names(model_colors)))
write.csv(perf, file.path(source_dir, "Figure2_model_performance.csv"), row.names = FALSE)
p2d <- ggplot(perf, aes(ROC_AUC, algorithm, colour = algorithm)) +
  geom_vline(xintercept = 0.5, linetype = 2, linewidth = 0.35, colour = palette_contract["neutral_mid"]) +
  geom_errorbarh(aes(xmin = AUC_CI_low, xmax = AUC_CI_high), height = 0.18, linewidth = 0.45) +
  geom_point(size = 1.75) +
  facet_wrap(~ cohort_short, ncol = 1) +
  scale_colour_manual(values = model_colors, guide = "none") +
  scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.25)) +
  labs(x = "ROC AUC (95% DeLong CI)", y = NULL, title = "AUC across cohorts")

fig2 <- (p2a | (p2b / p2c) | p2d) + plot_layout(widths = c(1.0, 1.15, 0.9), guides = "collect") + plot_annotation(tag_levels = "A") & theme(legend.position = "bottom")
save_pub_r(fig2, file.path(fig_dir, "Figure2_model_performance_and_transportability"), width_mm = 183, height_mm = 145)

# Figure 3: sample-level validation of the discovery-only top five.
expr66360 <- readRDS(file.path(work, "03_data_processed", "GSE66360_gene_expression_RMA.rds"))
expr48060 <- readRDS(file.path(work, "03_data_processed", "GSE48060_gene_expression_RMA.rds"))
top5 <- scan(file.path(work, "03_data_processed", "prioritized_top5_genes_discovery_only.txt"), what = character(), quiet = TRUE)
de5 <- read.csv(file.path(results_dir, "prioritized_top5_validation.csv"), check.names = FALSE)

long_expr <- function(expr, meta, sample_idx, cohort_label) {
  m <- expr[top5, meta$sample_id[sample_idx], drop = FALSE]
  z <- data.frame(
    gene = rep(rownames(m), times = ncol(m)),
    sample_id = rep(colnames(m), each = nrow(m)),
    expression = as.vector(m),
    group = rep(meta$group[sample_idx], each = nrow(m)),
    cohort = cohort_label
  )
  z
}
expr_long <- rbind(
  long_expr(expr66360, meta66360, meta66360$cohort == "Discovery", "GSE66360 discovery"),
  long_expr(expr66360, meta66360, meta66360$cohort == "Validation", "GSE66360 predefined validation"),
  long_expr(expr48060, meta48060, rep(TRUE, nrow(meta48060)), "GSE48060 external whole blood")
)
expr_long$gene <- factor(expr_long$gene, levels = top5)
expr_long$group <- factor(expr_long$group, levels = c("Control", "MI"))
write.csv(expr_long, file.path(source_dir, "Figure3_sample_level_expression.csv"), row.names = FALSE)

cohort_map <- c(
  "GSE66360 discovery" = "GSE66360_discovery",
  "GSE66360 predefined validation" = "GSE66360_validation",
  "GSE48060 external whole blood" = "GSE48060_external"
)
plot_expression <- function(label, title) {
  z <- expr_long[expr_long$cohort == label, ]
  ann <- de5[de5$cohort == cohort_map[[label]], ]
  ann$gene <- factor(ann$gene, levels = top5)
  ann$label <- sprintf("log2FC %+.2f\nq = %s", ann$logFC, format.pval(ann$adj.P.Val, digits = 2, eps = 1e-4))
  ggplot(z, aes(group, expression, fill = group, colour = group)) +
    geom_violin(width = 0.88, alpha = 0.22, linewidth = 0.3, trim = FALSE) +
    geom_boxplot(width = 0.36, outlier.shape = NA, alpha = 0.65, linewidth = 0.35) +
    geom_point(position = position_jitter(width = 0.11, height = 0, seed = 20260914), size = 0.75, alpha = 0.72) +
    geom_text(data = ann, aes(x = 1.5, y = Inf, label = label), inherit.aes = FALSE, vjust = 1.05, size = 2.0, lineheight = 0.92, family = "Arial") +
    facet_wrap(~ gene, nrow = 1, scales = "free_y") +
    scale_fill_manual(values = c(Control = "#BDBDBD", MI = palette_contract["accent_red"])) +
    scale_colour_manual(values = c(Control = "#606060", MI = "#9C2F2F")) +
    labs(x = NULL, y = "RMA expression (log2)", title = title) +
    theme(legend.position = "none", axis.text.x = element_text(angle = 0), panel.spacing.x = grid::unit(1.2, "mm"))
}
p3a <- plot_expression("GSE66360 discovery", "Development cohort: 21 MI and 22 controls")
p3b <- plot_expression("GSE66360 predefined validation", "Predefined validation: 28 MI and 28 controls")
p3c <- plot_expression("GSE48060 external whole blood", "External cohort: 31 MI and 21 controls")
fig3 <- p3a / p3b / p3c + plot_annotation(tag_levels = "A")
save_pub_r(fig3, file.path(fig_dir, "Figure3_top5_gene_replication"), width_mm = 183, height_mm = 175)

# Figure 4: evidence-bounded hypothesis framework (not a causal AOP).
boxes4 <- data.frame(
  xmin = c(0.2, 2.3, 4.4, 6.5, 8.6, 0.8, 3.15, 5.5, 7.85),
  xmax = c(1.8, 3.9, 6.0, 8.1, 10.2, 2.55, 4.9, 7.25, 9.6),
  ymin = c(rep(2.1, 5), rep(0.25, 4)), ymax = c(rep(3.35, 5), rep(1.25, 4)),
  label = c(
    "PFOS\nchemical query",
    "Predicted\nprotein associations",
    "PFOS-MI\ncandidate genes",
    "Acute-MI CEC\ntranscriptomic signal",
    "Testable hypotheses:\nredox, hypoxia,\nendothelial and inflammation",
    "Individual PFOS\nexposure not measured",
    "Target engagement\nnot demonstrated",
    "Temporal direction\nnot established",
    "Cardiac tissue and\nfunctional validation\nabsent"
  ),
  fill = c("#E8F2F8", "#E8F2F8", "#E6F3F1", "#FFF0D5", "#F4EAF6", rep("#F5F5F5", 4))
)
arrows_top <- data.frame(x = c(1.82, 3.92, 6.02, 8.12), xend = c(2.27, 4.37, 6.47, 8.57))
p4 <- ggplot() +
  geom_rect(data = boxes4, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax, fill = fill), colour = "#4D4D4D", linewidth = 0.45) +
  geom_text(data = boxes4, aes(x = (xmin + xmax) / 2, y = (ymin + ymax) / 2, label = label), size = 2.35, lineheight = 0.95, family = "Arial") +
  geom_segment(data = arrows_top, aes(x = x, xend = xend, y = 2.72, yend = 2.72), arrow = arrow(length = grid::unit(1.6, "mm")), linewidth = 0.45) +
  annotate("segment", x = 1.7, xend = 1.7, y = 1.25, yend = 2.05, linetype = 2, linewidth = 0.4, colour = palette_contract["accent_red"]) +
  annotate("segment", x = 4.02, xend = 4.8, y = 1.25, yend = 2.05, linetype = 2, linewidth = 0.4, colour = palette_contract["accent_red"]) +
  annotate("segment", x = 6.37, xend = 7.3, y = 1.25, yend = 2.05, linetype = 2, linewidth = 0.4, colour = palette_contract["accent_red"]) +
  annotate("segment", x = 8.72, xend = 9.4, y = 1.25, yend = 2.05, linetype = 2, linewidth = 0.4, colour = palette_contract["accent_red"]) +
  annotate("text", x = 5.2, y = 3.75, label = "Hypothesis-generating evidence chain", size = 2.9, fontface = "bold", family = "Arial") +
  annotate("text", x = 5.2, y = 1.58, label = "Causal evidence that remains missing", size = 2.7, fontface = "bold", colour = palette_contract["accent_red"], family = "Arial") +
  annotate("text", x = 5.2, y = -0.05, label = "This framework is not a formal adverse outcome pathway and does not establish PFOS-induced MI.", size = 2.35, fontface = "bold", family = "Arial") +
  scale_fill_identity() +
  coord_cartesian(xlim = c(0, 10.4), ylim = c(-0.2, 4.0), clip = "off") +
  theme_void(base_family = "Arial", base_size = 7)
save_pub_r(p4, file.path(fig_dir, "Figure4_evidence_bounded_hypothesis_framework"), width_mm = 183, height_mm = 105)

# Supplementary Figure S1: PCA diagnostics.
pca_df <- function(expr, meta, label, top_n = 2000) {
  vars <- apply(expr, 1, var)
  genes <- names(sort(vars, decreasing = TRUE))[seq_len(min(top_n, length(vars)))]
  pc <- prcomp(t(expr[genes, , drop = FALSE]), center = TRUE, scale. = FALSE)
  v <- 100 * pc$sdev^2 / sum(pc$sdev^2)
  data.frame(sample_id = rownames(pc$x), PC1 = pc$x[, 1], PC2 = pc$x[, 2], group = meta$group[match(rownames(pc$x), meta$sample_id)], cohort = if ("cohort" %in% names(meta)) meta$cohort[match(rownames(pc$x), meta$sample_id)] else label, dataset = label, var1 = v[1], var2 = v[2])
}
pca66360 <- pca_df(expr66360, meta66360, "GSE66360")
pca48060 <- pca_df(expr48060, meta48060, "GSE48060")
write.csv(rbind(pca66360, pca48060), file.path(source_dir, "FigureS1_PCA_coordinates.csv"), row.names = FALSE)
pS1a <- ggplot(pca66360, aes(PC1, PC2, colour = group, shape = cohort)) + geom_point(size = 1.7, alpha = 0.85) + scale_colour_manual(values = c(Control = "#606060", MI = unname(palette_contract["accent_red"]))) + labs(x = sprintf("PC1 (%.1f%%)", unique(pca66360$var1)), y = sprintf("PC2 (%.1f%%)", unique(pca66360$var2)), colour = NULL, shape = "Cohort", title = "GSE66360") + theme(legend.position = "bottom")
pS1b <- ggplot(pca48060, aes(PC1, PC2, colour = group)) + geom_point(size = 1.7, alpha = 0.85) + scale_colour_manual(values = c(Control = "#606060", MI = unname(palette_contract["accent_red"]))) + labs(x = sprintf("PC1 (%.1f%%)", unique(pca48060$var1)), y = sprintf("PC2 (%.1f%%)", unique(pca48060$var2)), colour = NULL, title = "GSE48060") + theme(legend.position = "bottom")
figS1 <- (pS1a | pS1b) + plot_annotation(tag_levels = "A")
save_pub_r(figS1, file.path(fig_dir, "FigureS1_PCA_diagnostics"), width_mm = 183, height_mm = 80)

# Supplementary Figure S2: final-model tuning curves.
models <- readRDS(file.path(results_dir, "final_models_discovery_trained.rds"))
lasso_res <- models$LASSO$results
rf_res <- models$RF$results
svm_res <- models[["SVM-RFE"]]$results
xgb_res <- models$XGBoost$cv_results
write.csv(lasso_res, file.path(source_dir, "FigureS2_LASSO_tuning.csv"), row.names = FALSE)
write.csv(rf_res, file.path(source_dir, "FigureS2_RF_tuning.csv"), row.names = FALSE)
write.csv(svm_res, file.path(source_dir, "FigureS2_SVM_RFE_tuning.csv"), row.names = FALSE)
write.csv(xgb_res, file.path(source_dir, "FigureS2_XGBoost_tuning.csv"), row.names = FALSE)

pS2a <- ggplot(lasso_res, aes(log10(lambda), ROC)) + geom_errorbar(aes(ymin = pmax(0, ROC - ROCSD), ymax = pmin(1, ROC + ROCSD)), width = 0, linewidth = 0.25, colour = palette_contract["neutral_mid"]) + geom_line(linewidth = 0.55, colour = palette_contract["signal_blue"]) + geom_point(size = 1.1, colour = palette_contract["signal_blue"]) + geom_vline(xintercept = log10(models$LASSO$bestTune$lambda), linetype = 2, colour = palette_contract["accent_red"]) + labs(x = expression(log[10](lambda)), y = "Mean CV ROC AUC ± SD", title = "LASSO")
pS2b <- ggplot(rf_res, aes(mtry, ROC)) + geom_errorbar(aes(ymin = pmax(0, ROC - ROCSD), ymax = pmin(1, ROC + ROCSD)), width = 0, linewidth = 0.25, colour = palette_contract["neutral_mid"]) + geom_line(linewidth = 0.55, colour = palette_contract["signal_teal"]) + geom_point(size = 1.2, colour = palette_contract["signal_teal"]) + geom_vline(xintercept = models$RF$bestTune$mtry, linetype = 2, colour = palette_contract["accent_red"]) + labs(x = "mtry", y = "Mean CV ROC AUC ± SD", title = "Random forest")
pS2c <- ggplot(svm_res, aes(Variables, ROC)) + geom_errorbar(aes(ymin = pmax(0, ROC - ROCSD), ymax = pmin(1, ROC + ROCSD)), width = 0, linewidth = 0.25, colour = palette_contract["neutral_mid"]) + geom_line(linewidth = 0.55, colour = palette_contract["accent_orange"]) + geom_point(size = 1.2, colour = palette_contract["accent_orange"]) + geom_vline(xintercept = models[["SVM-RFE"]]$optsize, linetype = 2, colour = palette_contract["accent_red"]) + scale_x_log10() + labs(x = "Retained variables (log scale)", y = "Mean CV ROC AUC ± SD", title = "SVM-RFE")
xgb_res$parameter_set <- interaction(xgb_res$max_depth, xgb_res$eta, xgb_res$min_child_weight, sep = "/")
pS2d <- ggplot(xgb_res, aes(nrounds, mean_ROC, colour = parameter_set)) + geom_errorbar(aes(ymin = pmax(0, mean_ROC - sd_ROC), ymax = pmin(1, mean_ROC + sd_ROC)), width = 0, linewidth = 0.2) + geom_line(linewidth = 0.45) + geom_point(size = 1.05) + labs(x = "Boosting rounds", y = "Mean CV ROC AUC ± SD", colour = "depth/eta/min.child", title = "XGBoost") + guides(colour = guide_legend(nrow = 3, byrow = TRUE))
figS2 <- ((pS2a | pS2b) / (pS2c | pS2d)) + plot_layout(guides = "collect") + plot_annotation(tag_levels = "A") & theme(legend.position = "bottom", legend.text = element_text(size = 5.5))
save_pub_r(figS2, file.path(fig_dir, "FigureS2_model_tuning"), width_mm = 183, height_mm = 130)

figure_manifest <- data.frame(
  figure = c("Figure1", "Figure2", "Figure3", "Figure4", "FigureS1", "FigureS2"),
  stem = c("Figure1_workflow_and_target_sensitivity", "Figure2_model_performance_and_transportability", "Figure3_top5_gene_replication", "Figure4_evidence_bounded_hypothesis_framework", "FigureS1_PCA_diagnostics", "FigureS2_model_tuning"),
  width_mm = c(183, 183, 183, 183, 183, 183),
  height_mm = c(125, 145, 175, 105, 80, 130),
  output_formats = "SVG;PDF;TIFF(600 dpi);PNG preview",
  stringsAsFactors = FALSE
)
write.csv(figure_manifest, file.path(fig_dir, "figure_manifest.csv"), row.names = FALSE)
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo_after_figures.txt"))
cat("Figures exported to", fig_dir, "\n")
