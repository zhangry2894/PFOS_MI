# Third-party raw exports are not redistributed

The raw exports downloaded from SwissTargetPrediction, SuperPred, PharmMapper,
STITCH, TargetNet, GeneCards and OMIM are intentionally absent from this public
archive because their reuse and redistribution are governed by provider-specific
terms.

This archive retains the source names, URLs, access dates, query identifiers,
organism, operational thresholds, standardized per-source counts, processing
scripts, fitted models, QA records and software-session information. The exact
standardized gene-level evidence table used by the analyses is distributed in
`S1_Data/target_inputs/PFOS_target_evidence_and_tiers.csv`; threshold and
multi-source intersection audits are also in S1 Data.

To reconstruct provider exports, users must query the original providers under
their current terms. Provider outputs may change over time, so results should be
compared with the archived standardized evidence table and the reported counts:
423 broad targets, 141 source-specific high-confidence targets and 74 targets
supported by at least two prediction sources.
