options(stringsAsFactors = FALSE, width = 220)
suppressPackageStartupMessages(library(pROC))

work <- Sys.getenv("PFOS_MI_WORK_ROOT", unset = "./rerun_output")
processed_dir <- file.path(work, "03_data_processed")
results_dir <- file.path(work, "04_results")
strict_dir <- file.path(results_dir, "strict_four_algorithm")
logs_dir <- file.path(work, "08_logs")

audit <- read.csv(file.path(results_dir, "PFOS_multidatabase_intersection_audit.csv"), check.names = FALSE)
candidates <- scan(file.path(processed_dir, "candidate_genes_consensus2plus_MI_original.txt"), what = character(), quiet = TRUE)
membership <- read.csv(file.path(strict_dir, "four_algorithm_membership_all_candidates.csv"), check.names = FALSE)
core <- scan(file.path(strict_dir, "strict_four_algorithm_core_genes.txt"), what = character(), quiet = TRUE)
perf <- read.csv(file.path(results_dir, "model_performance.csv"), check.names = FALSE)
pred <- read.csv(file.path(results_dir, "GSE48060_external_model_predictions.csv"), check.names = FALSE)
meta66360 <- read.csv(file.path(processed_dir, "GSE66360_sample_metadata.csv"), check.names = FALSE)
meta48060 <- read.csv(file.path(processed_dir, "GSE48060_sample_metadata.csv"), check.names = FALSE)

checks <- list(
  consensus2_targets_74 = audit$n_PFOS_targets[audit$minimum_supporting_PFOS_databases == 2] == 74,
  consensus2_MI_overlap_38 = audit$n_PFOS_MI_overlap[audit$minimum_supporting_PFOS_databases == 2] == 38,
  measured_candidates_37 = length(candidates) == 37,
  strict_5way_empty = audit$n_PFOS_targets[audit$minimum_supporting_PFOS_databases == 5] == 0,
  core_has_three_genes = identical(sort(core), sort(c("AKR1C3", "MMP2", "MMP9"))),
  core_selected_by_all_four = all(membership$n_algorithms[membership$gene %in% core] == 4),
  discovery_validation_ids_disjoint = length(intersect(
    meta66360$sample_id[meta66360$cohort == "Discovery"],
    meta66360$sample_id[meta66360$cohort == "Validation"]
  )) == 0,
  external_ids_disjoint_from_GSE66360 = length(intersect(meta66360$sample_id, meta48060$sample_id)) == 0,
  external_n_52 = nrow(meta48060) == 52,
  external_class_counts_31_MI_21_control = sum(meta48060$group == "MI") == 31 && sum(meta48060$group == "Control") == 21,
  no_missing_external_performance = !anyNA(perf[perf$cohort == "GSE48060_external", c("ROC_AUC", "AUC_CI_low", "AUC_CI_high")])
)

for (algorithm in unique(pred$algorithm)) {
  d <- pred[pred$algorithm == algorithm, ]
  fit <- roc(factor(d$truth, levels = c("Control", "MI")), d$probability_MI,
             levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  reported <- perf$ROC_AUC[perf$cohort == "GSE48060_external" & perf$algorithm == algorithm]
  checks[[paste0("external_AUC_reproduced_", gsub("-", "_", algorithm))]] <-
    length(reported) == 1L && abs(as.numeric(auc(fit)) - reported) < 1e-12
}

check_table <- data.frame(
  check = names(checks),
  passed = unlist(checks, use.names = FALSE),
  stringsAsFactors = FALSE
)
write.csv(check_table, file.path(logs_dir, "QA_checks.csv"), row.names = FALSE)

if (!all(check_table$passed)) {
  stop("QA failed: ", paste(check_table$check[!check_table$passed], collapse = ", "))
}

lines <- c(
  "QA AUDIT: PASS",
  sprintf("Checks passed: %d/%d", sum(check_table$passed), nrow(check_table)),
  "External AUCs were recalculated from saved per-sample probabilities with MI as the positive class.",
  "AUC direction was locked; values below 0.5 were not inverted.",
  "GSE66360 discovery, GSE66360 validation, and GSE48060 external sample identifiers are disjoint as applicable.",
  "No external samples were used for feature selection or tuning in the saved scripts."
)
writeLines(lines, file.path(logs_dir, "QA_AUDIT.txt"))
cat(paste(lines, collapse = "\n"), "\n")

