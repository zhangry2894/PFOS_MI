options(stringsAsFactors = FALSE, width = 180)
set.seed(20260914)

suppressPackageStartupMessages({
  library(caret)
  library(glmnet)
  library(pROC)
  library(PRROC)
  library(randomForest)
  library(xgboost)
})

work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
processed_dir <- file.path(work, "03_data_processed")
results_dir <- file.path(work, "04_results")
logs_dir <- file.path(work, "08_logs")
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

expr66360 <- readRDS(file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"))
expr48060 <- readRDS(file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"))
meta66360 <- read.csv(file.path(processed_dir, "GSE66360_sample_metadata.csv"), check.names = FALSE)
meta48060 <- read.csv(file.path(processed_dir, "GSE48060_sample_metadata.csv"), check.names = FALSE)
candidates <- unique(scan(file.path(processed_dir, "candidate_genes_consensus2plus_MI_original.txt"), what = character(), quiet = TRUE))
candidates <- intersect(candidates, rownames(expr66360))

idx_dev <- meta66360$cohort == "Discovery"
idx_val <- meta66360$cohort == "Validation"
x_dev <- as.data.frame(t(expr66360[candidates, meta66360$sample_id[idx_dev], drop = FALSE]), check.names = FALSE)
x_val <- as.data.frame(t(expr66360[candidates, meta66360$sample_id[idx_val], drop = FALSE]), check.names = FALSE)
x_ext <- as.data.frame(t(expr48060[candidates, meta48060$sample_id, drop = FALSE]), check.names = FALSE)
y_dev <- factor(meta66360$group[idx_dev], levels = c("MI", "Control"))
y_val <- factor(meta66360$group[idx_val], levels = c("MI", "Control"))
y_ext <- factor(meta48060$group, levels = c("MI", "Control"))
rownames(x_dev) <- meta66360$sample_id[idx_dev]
rownames(x_val) <- meta66360$sample_id[idx_val]
rownames(x_ext) <- meta48060$sample_id

stopifnot(nrow(x_dev) == 43, nrow(x_val) == 56, nrow(x_ext) == 52)

make_inner_control <- function(seed) {
  set.seed(seed)
  trainControl(
    method = "cv",
    number = 5,
    classProbs = TRUE,
    summaryFunction = twoClassSummary,
    savePredictions = "final",
    allowParallel = FALSE
  )
}

lasso_grid <- expand.grid(alpha = 1, lambda = 10^seq(-4, 0, length.out = 20))
rf_grid <- data.frame(mtry = unique(pmax(1, pmin(ncol(x_dev), c(5, 10, 14, 20, 40)))))
xgb_grid <- expand.grid(
  nrounds = c(50, 100),
  max_depth = c(1, 2, 3),
  eta = c(0.03, 0.10),
  gamma = 0,
  colsample_bytree = 0.8,
  min_child_weight = c(1, 5),
  subsample = 0.8
)
svm_grid <- data.frame(cost = c(0.01, 0.1, 1, 10))
rfe_sizes <- unique(pmin(ncol(x_dev), c(5, 10, 20, 40, 80, 120)))

extract_selected <- function(fit, algorithm, top_n = 20) {
  if (algorithm == "LASSO") {
    cf <- as.matrix(coef(fit$finalModel, s = fit$bestTune$lambda))
    genes <- rownames(cf)[cf[, 1] != 0]
    return(setdiff(genes, "(Intercept)"))
  }
  if (algorithm == "RF") {
    vi <- varImp(fit, scale = FALSE)$importance
    score <- if ("Overall" %in% names(vi)) vi$Overall else rowMeans(vi)
    return(names(sort(score, decreasing = TRUE))[seq_len(min(top_n, length(score)))])
  }
  if (algorithm == "XGBoost") {
    vi <- xgb.importance(model = fit$model)
    feature_col <- if ("Features" %in% names(vi)) "Features" else "Feature"
    return(head(vi[[feature_col]], top_n))
  }
  if (algorithm == "SVM-RFE") return(predictors(fit))
  character()
}

fit_xgb_native <- function(x, y, seed) {
  x <- as.matrix(x)
  storage.mode(x) <- "double"
  y_num <- as.numeric(y == "MI")
  set.seed(seed)
  inner_folds <- createFolds(y, k = 5, returnTrain = FALSE)
  cv_rows <- vector("list", nrow(xgb_grid))
  for (gi in seq_len(nrow(xgb_grid))) {
    g <- xgb_grid[gi, ]
    fold_auc <- numeric(length(inner_folds))
    for (fi in seq_along(inner_folds)) {
      test_idx <- inner_folds[[fi]]
      train_idx <- setdiff(seq_len(nrow(x)), test_idx)
      params <- list(
        objective = "binary:logistic",
        eval_metric = "logloss",
        eta = g$eta,
        max_depth = as.integer(g$max_depth),
        gamma = g$gamma,
        colsample_bytree = g$colsample_bytree,
        min_child_weight = g$min_child_weight,
        subsample = g$subsample,
        nthread = 1,
        seed = seed + fi + gi * 100
      )
      model <- xgb.train(
        params = params,
        data = xgb.DMatrix(x[train_idx, , drop = FALSE], label = y_num[train_idx]),
        nrounds = as.integer(g$nrounds),
        verbose = 0
      )
      prob <- predict(model, xgb.DMatrix(x[test_idx, , drop = FALSE]))
      fold_auc[fi] <- as.numeric(auc(roc(y[test_idx], prob, levels = c("Control", "MI"), direction = "<", quiet = TRUE)))
    }
    cv_rows[[gi]] <- cbind(g, mean_ROC = mean(fold_auc), sd_ROC = sd(fold_auc))
  }
  cv <- do.call(rbind, cv_rows)
  best_idx <- order(-cv$mean_ROC, cv$sd_ROC, cv$max_depth, cv$nrounds)[1]
  best <- cv[best_idx, names(xgb_grid), drop = FALSE]
  params <- list(
    objective = "binary:logistic",
    eval_metric = "logloss",
    eta = best$eta,
    max_depth = as.integer(best$max_depth),
    gamma = best$gamma,
    colsample_bytree = best$colsample_bytree,
    min_child_weight = best$min_child_weight,
    subsample = best$subsample,
    nthread = 1,
    seed = seed
  )
  model <- xgb.train(
    params = params,
    data = xgb.DMatrix(x, label = y_num),
    nrounds = as.integer(best$nrounds),
    verbose = 0
  )
  list(model = model, bestTune = best, cv_results = cv, xNames = colnames(x))
}

predict_xgb_native <- function(fit, newx) {
  x <- as.matrix(newx[, fit$xNames, drop = FALSE])
  storage.mode(x) <- "double"
  predict(fit$model, xgb.DMatrix(x))
}

fit_one <- function(algorithm, x, y, seed, final_control = NULL) {
  ctrl <- if (is.null(final_control)) make_inner_control(seed) else final_control
  set.seed(seed)
  if (algorithm == "LASSO") {
    return(train(x, y, method = "glmnet", metric = "ROC", trControl = ctrl, tuneGrid = lasso_grid, preProcess = c("center", "scale", "nzv")))
  }
  if (algorithm == "RF") {
    return(train(x, y, method = "rf", metric = "ROC", trControl = ctrl, tuneGrid = rf_grid, ntree = 1000, importance = TRUE))
  }
  if (algorithm == "XGBoost") {
    return(fit_xgb_native(x, y, seed))
  }
  if (algorithm == "SVM-RFE") {
    svm_funcs <- caretFuncs
    svm_funcs$summary <- twoClassSummary
    rctrl <- rfeControl(
      functions = svm_funcs,
      method = "cv",
      number = 5,
      returnResamp = "final",
      verbose = FALSE,
      allowParallel = FALSE
    )
    return(rfe(
      x = x,
      y = y,
      sizes = rfe_sizes,
      metric = "ROC",
      rfeControl = rctrl,
      method = "svmLinear2",
      tuneGrid = svm_grid,
      preProcess = c("center", "scale", "nzv"),
      trControl = make_inner_control(seed + 7000)
    ))
  }
  stop("Unknown algorithm")
}

algorithms <- c("LASSO", "RF", "SVM-RFE", "XGBoost")
set.seed(20260914)
outer_folds <- createMultiFolds(y_dev, k = 5, times = 3)
outer_predictions <- list()
selection_records <- list()
fit_log <- list()
counter <- 0L

cat("Starting repeated nested cross-validation with", length(outer_folds), "outer resamples...\n")
for (fold_name in names(outer_folds)) {
  train_idx <- outer_folds[[fold_name]]
  test_idx <- setdiff(seq_len(nrow(x_dev)), train_idx)
  for (a in algorithms) {
    counter <- counter + 1L
    seed <- 20260914 + counter * 101L
    cat(sprintf("[%02d/%02d] %s %s train=%d test=%d\n", counter, length(outer_folds) * length(algorithms), fold_name, a, length(train_idx), length(test_idx)))
    fit <- fit_one(a, x_dev[train_idx, , drop = FALSE], y_dev[train_idx], seed)
    prob <- if (a == "XGBoost") {
      predict_xgb_native(fit, x_dev[test_idx, , drop = FALSE])
    } else {
      predict(fit, x_dev[test_idx, , drop = FALSE], type = "prob")$MI
    }
    outer_predictions[[counter]] <- data.frame(
      sample_id = rownames(x_dev)[test_idx],
      truth = as.character(y_dev[test_idx]),
      algorithm = a,
      outer_resample = fold_name,
      probability_MI = prob
    )
    selected <- extract_selected(fit, a)
    selection_records[[counter]] <- if (length(selected)) {
      data.frame(
        gene = selected,
        algorithm = a,
        outer_resample = fold_name,
        selected = 1L
      )
    } else {
      data.frame(gene = character(), algorithm = character(), outer_resample = character(), selected = integer())
    }
    best <- if (a == "SVM-RFE") {
      paste0("n_features=", length(predictors(fit)), ";C=", fit$fit$bestTune$cost)
    } else if (a == "XGBoost") {
      paste(names(fit$bestTune), unlist(fit$bestTune), sep = "=", collapse = ";")
    } else {
      paste(names(fit$bestTune), unlist(fit$bestTune), sep = "=", collapse = ";")
    }
    fit_log[[counter]] <- data.frame(algorithm = a, outer_resample = fold_name, best_tuning = best, n_selected = length(selected))
    rm(fit)
    invisible(gc())
  }
}

outer_predictions <- do.call(rbind, outer_predictions)
selection_records <- do.call(rbind, selection_records)
fit_log <- do.call(rbind, fit_log)
write.csv(outer_predictions, file.path(results_dir, "nested_cv_all_predictions.csv"), row.names = FALSE)
write.csv(selection_records, file.path(results_dir, "nested_cv_feature_selections.csv"), row.names = FALSE)
write.csv(fit_log, file.path(results_dir, "nested_cv_tuning_log.csv"), row.names = FALSE)

oof <- aggregate(probability_MI ~ sample_id + truth + algorithm, data = outer_predictions, FUN = mean)

full_ctrl <- trainControl(
  method = "repeatedcv",
  number = 5,
  repeats = 3,
  classProbs = TRUE,
  summaryFunction = twoClassSummary,
  savePredictions = "final",
  allowParallel = FALSE
)

final_models <- list()
validation_predictions <- list()
external_predictions <- list()
full_selected <- list()
full_tuning <- list()

cat("Fitting final models on the complete predefined discovery cohort...\n")
for (i in seq_along(algorithms)) {
  a <- algorithms[i]
  set.seed(20270000 + i * 1001)
  fit <- fit_one(a, x_dev, y_dev, 20270000 + i * 1001, final_control = full_ctrl)
  final_models[[a]] <- fit
  validation_predictions[[a]] <- data.frame(
    sample_id = rownames(x_val), truth = as.character(y_val), algorithm = a,
    probability_MI = if (a == "XGBoost") predict_xgb_native(fit, x_val) else predict(fit, x_val, type = "prob")$MI
  )
  external_predictions[[a]] <- data.frame(
    sample_id = rownames(x_ext), truth = as.character(y_ext), algorithm = a,
    probability_MI = if (a == "XGBoost") predict_xgb_native(fit, x_ext) else predict(fit, x_ext, type = "prob")$MI
  )
  full_selected[[a]] <- extract_selected(fit, a)
  full_tuning[[a]] <- if (a == "SVM-RFE") {
    data.frame(algorithm = a, best_tuning = paste0("n_features=", length(predictors(fit)), ";C=", fit$fit$bestTune$cost), n_selected = length(predictors(fit)))
  } else if (a == "XGBoost") {
    data.frame(algorithm = a, best_tuning = paste(names(fit$bestTune), unlist(fit$bestTune), sep = "=", collapse = ";"), n_selected = length(full_selected[[a]]))
  } else {
    data.frame(algorithm = a, best_tuning = paste(names(fit$bestTune), unlist(fit$bestTune), sep = "=", collapse = ";"), n_selected = length(full_selected[[a]]))
  }
}

validation_predictions <- do.call(rbind, validation_predictions)
external_predictions <- do.call(rbind, external_predictions)
write.csv(validation_predictions, file.path(results_dir, "GSE66360_validation_model_predictions.csv"), row.names = FALSE)
write.csv(external_predictions, file.path(results_dir, "GSE48060_external_model_predictions.csv"), row.names = FALSE)
write.csv(do.call(rbind, full_tuning), file.path(results_dir, "final_model_tuning_parameters.csv"), row.names = FALSE)
saveRDS(final_models, file.path(results_dir, "final_models_discovery_trained.rds"), compress = "xz")

# Add an equal-weight ensemble without using the validation labels.
make_ensemble <- function(pred_df) {
  z <- reshape(pred_df, idvar = c("sample_id", "truth"), timevar = "algorithm", direction = "wide")
  prob_cols <- grep("^probability_MI\\.", names(z), value = TRUE)
  data.frame(sample_id = z$sample_id, truth = z$truth, algorithm = "Ensemble", probability_MI = rowMeans(z[prob_cols]))
}
oof_ensemble <- make_ensemble(oof)
val_ensemble <- make_ensemble(validation_predictions)
ext_ensemble <- make_ensemble(external_predictions)
oof_all <- rbind(oof, oof_ensemble)
val_all <- rbind(validation_predictions, val_ensemble)
ext_all <- rbind(external_predictions, ext_ensemble)

# Thresholds are fixed from discovery out-of-fold predictions and then applied unchanged.
thresholds <- do.call(rbind, lapply(split(oof_all, oof_all$algorithm), function(d) {
  r <- roc(d$truth, d$probability_MI, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  th <- as.numeric(coords(r, x = "best", best.method = "youden", ret = "threshold", transpose = FALSE)[1])
  data.frame(algorithm = unique(d$algorithm), threshold = th)
}))
write.csv(thresholds, file.path(results_dir, "decision_thresholds_locked_from_discovery_oof.csv"), row.names = FALSE)

perf_one <- function(d, cohort, threshold) {
  truth <- factor(d$truth, levels = c("Control", "MI"))
  prob <- d$probability_MI
  r <- roc(truth, prob, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  ci <- as.numeric(ci.auc(r, method = "delong"))
  pred <- factor(ifelse(prob >= threshold, "MI", "Control"), levels = c("Control", "MI"))
  cm <- confusionMatrix(pred, truth, positive = "MI")
  pr <- pr.curve(scores.class0 = prob[truth == "MI"], scores.class1 = prob[truth == "Control"], curve = FALSE)$auc.integral
  data.frame(
    cohort = cohort,
    algorithm = unique(d$algorithm),
    n = length(truth),
    n_MI = sum(truth == "MI"),
    n_control = sum(truth == "Control"),
    ROC_AUC = as.numeric(auc(r)),
    AUC_CI_low = ci[1],
    AUC_CI_high = ci[3],
    PR_AUC = pr,
    threshold = threshold,
    sensitivity = unname(cm$byClass["Sensitivity"]),
    specificity = unname(cm$byClass["Specificity"]),
    balanced_accuracy = unname(cm$byClass["Balanced Accuracy"]),
    Brier_score = mean((as.numeric(truth == "MI") - prob)^2)
  )
}

performance <- do.call(rbind, lapply(algorithms |> c("Ensemble"), function(a) {
  th <- thresholds$threshold[thresholds$algorithm == a]
  rbind(
    perf_one(oof_all[oof_all$algorithm == a, ], "GSE66360_discovery_repeated_nested_CV", th),
    perf_one(val_all[val_all$algorithm == a, ], "GSE66360_predefined_validation", th),
    perf_one(ext_all[ext_all$algorithm == a, ], "GSE48060_external", th)
  )
}))
write.csv(performance, file.path(results_dir, "model_performance.csv"), row.names = FALSE)

# Equal-weight feature-ranking synthesis. It is based only on discovery fits.
all_genes <- colnames(x_dev)
stability <- expand.grid(gene = all_genes, algorithm = algorithms)
stability$key <- paste(stability$gene, stability$algorithm)
counts <- table(paste(selection_records$gene, selection_records$algorithm))
stability$selection_frequency <- as.numeric(counts[stability$key]) / length(outer_folds)
stability$selection_frequency[is.na(stability$selection_frequency)] <- 0

get_full_importance <- function(fit, algorithm, genes) {
  out <- setNames(rep(0, length(genes)), genes)
  if (algorithm == "LASSO") {
    cf <- as.matrix(coef(fit$finalModel, s = fit$bestTune$lambda))[, 1]
    cf <- abs(cf[setdiff(names(cf), "(Intercept)")])
    out[names(cf)] <- cf
  } else if (algorithm == "RF") {
    vi <- varImp(fit, scale = FALSE)$importance
    score <- if ("Overall" %in% names(vi)) vi$Overall else rowMeans(vi)
    out[rownames(vi)] <- score
  } else if (algorithm == "XGBoost") {
    vi <- xgb.importance(model = fit$model)
    feature_col <- if ("Features" %in% names(vi)) "Features" else "Feature"
    out[vi[[feature_col]]] <- vi$Gain
  } else if (algorithm == "SVM-RFE") {
    vi <- varImp(fit$fit, scale = FALSE)$importance
    score <- if ("Overall" %in% names(vi)) vi$Overall else rowMeans(vi)
    out[rownames(vi)] <- score
  }
  out
}

importance_long <- do.call(rbind, lapply(algorithms, function(a) {
  score <- get_full_importance(final_models[[a]], a, all_genes)
  pct <- if (length(unique(score)) == 1) rep(0, length(score)) else (rank(score, ties.method = "average") - 1) / (length(score) - 1)
  data.frame(gene = names(score), algorithm = a, raw_importance = as.numeric(score), importance_percentile = pct)
}))
importance_long <- merge(importance_long, stability[, c("gene", "algorithm", "selection_frequency")], by = c("gene", "algorithm"), all.x = TRUE)
write.csv(importance_long, file.path(results_dir, "feature_importance_by_algorithm.csv"), row.names = FALSE)

ensemble_rank <- aggregate(cbind(selection_frequency, importance_percentile) ~ gene, data = importance_long, FUN = mean)
ensemble_rank$ensemble_score <- 0.5 * ensemble_rank$selection_frequency + 0.5 * ensemble_rank$importance_percentile
ensemble_rank$n_algorithms_selected_final <- vapply(ensemble_rank$gene, function(g) sum(vapply(full_selected, function(s) g %in% s, logical(1))), integer(1))
ensemble_rank <- ensemble_rank[order(-ensemble_rank$ensemble_score, -ensemble_rank$n_algorithms_selected_final, ensemble_rank$gene), ]
ensemble_rank$rank <- seq_len(nrow(ensemble_rank))
write.csv(ensemble_rank, file.path(results_dir, "ensemble_feature_ranking.csv"), row.names = FALSE)
writeLines(head(ensemble_rank$gene, 5), file.path(processed_dir, "prioritized_top5_genes_discovery_only.txt"))

cat("\nMODEL PERFORMANCE\n")
print(performance)
cat("\nTOP 20 ENSEMBLE-RANKED FEATURES\n")
print(head(ensemble_rank, 20))
cat("\nFINAL MODEL TUNING\n")
print(do.call(rbind, full_tuning))
cat("\nDISCOVERY-ONLY PRIORITIZED TOP 5\n")
print(head(ensemble_rank$gene, 5))
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo_after_ML.txt"))
