options(stringsAsFactors = FALSE)

work <- Sys.getenv("PFOS_MI_WORK_ROOT", unset = "./rerun_output")
code_dir <- file.path(work, "01_code")
Sys.setenv(PFOS_MI_WORK_ROOT = work, PFOS_REVISE_TMP = work)

scripts <- c(
  "01_prepare_consensus_targets.R",
  "02_nested_ml_consensus.R",
  "03_strict_four_algorithm_consensus.R",
  "04_external_validation_and_summary.R",
  "05_audit_outputs.R"
)

rscript <- file.path(R.home("bin"), "Rscript.exe")
if (!file.exists(rscript)) rscript <- file.path(R.home("bin"), "Rscript")

for (script in scripts) {
  path <- file.path(code_dir, script)
  cat(sprintf("\n===== RUNNING %s =====\n", script))
  status <- system2(rscript, shQuote(path))
  if (!identical(status, 0L)) stop("Pipeline failed in ", script, " with status ", status)
}

cat("\nAll consensus-target analyses and QA checks completed successfully.\n")

