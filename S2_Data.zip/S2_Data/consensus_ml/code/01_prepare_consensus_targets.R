options(stringsAsFactors = FALSE, width = 220)
set.seed(20260920)

work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
input_dir <- file.path(work, "02_inputs")
processed_dir <- file.path(work, "03_data_processed")
results_dir <- file.path(work, "04_results")
logs_dir <- file.path(work, "08_logs")
dir.create(processed_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(results_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

pfos <- read.csv(file.path(input_dir, "PFOS_target_evidence_and_tiers.csv"), check.names = FALSE)
mi <- read.csv(file.path(input_dir, "MI_gene_evidence_and_tiers.csv"), check.names = FALSE)
expr_discovery <- readRDS(file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"))
expr_external <- readRDS(file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"))

stopifnot(all(c("gene", "n_sources", "tier_consensus_2plus") %in% names(pfos)))
stopifnot(all(c("gene", "tier_original_2841") %in% names(mi)))

mi_genes <- sort(unique(mi$gene[mi$tier_original_2841]))
thresholds <- 1:5
audit <- do.call(rbind, lapply(thresholds, function(k) {
  pfos_k <- sort(unique(pfos$gene[pfos$n_sources >= k]))
  overlap <- intersect(pfos_k, mi_genes)
  measured <- Reduce(intersect, list(overlap, rownames(expr_discovery), rownames(expr_external)))
  data.frame(
    minimum_supporting_PFOS_databases = k,
    n_PFOS_targets = length(pfos_k),
    n_PFOS_MI_overlap = length(overlap),
    n_measured_in_both_GEO_cohorts = length(measured),
    PFOS_MI_overlap_genes = paste(overlap, collapse = ";"),
    measured_genes = paste(measured, collapse = ";"),
    stringsAsFactors = FALSE
  )
}))
write.csv(audit, file.path(results_dir, "PFOS_multidatabase_intersection_audit.csv"), row.names = FALSE)

# Primary multi-database definition: supported by at least two independent
# prediction resources. The strict five-way intersection is reported above;
# it is empty and therefore cannot support feature selection.
pfos_consensus <- sort(unique(pfos$gene[pfos$n_sources >= 2]))
candidate_network <- sort(intersect(pfos_consensus, mi_genes))
candidate_measured <- sort(Reduce(intersect, list(
  candidate_network,
  rownames(expr_discovery),
  rownames(expr_external)
)))

writeLines(pfos_consensus, file.path(processed_dir, "PFOS_targets_consensus2plus.txt"))
writeLines(candidate_network, file.path(processed_dir, "PFOS_MI_consensus2plus_overlap.txt"))
writeLines(candidate_measured, file.path(processed_dir, "candidate_genes_consensus2plus_MI_original.txt"))

ev_cols <- c(
  "gene", "n_sources", "n_high_confidence_sources",
  grep("_present$", names(pfos), value = TRUE),
  grep("_score$", names(pfos), value = TRUE)
)
ev_cols <- unique(ev_cols[ev_cols %in% names(pfos)])
candidate_evidence <- pfos[pfos$gene %in% candidate_network, ev_cols, drop = FALSE]
candidate_evidence$in_GSE66360 <- candidate_evidence$gene %in% rownames(expr_discovery)
candidate_evidence$in_GSE48060 <- candidate_evidence$gene %in% rownames(expr_external)
candidate_evidence <- candidate_evidence[order(-candidate_evidence$n_sources, candidate_evidence$gene), ]
write.csv(candidate_evidence, file.path(results_dir, "PFOS_MI_consensus_candidate_evidence.csv"), row.names = FALSE)

manifest <- c(
  "Analysis: multi-database consensus PFOS targets for PFOS-MI feature selection",
  "Primary PFOS rule: gene supported by at least 2 of 5 target-prediction resources",
  "PFOS resources: SuperPred, PharmMapper, SwissTargetPrediction, STITCH, TargetNet",
  "MI rule: original 2,841-gene set retained from the audited revision workflow",
  "Feature universe: PFOS consensus intersect MI genes, restricted to genes measured in both GEO cohorts",
  sprintf("PFOS consensus >=2 sources: %d", length(pfos_consensus)),
  sprintf("PFOS-MI network overlap: %d", length(candidate_network)),
  sprintf("Measured candidates in both GSE66360 and GSE48060: %d", length(candidate_measured)),
  sprintf("Strict five-source PFOS intersection: %d", sum(pfos$n_sources >= 5)),
  sprintf("Run date: %s", Sys.Date())
)
writeLines(manifest, file.path(results_dir, "consensus_target_manifest.txt"))
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo_prepare.txt"))

cat(paste(manifest, collapse = "\n"), "\n\n")
print(audit[, 1:4], row.names = FALSE)
cat("\nMeasured candidate genes:\n")
print(candidate_measured)
