options(stringsAsFactors = FALSE, width = 220)

suppressPackageStartupMessages({
  library(pROC)
})

work <- Sys.getenv(
  "PFOS_MI_WORK_ROOT",
  unset = "./rerun_output"
)
processed_dir <- file.path(work, "03_data_processed")
results_dir <- file.path(work, "04_results")
strict_dir <- file.path(results_dir, "strict_four_algorithm")
logs_dir <- file.path(work, "08_logs")
dir.create(logs_dir, recursive = TRUE, showWarnings = FALSE)

expr66360 <- readRDS(file.path(processed_dir, "GSE66360_gene_expression_RMA.rds"))
expr48060 <- readRDS(file.path(processed_dir, "GSE48060_gene_expression_RMA.rds"))
meta66360 <- read.csv(file.path(processed_dir, "GSE66360_sample_metadata.csv"), check.names = FALSE)
meta48060 <- read.csv(file.path(processed_dir, "GSE48060_sample_metadata.csv"), check.names = FALSE)
limma <- read.csv(file.path(results_dir, "limma_all_genes_all_cohorts.csv"), check.names = FALSE)
performance <- read.csv(file.path(results_dir, "model_performance.csv"), check.names = FALSE)
core <- scan(file.path(strict_dir, "strict_four_algorithm_core_genes.txt"), what = character(), quiet = TRUE)

stopifnot(length(core) > 0L)
stopifnot(all(core %in% rownames(expr66360)), all(core %in% rownames(expr48060)))
stopifnot(all(meta66360$group %in% c("Control", "MI")))
stopifnot(all(meta48060$group %in% c("Control", "MI")))

idx_dev <- meta66360$cohort == "Discovery"
idx_val <- meta66360$cohort == "Validation"
discovery_de <- limma[limma$cohort == "GSE66360_discovery" & limma$gene %in% core, ]
discovery_sign <- setNames(sign(discovery_de$logFC), discovery_de$gene)
stopifnot(all(core %in% names(discovery_sign)), all(discovery_sign[core] != 0))

auc_one <- function(truth, score, cohort, item, item_type) {
  truth <- factor(truth, levels = c("Control", "MI"))
  fit <- roc(truth, score, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  ci <- as.numeric(ci.auc(fit, method = "delong"))
  data.frame(
    cohort = cohort,
    item_type = item_type,
    item = item,
    n = length(truth),
    n_MI = sum(truth == "MI"),
    n_control = sum(truth == "Control"),
    ROC_AUC_direction_locked = as.numeric(auc(fit)),
    AUC_CI_low = ci[1],
    AUC_CI_high = ci[3],
    stringsAsFactors = FALSE
  )
}

cohorts <- list(
  GSE66360_discovery = list(expr = expr66360[, idx_dev, drop = FALSE], meta = meta66360[idx_dev, ]),
  GSE66360_validation = list(expr = expr66360[, idx_val, drop = FALSE], meta = meta66360[idx_val, ]),
  GSE48060_external = list(expr = expr48060, meta = meta48060)
)

single_gene_auc <- do.call(rbind, lapply(names(cohorts), function(cohort_name) {
  z <- cohorts[[cohort_name]]
  do.call(rbind, lapply(core, function(gene) {
    score <- as.numeric(z$expr[gene, z$meta$sample_id]) * discovery_sign[[gene]]
    auc_one(z$meta$group, score, cohort_name, gene, "single_gene")
  }))
}))
write.csv(single_gene_auc, file.path(strict_dir, "strict_core_single_gene_auc.csv"), row.names = FALSE)

# Exploratory equal-weight core score. Scaling means and SDs and expression
# directions are locked from the discovery subset and applied unchanged.
dev_mat <- t(expr66360[core, meta66360$sample_id[idx_dev], drop = FALSE])
dev_mean <- colMeans(dev_mat)
dev_sd <- apply(dev_mat, 2, sd)
stopifnot(all(is.finite(dev_sd)), all(dev_sd > 0))

score_cohort <- function(expr, meta) {
  mat <- t(expr[core, meta$sample_id, drop = FALSE])
  z <- sweep(sweep(mat, 2, dev_mean, "-"), 2, dev_sd, "/")
  oriented <- sweep(z, 2, discovery_sign[colnames(z)], "*")
  rowMeans(oriented)
}

core_score_rows <- do.call(rbind, lapply(names(cohorts), function(cohort_name) {
  z <- cohorts[[cohort_name]]
  score <- score_cohort(z$expr, z$meta)
  data.frame(
    cohort = cohort_name,
    sample_id = z$meta$sample_id,
    truth = z$meta$group,
    core_equal_weight_score = as.numeric(score),
    stringsAsFactors = FALSE
  )
}))
write.csv(core_score_rows, file.path(strict_dir, "strict_core_equal_weight_score_predictions.csv"), row.names = FALSE)

core_score_auc <- do.call(rbind, lapply(split(core_score_rows, core_score_rows$cohort), function(d) {
  auc_one(d$truth, d$core_equal_weight_score, unique(d$cohort), paste(core, collapse = "+"), "equal_weight_core_score")
}))
write.csv(core_score_auc, file.path(strict_dir, "strict_core_equal_weight_score_auc.csv"), row.names = FALSE)

external_model_auc <- performance[performance$cohort == "GSE48060_external", c(
  "cohort", "algorithm", "n", "n_MI", "n_control", "ROC_AUC", "AUC_CI_low", "AUC_CI_high",
  "PR_AUC", "threshold", "sensitivity", "specificity", "balanced_accuracy", "Brier_score"
)]
external_model_auc <- external_model_auc[match(c("LASSO", "RF", "SVM-RFE", "XGBoost", "Ensemble"), external_model_auc$algorithm), ]
write.csv(external_model_auc, file.path(results_dir, "external_model_auc_consensus_targets.csv"), row.names = FALSE)

pfos_evidence <- read.csv(file.path(results_dir, "PFOS_MI_consensus_candidate_evidence.csv"), check.names = FALSE)
core_evidence <- pfos_evidence[pfos_evidence$gene %in% core, , drop = FALSE]
selection <- read.csv(file.path(strict_dir, "four_algorithm_membership_all_candidates.csv"), check.names = FALSE)
core_evidence <- merge(core_evidence, selection, by = "gene", all.x = TRUE, sort = FALSE)
core_evidence <- core_evidence[match(core, core_evidence$gene), ]
write.csv(core_evidence, file.path(strict_dir, "strict_core_target_and_selection_evidence.csv"), row.names = FALSE)

external_de <- limma[limma$cohort == "GSE48060_external" & limma$gene %in% core,
                     c("cohort", "gene", "logFC", "P.Value", "adj.P.Val"), drop = FALSE]
external_de$discovery_direction <- ifelse(discovery_sign[external_de$gene] > 0, "higher_in_MI", "lower_in_MI")
external_de$same_direction_as_discovery <- sign(external_de$logFC) == discovery_sign[external_de$gene]
external_de <- external_de[match(core, external_de$gene), ]
write.csv(external_de, file.path(strict_dir, "strict_core_external_direction_check.csv"), row.names = FALSE)

summary_lines <- c(
  "PFOS multi-database consensus analysis summary",
  "Primary PFOS rule: >=2 of 5 resources",
  sprintf("Strict four-algorithm core (%d): %s", length(core), paste(core, collapse = ", ")),
  "External model AUCs:",
  paste(sprintf("  %s: %.3f (95%% CI %.3f-%.3f)", external_model_auc$algorithm,
                external_model_auc$ROC_AUC, external_model_auc$AUC_CI_low,
                external_model_auc$AUC_CI_high), collapse = "\n"),
  "External direction-locked single-gene AUCs:",
  paste(sprintf("  %s: %.3f (95%% CI %.3f-%.3f)",
                single_gene_auc$item[single_gene_auc$cohort == "GSE48060_external"],
                single_gene_auc$ROC_AUC_direction_locked[single_gene_auc$cohort == "GSE48060_external"],
                single_gene_auc$AUC_CI_low[single_gene_auc$cohort == "GSE48060_external"],
                single_gene_auc$AUC_CI_high[single_gene_auc$cohort == "GSE48060_external"]), collapse = "\n"),
  sprintf("Exploratory equal-weight core score external AUC: %.3f (95%% CI %.3f-%.3f)",
          core_score_auc$ROC_AUC_direction_locked[core_score_auc$cohort == "GSE48060_external"],
          core_score_auc$AUC_CI_low[core_score_auc$cohort == "GSE48060_external"],
          core_score_auc$AUC_CI_high[core_score_auc$cohort == "GSE48060_external"]),
  "Direction was locked from discovery; AUC values below 0.5 were not inverted."
)
writeLines(summary_lines, file.path(results_dir, "FINAL_SUMMARY.txt"))
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo_external_validation.txt"))

cat(paste(summary_lines, collapse = "\n"), "\n")
