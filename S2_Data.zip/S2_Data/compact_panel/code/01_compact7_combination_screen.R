#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(glmnet)
  library(pROC)
})

options(stringsAsFactors = FALSE, width = 220)
set.seed(20260920)

args <- commandArgs(trailingOnly = TRUE)
input_root <- if (length(args) >= 1L) args[[1]] else "./rerun_output"
output_root <- if (length(args) >= 2L) args[[2]] else file.path(input_root, "compact7_analysis")
input_root <- normalizePath(input_root, winslash = "/", mustWork = TRUE)

code_dir <- file.path(output_root, "code")
results_dir <- file.path(output_root, "results")
models_dir <- file.path(output_root, "models")
logs_dir <- file.path(output_root, "logs")
for (d in c(output_root, code_dir, results_dir, models_dir, logs_dir)) {
  dir.create(d, recursive = TRUE, showWarnings = FALSE)
}

membership_path <- file.path(input_root, "04_results", "strict_four_algorithm", "four_algorithm_membership_all_candidates.csv")
expr66360_path <- file.path(input_root, "03_data_processed", "GSE66360_gene_expression_RMA.rds")
expr48060_path <- file.path(input_root, "03_data_processed", "GSE48060_gene_expression_RMA.rds")
meta66360_path <- file.path(input_root, "03_data_processed", "GSE66360_sample_metadata.csv")
meta48060_path <- file.path(input_root, "03_data_processed", "GSE48060_sample_metadata.csv")
evidence_path <- file.path(input_root, "04_results", "PFOS_MI_consensus_candidate_evidence.csv")
limma_path <- file.path(input_root, "04_results", "limma_all_genes_all_cohorts.csv")

stopifnot(all(file.exists(c(
  membership_path, expr66360_path, expr48060_path, meta66360_path,
  meta48060_path, evidence_path, limma_path
))))

membership <- read.csv(membership_path, check.names = FALSE)
expr66360 <- readRDS(expr66360_path)
expr48060 <- readRDS(expr48060_path)
meta66360 <- read.csv(meta66360_path, check.names = FALSE)
meta48060 <- read.csv(meta48060_path, check.names = FALSE)
evidence <- read.csv(evidence_path, check.names = FALSE)
limma <- read.csv(limma_path, check.names = FALSE)

required_membership <- c("gene", "LASSO", "SVM_RFE", "Boruta", "XGBoost", "n_algorithms")
stopifnot(all(required_membership %in% names(membership)))

# The operational PFOS intersection is the pre-audited >=2-of-5 database
# consensus. The literal five-way intersection is empty, so it cannot seed an
# expression-based feature-selection analysis.
pool <- membership[membership$n_algorithms >= 2L, , drop = FALSE]
pool <- pool[order(-pool$n_algorithms, -pool$confirmed_frequency, pool$gene), ]
stopifnot(nrow(pool) == 7L)
genes7 <- pool$gene
stopifnot(all(genes7 %in% rownames(expr66360)), all(genes7 %in% rownames(expr48060)))

idx_dev <- meta66360$cohort == "Discovery"
idx_val <- meta66360$cohort == "Validation"
stopifnot(sum(idx_dev) == 43L, sum(idx_val) == 56L, nrow(meta48060) == 52L)

x_dev <- t(expr66360[genes7, meta66360$sample_id[idx_dev], drop = FALSE])
x_val <- t(expr66360[genes7, meta66360$sample_id[idx_val], drop = FALSE])
x_ext <- t(expr48060[genes7, meta48060$sample_id, drop = FALSE])
y_dev_label <- factor(meta66360$group[idx_dev], levels = c("Control", "MI"))
y_val_label <- factor(meta66360$group[idx_val], levels = c("Control", "MI"))
y_ext_label <- factor(meta48060$group, levels = c("Control", "MI"))
y_dev <- as.integer(y_dev_label == "MI")

# Fixed stratified five-fold assignment used identically for every candidate
# subset; only the discovery cohort participates in lambda selection.
make_stratified_folds <- function(y, k = 5L, seed = 20260920L) {
  set.seed(seed)
  out <- integer(length(y))
  for (cls in sort(unique(y))) {
    ii <- sample(which(y == cls))
    out[ii] <- rep(seq_len(k), length.out = length(ii))
  }
  out
}
foldid <- make_stratified_folds(y_dev)
fold_assignment <- data.frame(
  sample_id = meta66360$sample_id[idx_dev],
  outcome = as.character(y_dev_label),
  fold = foldid
)
write.csv(fold_assignment, file.path(results_dir, "discovery_fold_assignment.csv"), row.names = FALSE)

clip_probability <- function(p, eps = 1e-6) pmin(pmax(as.numeric(p), eps), 1 - eps)

metric_row <- function(labels, probability, cohort, subset_id, genes) {
  probability <- clip_probability(probability)
  truth01 <- as.integer(labels == "MI")
  roc_obj <- pROC::roc(labels, probability, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
  ci <- as.numeric(pROC::ci.auc(roc_obj, method = "delong"))
  auc_var <- tryCatch(as.numeric(pROC::var(roc_obj)), error = function(e) NA_real_)
  data.frame(
    subset_id = subset_id,
    genes = paste(genes, collapse = ";"),
    n_genes = length(genes),
    cohort = cohort,
    n = length(labels),
    n_MI = sum(labels == "MI"),
    n_control = sum(labels == "Control"),
    ROC_AUC = as.numeric(pROC::auc(roc_obj)),
    AUC_SE = sqrt(auc_var),
    AUC_CI_low = ci[1],
    AUC_CI_high = ci[3],
    log_loss = -mean(truth01 * log(probability) + (1 - truth01) * log(1 - probability)),
    Brier = mean((probability - truth01)^2),
    stringsAsFactors = FALSE
  )
}

# Enumerate every multi-gene subset after the literature-aligned ensemble-vote
# prefilter. Seven genes yield 2^7 - 1 - 7 = 120 signatures of size 2-7.
subset_list <- list()
counter <- 0L
for (k in 2:length(genes7)) {
  cmb <- combn(genes7, k, simplify = FALSE)
  for (g in cmb) {
    counter <- counter + 1L
    subset_list[[sprintf("S%03d", counter)]] <- sort(g)
  }
}
stopifnot(length(subset_list) == 120L)

models <- vector("list", length(subset_list))
names(models) <- names(subset_list)
metrics <- vector("list", length(subset_list) * 2L)
predictions <- vector("list", length(subset_list) * 2L)
metric_i <- 0L
pred_i <- 0L

for (subset_id in names(subset_list)) {
  genes <- subset_list[[subset_id]]
  cvfit <- suppressWarnings(cv.glmnet(
    x = x_dev[, genes, drop = FALSE],
    y = y_dev,
    family = "binomial",
    alpha = 0,
    foldid = foldid,
    type.measure = "deviance",
    standardize = TRUE,
    intercept = TRUE
  ))
  lambda <- cvfit$lambda.1se
  p_val <- as.numeric(predict(cvfit, newx = x_val[, genes, drop = FALSE], s = "lambda.1se", type = "response"))
  p_ext <- as.numeric(predict(cvfit, newx = x_ext[, genes, drop = FALSE], s = "lambda.1se", type = "response"))

  models[[subset_id]] <- list(genes = genes, lambda_1se = lambda, cvfit = cvfit)

  metric_i <- metric_i + 1L
  metrics[[metric_i]] <- metric_row(y_val_label, p_val, "GSE66360_predefined_validation", subset_id, genes)
  metric_i <- metric_i + 1L
  metrics[[metric_i]] <- metric_row(y_ext_label, p_ext, "GSE48060_external", subset_id, genes)

  pred_i <- pred_i + 1L
  predictions[[pred_i]] <- data.frame(
    subset_id = subset_id, genes = paste(genes, collapse = ";"), n_genes = length(genes),
    cohort = "GSE66360_predefined_validation", sample_id = meta66360$sample_id[idx_val],
    truth = as.character(y_val_label), probability_MI = p_val, stringsAsFactors = FALSE
  )
  pred_i <- pred_i + 1L
  predictions[[pred_i]] <- data.frame(
    subset_id = subset_id, genes = paste(genes, collapse = ";"), n_genes = length(genes),
    cohort = "GSE48060_external", sample_id = meta48060$sample_id,
    truth = as.character(y_ext_label), probability_MI = p_ext, stringsAsFactors = FALSE
  )
}

metrics_long <- do.call(rbind, metrics)
predictions_long <- do.call(rbind, predictions)
saveRDS(models, file.path(models_dir, "all_120_subset_ridge_models.rds"), compress = "xz")
write.csv(metrics_long, file.path(results_dir, "all_120_subset_metrics_long.csv"), row.names = FALSE)
write.csv(predictions_long, file.path(results_dir, "all_120_subset_predictions.csv"), row.names = FALSE)

val <- metrics_long[metrics_long$cohort == "GSE66360_predefined_validation", ]
ext <- metrics_long[metrics_long$cohort == "GSE48060_external", ]
names(val)[names(val) %in% c("ROC_AUC", "AUC_SE", "AUC_CI_low", "AUC_CI_high", "log_loss", "Brier")] <-
  paste0(names(val)[names(val) %in% c("ROC_AUC", "AUC_SE", "AUC_CI_low", "AUC_CI_high", "log_loss", "Brier")], "_internal")
names(ext)[names(ext) %in% c("ROC_AUC", "AUC_SE", "AUC_CI_low", "AUC_CI_high", "log_loss", "Brier")] <-
  paste0(names(ext)[names(ext) %in% c("ROC_AUC", "AUC_SE", "AUC_CI_low", "AUC_CI_high", "log_loss", "Brier")], "_external")
# The combination is selected only from the predefined GSE66360 validation
# columns. GSE48060 is not referenced until after the subset ID is locked.
val_results <- val[order(-val$ROC_AUC_internal, val$n_genes, val$log_loss_internal), ]
combo_candidates <- val_results[val_results$n_genes >= 2L, ]
best_internal <- combo_candidates[order(-combo_candidates$ROC_AUC_internal,
                                        combo_candidates$n_genes,
                                        combo_candidates$log_loss_internal), ][1, ]
one_se_floor <- best_internal$ROC_AUC_internal - best_internal$AUC_SE_internal
eligible <- combo_candidates[combo_candidates$ROC_AUC_internal >= one_se_floor, ]
min_size <- min(eligible$n_genes)
one_se_selected <- eligible[eligible$n_genes == min_size, ]
one_se_selected <- one_se_selected[order(one_se_selected$log_loss_internal,
                                         -one_se_selected$ROC_AUC_internal), ][1, ]

is_dominated <- function(i, d) {
  any((d$n_genes <= d$n_genes[i]) &
        (d$ROC_AUC_internal >= d$ROC_AUC_internal[i]) &
        ((d$n_genes < d$n_genes[i]) | (d$ROC_AUC_internal > d$ROC_AUC_internal[i])))
}
pareto_flag <- !vapply(seq_len(nrow(combo_candidates)), is_dominated, logical(1), d = combo_candidates)
pareto <- combo_candidates[pareto_flag, ]
pareto <- pareto[order(pareto$n_genes, -pareto$ROC_AUC_internal, pareto$log_loss_internal), ]
write.csv(pareto, file.path(results_dir, "internal_pareto_front.csv"), row.names = FALSE)

# Lock the discovery/validation-selected panels before the external performance
# columns are joined to the analysis table.
selection_lock <- data.frame(
  selection_rule = c("Maximum internal validation AUC among 2-7 gene subsets",
                     "AUC one-SE-style parsimony rule; internal validation only"),
  subset_id = c(best_internal$subset_id, one_se_selected$subset_id),
  genes = c(best_internal$genes, one_se_selected$genes),
  n_genes = c(best_internal$n_genes, one_se_selected$n_genes),
  internal_AUC = c(best_internal$ROC_AUC_internal, one_se_selected$ROC_AUC_internal),
  internal_AUC_SE = c(best_internal$AUC_SE_internal, one_se_selected$AUC_SE_internal),
  one_SE_floor_from_best = one_se_floor,
  stringsAsFactors = FALSE
)
write.csv(selection_lock, file.path(results_dir, "SELECTION_LOCK_INTERNAL_ONLY.csv"), row.names = FALSE)

# External metrics are merged only after the selection lock has been written.
keep_ext <- c("subset_id", grep("_external$", names(ext), value = TRUE))
all_results <- merge(val_results, ext[, keep_ext], by = "subset_id", all = TRUE)
all_results <- all_results[order(-all_results$ROC_AUC_internal, all_results$n_genes, all_results$log_loss_internal), ]
write.csv(all_results, file.path(results_dir, "all_120_subset_performance.csv"), row.names = FALSE)

best_by_size <- do.call(rbind, lapply(split(all_results, all_results$n_genes), function(d) {
  d[order(-d$ROC_AUC_internal, d$log_loss_internal, d$subset_id), ][1, ]
}))
best_by_size <- best_by_size[order(best_by_size$n_genes), ]
write.csv(best_by_size, file.path(results_dir, "best_internal_subset_by_gene_count.csv"), row.names = FALSE)
write.csv(head(all_results, 20L), file.path(results_dir, "top20_subsets_by_internal_validation.csv"), row.names = FALSE)

# Literature-aligned panels from individual selectors, pairwise/multiway
# intersections, and vote thresholds. Duplicate gene sets are grouped.
method_sets <- list(
  LASSO = sort(membership$gene[membership$LASSO == 1L]),
  `SVM-RFE` = sort(membership$gene[membership$SVM_RFE == 1L]),
  Boruta = sort(membership$gene[membership$Boruta == 1L]),
  XGBoost = sort(membership$gene[membership$XGBoost == 1L])
)
panel_aliases <- list()
for (k in 1:4) {
  for (methods in combn(names(method_sets), k, simplify = FALSE)) {
    panel <- sort(Reduce(intersect, method_sets[methods]))
    if (length(panel) >= 1L && length(panel) <= 7L) {
      panel_aliases[[paste(methods, collapse = " intersect ")]] <- panel
    }
  }
}
panel_aliases[["Vote >=2 of 4"]] <- sort(membership$gene[membership$n_algorithms >= 2L])
panel_aliases[["Vote >=3 of 4"]] <- sort(membership$gene[membership$n_algorithms >= 3L])
panel_aliases[["Strict 4-way intersection"]] <- sort(membership$gene[membership$n_algorithms == 4L])

subset_signature <- vapply(subset_list, function(x) paste(sort(x), collapse = ";"), character(1))
alias_table <- do.call(rbind, lapply(names(panel_aliases), function(alias) {
  signature <- paste(sort(panel_aliases[[alias]]), collapse = ";")
  sid <- names(subset_signature)[match(signature, subset_signature)]
  data.frame(alias = alias, subset_id = sid, genes = signature,
             n_genes = length(panel_aliases[[alias]]), stringsAsFactors = FALSE)
}))
alias_group <- aggregate(alias ~ subset_id + genes + n_genes, alias_table, paste, collapse = " | ")
algorithm_panels <- merge(alias_group, all_results, by = c("subset_id", "genes", "n_genes"), all.x = TRUE)
algorithm_panels <- algorithm_panels[order(-algorithm_panels$ROC_AUC_internal,
                                           algorithm_panels$n_genes,
                                           algorithm_panels$alias), ]
write.csv(algorithm_panels, file.path(results_dir, "algorithm_defined_panels_le7.csv"), row.names = FALSE)
write.csv(alias_table, file.path(results_dir, "algorithm_panel_aliases.csv"), row.names = FALSE)

selected_summary <- merge(selection_lock,
                          all_results[, c("subset_id", "AUC_CI_low_internal", "AUC_CI_high_internal",
                                          "log_loss_internal", "Brier_internal", "ROC_AUC_external",
                                          "AUC_CI_low_external", "AUC_CI_high_external",
                                          "log_loss_external", "Brier_external")],
                          by = "subset_id", all.x = TRUE)
write.csv(selected_summary, file.path(results_dir, "selected_panels_with_external_evaluation.csv"), row.names = FALSE)

# Coefficients and a coefficient-free, direction-locked equal-weight score are
# retained as sensitivity checks for the internally locked panel(s).
selected_unique_ids <- unique(selection_lock$subset_id)
coef_rows <- list()
equal_weight_rows <- list()
ci <- 0L
ei <- 0L
for (sid in selected_unique_ids) {
  genes <- subset_list[[sid]]
  coef_mat <- as.matrix(coef(models[[sid]]$cvfit, s = "lambda.1se"))
  ci <- ci + 1L
  coef_rows[[ci]] <- data.frame(
    subset_id = sid,
    term = rownames(coef_mat),
    coefficient = as.numeric(coef_mat[, 1]),
    lambda_1se = models[[sid]]$lambda_1se,
    stringsAsFactors = FALSE
  )

  center <- colMeans(x_dev[, genes, drop = FALSE])
  scale <- apply(x_dev[, genes, drop = FALSE], 2, sd)
  scale[!is.finite(scale) | scale == 0] <- 1
  direction <- sign(colMeans(x_dev[y_dev == 1, genes, drop = FALSE]) -
                      colMeans(x_dev[y_dev == 0, genes, drop = FALSE]))
  direction[direction == 0] <- 1
  score_matrix <- function(x) {
    z <- sweep(x[, genes, drop = FALSE], 2, center, "-")
    z <- sweep(z, 2, scale, "/")
    rowMeans(sweep(z, 2, direction, "*"))
  }
  for (cohort_info in list(
    list(name = "GSE66360_predefined_validation", labels = y_val_label, x = x_val),
    list(name = "GSE48060_external", labels = y_ext_label, x = x_ext)
  )) {
    score <- score_matrix(cohort_info$x)
    roc_obj <- pROC::roc(cohort_info$labels, score, levels = c("Control", "MI"), direction = "<", quiet = TRUE)
    ci_auc <- as.numeric(pROC::ci.auc(roc_obj, method = "delong"))
    ei <- ei + 1L
    equal_weight_rows[[ei]] <- data.frame(
      subset_id = sid,
      genes = paste(genes, collapse = ";"),
      cohort = cohort_info$name,
      ROC_AUC = as.numeric(pROC::auc(roc_obj)),
      AUC_CI_low = ci_auc[1],
      AUC_CI_high = ci_auc[3],
      direction = paste(paste0(genes, ":", ifelse(direction > 0, "+", "-")), collapse = ";"),
      stringsAsFactors = FALSE
    )
  }
}
write.csv(do.call(rbind, coef_rows), file.path(results_dir, "selected_panel_ridge_coefficients.csv"), row.names = FALSE)
write.csv(do.call(rbind, equal_weight_rows), file.path(results_dir, "selected_panel_equal_weight_sensitivity.csv"), row.names = FALSE)

# Stratified bootstrap of the predefined validation cohort quantifies how often
# each subset would win if the same 56-person validation cohort were resampled.
# This affects uncertainty reporting only; it does not consult GSE48060.
auc_fast <- function(truth01, score) {
  n1 <- sum(truth01 == 1L)
  n0 <- sum(truth01 == 0L)
  (sum(rank(score, ties.method = "average")[truth01 == 1L]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
val_pred <- predictions_long[predictions_long$cohort == "GSE66360_predefined_validation", ]
val_ids <- unique(val_pred$sample_id)
subset_ids <- names(subset_list)
val_matrix <- matrix(NA_real_, nrow = length(val_ids), ncol = length(subset_ids),
                     dimnames = list(val_ids, subset_ids))
for (sid in subset_ids) {
  d <- val_pred[val_pred$subset_id == sid, ]
  val_matrix[d$sample_id, sid] <- d$probability_MI
}
truth_map <- val_pred[!duplicated(val_pred$sample_id), c("sample_id", "truth")]
truth01 <- as.integer(truth_map$truth[match(val_ids, truth_map$sample_id)] == "MI")
stopifnot(!anyNA(val_matrix), sum(truth01 == 1L) == 28L, sum(truth01 == 0L) == 28L)

set.seed(20260921)
n_boot <- 1000L
boot_winner <- character(n_boot)
boot_winner_auc <- numeric(n_boot)
idx0 <- which(truth01 == 0L)
idx1 <- which(truth01 == 1L)
subset_sizes <- vapply(subset_list, length, integer(1))
for (b in seq_len(n_boot)) {
  take <- c(sample(idx0, length(idx0), replace = TRUE),
            sample(idx1, length(idx1), replace = TRUE))
  truth_b <- truth01[take]
  auc_b <- apply(val_matrix[take, , drop = FALSE], 2, function(z) auc_fast(truth_b, z))
  top <- names(auc_b)[auc_b >= max(auc_b) - 1e-12]
  top <- top[order(subset_sizes[top], top)]
  boot_winner[b] <- top[1]
  boot_winner_auc[b] <- auc_b[top[1]]
}
winner_tab <- sort(table(boot_winner), decreasing = TRUE)
winner_frequency <- data.frame(
  subset_id = names(winner_tab),
  selection_count = as.integer(winner_tab),
  selection_frequency = as.integer(winner_tab) / n_boot,
  stringsAsFactors = FALSE
)
winner_frequency$genes <- vapply(winner_frequency$subset_id, function(sid) paste(subset_list[[sid]], collapse = ";"), character(1))
winner_frequency$n_genes <- subset_sizes[winner_frequency$subset_id]
write.csv(winner_frequency, file.path(results_dir, "validation_bootstrap_subset_selection_frequency.csv"), row.names = FALSE)

gene_boot_frequency <- data.frame(
  gene = genes7,
  selection_frequency = vapply(genes7, function(g) {
    mean(vapply(boot_winner, function(sid) g %in% subset_list[[sid]], logical(1)))
  }, numeric(1)),
  stringsAsFactors = FALSE
)
gene_boot_frequency <- gene_boot_frequency[order(-gene_boot_frequency$selection_frequency, gene_boot_frequency$gene), ]
write.csv(gene_boot_frequency, file.path(results_dir, "validation_bootstrap_gene_selection_frequency.csv"), row.names = FALSE)
write.csv(data.frame(
  bootstrap_replicates = n_boot,
  locked_subset_id = one_se_selected$subset_id,
  locked_subset_win_frequency = mean(boot_winner == one_se_selected$subset_id),
  median_winner_AUC = median(boot_winner_auc),
  winner_AUC_q025 = unname(quantile(boot_winner_auc, 0.025)),
  winner_AUC_q975 = unname(quantile(boot_winner_auc, 0.975))
), file.path(results_dir, "validation_bootstrap_summary.csv"), row.names = FALSE)

pool_evidence <- merge(pool, evidence, by = "gene", all.x = TRUE, suffixes = c("_ML", "_PFOS"))
limma7 <- limma[limma$gene %in% genes7, c("cohort", "gene", "logFC", "P.Value", "adj.P.Val")]
limma_wide <- reshape(limma7, idvar = "gene", timevar = "cohort", direction = "wide")
pool_evidence <- merge(pool_evidence, limma_wide, by = "gene", all.x = TRUE)
write.csv(pool_evidence, file.path(results_dir, "vote2_seven_gene_evidence.csv"), row.names = FALSE)

selected_ids <- unique(selection_lock$subset_id)
selected_genes <- unique(unlist(subset_list[selected_ids]))
write.csv(pool_evidence[pool_evidence$gene %in% selected_genes, ],
          file.path(results_dir, "selected_panel_gene_evidence.csv"), row.names = FALSE)

# Reproducibility checks.
checks <- data.frame(
  check = c(
    "PFOS operational intersection definition retained",
    "Seven genes supported by at least two algorithms",
    "All 120 multi-gene subsets enumerated",
    "All models use the same discovery-only folds",
    "Expected validation and external sample counts",
    "Selection lock uses no external metric",
    "All selected panels contain at most seven genes",
    "No missing AUC estimates",
    "Equal-weight sensitivity analysis complete",
    "Validation bootstrap frequencies valid"
  ),
  pass = c(
    file.exists(file.path(input_root, "03_data_processed", "PFOS_targets_consensus2plus.txt")),
    nrow(pool) == 7L && all(pool$n_algorithms >= 2L),
    length(subset_list) == 120L && length(unique(subset_signature)) == 120L,
    nrow(fold_assignment) == 43L && length(unique(fold_assignment$fold)) == 5L,
    all(metrics_long$n[metrics_long$cohort == "GSE66360_predefined_validation"] == 56L) &&
      all(metrics_long$n[metrics_long$cohort == "GSE48060_external"] == 52L),
    !any(grepl("external", names(selection_lock), ignore.case = TRUE)),
    all(selection_lock$n_genes <= 7L),
    !anyNA(metrics_long$ROC_AUC),
    nrow(do.call(rbind, equal_weight_rows)) == 2L * length(selected_unique_ids) &&
      !anyNA(do.call(rbind, equal_weight_rows)$ROC_AUC),
    abs(sum(winner_frequency$selection_frequency) - 1) < 1e-12
  ),
  stringsAsFactors = FALSE
)
write.csv(checks, file.path(logs_dir, "QA_checks.csv"), row.names = FALSE)

audit <- c(
  "Compact (<=7 genes) PFOS-MI combination-screen audit",
  sprintf("Generated: %s", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z")),
  sprintf("Input root: %s", input_root),
  sprintf("Output root: %s", normalizePath(output_root, winslash = "/", mustWork = TRUE)),
  "",
  sprintf("Overall: %s (%d PASS, %d FAIL)", if (all(checks$pass)) "PASS" else "FAIL",
          sum(checks$pass), sum(!checks$pass)),
  paste0("[", ifelse(checks$pass, "PASS", "FAIL"), "] ", checks$check),
  "",
  "Design boundary:",
  "PFOS targets are the >=2-of-5 database consensus set; literal five-way intersection is empty.",
  "Four selector memberships were derived from the GSE66360 discovery cohort only.",
  "The seven-gene pool is the >=2-of-4 algorithm vote set.",
  "Subset selection used only the predefined GSE66360 validation cohort.",
  "GSE48060 metrics were attached only after the subset IDs were locked.",
  "Selecting a different panel by inspecting GSE48060 would convert it into a model-selection set."
)
writeLines(audit, file.path(logs_dir, "QA_AUDIT.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(logs_dir, "R_sessionInfo.txt"), useBytes = TRUE)

manifest <- c(
  "ANALYSIS MANIFEST",
  "PFOS target rule: supported by at least 2 of SuperPred, PharmMapper, SwissTargetPrediction, STITCH, and TargetNet",
  "PFOS consensus targets: 74; PFOS-MI overlap: 38; measured candidates: 37",
  sprintf("Algorithm-vote pool (>=2 of LASSO, SVM-RFE, Boruta, XGBoost): %d genes", length(genes7)),
  sprintf("Vote-pool genes: %s", paste(genes7, collapse = ";")),
  "Combination search: every 2-7 gene subset of the seven-gene pool (120 signatures)",
  "Classifier: ridge logistic regression; lambda.1se selected using fixed stratified five-fold CV in the discovery cohort",
  "Internal subset selection: predefined GSE66360 validation cohort only",
  "External evaluation: GSE48060 attached after selection lock",
  "AUC: direction locked (Control < MI probability); values below 0.5 were not inverted",
  sprintf("Best-internal subset: %s [%s]", best_internal$subset_id, best_internal$genes),
  sprintf("One-SE-style parsimonious subset: %s [%s]", one_se_selected$subset_id, one_se_selected$genes)
)
writeLines(manifest, file.path(results_dir, "ANALYSIS_MANIFEST.txt"), useBytes = TRUE)

if (!all(checks$pass)) stop("QA failed; inspect logs/QA_checks.csv")
cat(paste(manifest, collapse = "\n"), "\n")
cat("QA: PASS\n")
